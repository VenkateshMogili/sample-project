 function helloWorld(){
      // alert("Hello World!");
      // document.getElementById("output").innerText="<h1>Hello World!</h1>";
       document.getElementsByClassName("output2")[1].innerHTML="<h1>Hello World!</h1>";
    }