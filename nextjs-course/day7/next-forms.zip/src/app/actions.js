"use server";

import { revalidatePath } from "next/cache";
import User from "../../models/User";

export async function handleSubmit(prevState, formData) {
  try {
    const isEdit = formData.get("_id");
    if (isEdit) {
      const userData = {
        name: formData.get("name")
      }
      await User.findByIdAndUpdate(isEdit, userData);

      revalidatePath("/");
      return { message: "User Updated!" }
    } else {
      const userData = {
        name: formData.get("name"),
        email: formData.get("name") + "@gmail.com"
      }
      const user = new User(userData);
      await user.save();

      revalidatePath("/");
      return { message: "New User Created!" }
    }

  } catch (error) {
    return { message: error.message };
  }
}

export async function getUsers() {
  try {
    return await User.find({});
  } catch (error) {
    return [];
  }
}

export async function handleDelete(id) {
  try {
    await User.findByIdAndDelete(id);

    revalidatePath("/");

    return { message: "User Deleted!" }
  } catch (error) {
    return { message: error.message };
  }
}