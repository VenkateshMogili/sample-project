import { getUsers } from "./actions";
import UserAppV1 from "./components/UserAppV1";
import UserAppV2 from "./components/UserAppV2";

export default async function Home() {
  const users=await getUsers();

  return (
    <UserAppV2
    users={JSON.parse(JSON.stringify(users))}
    />
  );
}
