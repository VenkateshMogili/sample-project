import React from 'react'
import User from '../../../../models/User';
import EditForm from './EditForm';

export default async function EditUser({params}) {
  const userInfo=await User.findOne({_id:params.id});

  return (
    <EditForm userInfo={JSON.parse(JSON.stringify(userInfo))}/>
  )
}
