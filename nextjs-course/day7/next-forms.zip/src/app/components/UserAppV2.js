"use client";

import React, { useActionState, useEffect, useState } from 'react'
import { handleDelete, handleSubmit } from '../actions';
import { useFormStatus } from 'react-dom';
import Link from 'next/link';
import styles from "./UserApp.module.css";
import Image from 'next/image';
import vmImage from "../../../public/vm.png";

const initialState={
  message:""
};

function AddButton({handleReset}){
  const {pending}=useFormStatus();

  useEffect(()=>{
    if(pending){
      handleReset();
    }
  },[pending])

  return (
    <button className='w-[400px] p-2 rounded bg-green-500 m-2' disabled={pending}>{pending?"Adding...":"Add"}</button>
  )
}

function EditButton({handleReset}){
  const {pending}=useFormStatus();

  useEffect(()=>{
    if(pending){
      handleReset();
    }
  },[pending])

  return (
    <button className='w-[400px] p-2 rounded bg-green-500 m-2' disabled={pending}>{pending?"Updating...":"Update"}</button>
  )
}

export default function UserAppV2({ users }) {
  const [state,formAction]=useActionState(handleSubmit,initialState);
  const [selectedId,setSelectedId]=useState('');
  const [selectedName,setSelectedName]=useState('');

  const handleEdit=(id,user)=>{
    setSelectedId(id);
    setSelectedName(user.name);
  }

  const handleReset=()=>{
    setSelectedId('');
    setSelectedName('');
  }

  const handleRemove=(id)=>{
    const confirm=window.confirm("Are you sure want to delete?");
    if(confirm){
      handleDelete(id);
    }
  }

  // const blueColor={color:'blue'}

  return (
    <div className='m-2'>
      <h1 className={`text-orange-400 text-5xl text-center m-2 bg-green-100 rounded p-5 m-5`}>User Management App with Next.js 15 v2</h1>
      <img src="/vm.png"/>
      <Image src={"https://upload.wikimedia.org/wikipedia/commons/thumb/2/2f/Google_2015_logo.svg/800px-Google_2015_logo.svg.png"} width={500} height={500}/>

      <Link href="/add-user" className='flex justify-center'>
      <button className='w-[100px] p-3 rounded bg-green-500 m-2 hover:bg-green-600'>Add User</button>
      </Link>

      {!users.length ? <h1 className='text-center text-red-500'>No Users Found!</h1> :
        <table className='border w-full text-center mt-2'>
          <thead className='border'>
            <tr className='bg-green-500'>
              <th className='p-3'>Name</th>
              <th className='p-3'>Email</th>
              <th className='p-3'>Actions</th>
            </tr>
          </thead>
          <tbody>
            {users.map((user, index) => (
              <tr key={index}>
                <td className='p-2'>{user.name}</td>
                <td className='p-2'>{user.email}</td>
                <td className='p-2'>

      <Link href={`/edit-user/${user._id}`}>
                  <button className='bg-blue-400 p-2 w-[100px] rounded m-2'>Edit</button>
                  </Link>
                  <button className='bg-red-400 p-2 w-[100px] rounded m-2' onClick={()=>handleRemove(user._id)}>Delete</button>
                </td>
              </tr>
            ))}
          </tbody>
        </table>}
    </div>
  )
}
