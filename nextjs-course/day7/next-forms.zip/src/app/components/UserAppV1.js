"use client";

import React, { useActionState, useEffect, useState } from 'react'
import { handleDelete, handleSubmit } from '../actions';
import { useFormStatus } from 'react-dom';

const initialState={
  message:""
};

function AddButton({handleReset}){
  const {pending}=useFormStatus();

  useEffect(()=>{
    if(pending){
      handleReset();
    }
  },[pending])

  return (
    <button className='w-[400px] p-2 rounded bg-green-500 m-2' disabled={pending}>{pending?"Adding...":"Add"}</button>
  )
}

function EditButton({handleReset}){
  const {pending}=useFormStatus();

  useEffect(()=>{
    if(pending){
      handleReset();
    }
  },[pending])

  return (
    <button className='w-[400px] p-2 rounded bg-green-500 m-2' disabled={pending}>{pending?"Updating...":"Update"}</button>
  )
}

export default function UserAppV1({ users }) {
  const [state,formAction]=useActionState(handleSubmit,initialState);
  const [selectedId,setSelectedId]=useState('');
  const [selectedName,setSelectedName]=useState('');

  const handleEdit=(id,user)=>{
    setSelectedId(id);
    setSelectedName(user.name);
  }

  const handleReset=()=>{
    setSelectedId('');
    setSelectedName('');
  }

  const handleRemove=(id)=>{
    const confirm=window.confirm("Are you sure want to delete?");
    if(confirm){
      handleDelete(id);
    }
  }

  return (
    <div className='m-2'>
      <h1 className='text-green-500 text-5xl text-center m-2'>User Management App with Next.js 15 v1</h1>

      <form action={formAction} className='flex flex-col items-center'>
        <input type="hidden" name="_id" value={selectedId}/>
        <input
          type="text"
          placeholder='Enter your name'
          name="name"
          value={selectedName}
          onChange={(e)=>setSelectedName(e.target.value)}
          className='w-[400px] p-2 rounded m-2 text-black'
        />
        {selectedId?<EditButton handleReset={handleReset}/>:
        <AddButton handleReset={handleReset}/>}
        {state?.message}
      </form>

      {!users.length ? <h1 className='text-center text-red-500'>No Users Found!</h1> :
        <table className='border w-full text-center mt-2'>
          <thead className='border'>
            <tr className='bg-green-500'>
              <th className='p-3'>Name</th>
              <th className='p-3'>Email</th>
              <th className='p-3'>Actions</th>
            </tr>
          </thead>
          <tbody>
            {users.map((user, index) => (
              <tr key={index}>
                <td className='p-2'>{user.name}</td>
                <td className='p-2'>{user.email}</td>
                <td className='p-2'>
                  <button className='bg-blue-400 p-2 w-[100px] rounded m-2' onClick={()=>handleEdit(user._id,user)}>Edit</button>
                  <button className='bg-red-400 p-2 w-[100px] rounded m-2' onClick={()=>handleRemove(user._id)}>Delete</button>
                </td>
              </tr>
            ))}
          </tbody>
        </table>}
    </div>
  )
}
