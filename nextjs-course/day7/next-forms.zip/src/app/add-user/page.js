"use client";

import React, { useActionState, useEffect } from 'react'
import { handleSubmit } from '../actions';
import { useFormStatus } from 'react-dom';
import { redirect } from 'next/navigation';

const initialState={
  message:""
};

function AddButton(){
  const {pending}=useFormStatus();

  useEffect(()=>{
      if(pending){
        redirect("/");
      }
    },[pending])

  return (
    <button className='w-[400px] p-2 rounded bg-green-500 m-2' disabled={pending}>{pending?"Adding...":"Add"}</button>
  )
}

export default function AddUser() {
    const [state,formAction]=useActionState(handleSubmit,initialState);

  return (
    <div>
    <h1 className='text-orange-500 text-5xl text-center m-5'>Add User</h1>

    <form action={formAction} className='flex flex-col items-center'>
        <input
          type="text"
          placeholder='Enter your name'
          name="name"
          className='w-[400px] p-2 rounded m-2 text-black'
        />
        <AddButton />
        {state?.message}
      </form>
      </div>
  )
}
