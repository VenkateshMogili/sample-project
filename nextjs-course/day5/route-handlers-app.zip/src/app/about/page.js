"use client"
import React from 'react'

export default function About() {
  console.log("About Client Component!");
  return (
    <div>About</div>
  )
}
