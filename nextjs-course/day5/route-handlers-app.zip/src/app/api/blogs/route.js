import { blogs } from "./data";

// export function GET(){
//   return Response.json(blogs);
// }

export async function GET(request){
  const searchParams = await request.nextUrl.searchParams;
  const query=searchParams.get("query");
  const limit=searchParams.get("limit");
  const filteredBlogs = query?blogs.filter(blog=>blog.title.includes(query)):blogs;
  const limitedBlogs = limit?filteredBlogs.slice(0,limit):blogs;
  return Response.json(limitedBlogs);
}

export async function POST(request){
  const body = await request.json();
  const newBlog={
    id:blogs.length+1,
    title:body.title
  };
  blogs.push(newBlog);
  return new Response(JSON.stringify(newBlog),{
    status:201,
    headers:{
      "Content-Type":"application/json"
    }
  });
}