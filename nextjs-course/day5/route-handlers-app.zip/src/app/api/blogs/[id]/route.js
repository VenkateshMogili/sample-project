import { redirect } from "next/navigation";
import { blogs } from "../data";

export function GET(_request,{params}){
  const singleBlog=blogs.find(blog=>blog.id===parseInt(params.id));
  if(!singleBlog){
    redirect("/api/blogs");
  }
  return Response.json(singleBlog);
}

export async function PUT(request,{params}){
  const body = await request.json();
  const index=blogs.findIndex(blog=>blog.id===parseInt(params.id));
  blogs[index].title=body.title;
  return Response.json(blogs[index]);
}

export async function DELETE(_request,{params}){
  const index=blogs.findIndex(blog=>blog.id===parseInt(params.id));
  const deletedBlog = blogs[index];
  blogs.splice(index,1);
  return Response.json(deletedBlog);
}