import { cookies, headers } from "next/headers"

export function GET(){
  const headersList = headers();
  const cookieStore = cookies();
  const theme = cookieStore.get("theme");
  console.log(theme);
  if(!theme){
    cookieStore.set("theme","dark")
  }
  const Authorization = headersList.get('Authorization');
  const token = headersList.get('token');
  console.log(token);
  return new Response("<h1>Profile Data</h1>",{
    headers:{
      "Content-Type":"text/html",
      "Authorization":Authorization,
      // "Set-Cookie":"theme=dark"
    }
  })
}