import React from 'react'

export default async function Review() {
  await new Promise((resolve)=>setTimeout(resolve,5000));
  return (
    <div>Review</div>
  )
}
