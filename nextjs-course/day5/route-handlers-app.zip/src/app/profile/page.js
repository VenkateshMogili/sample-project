import { cookies } from 'next/headers';
import React from 'react'

export default function Profile() {
  const cookieStore = cookies();
  const theme = cookieStore.get("theme");
  console.log(theme);
  console.log("Profile Server Component!");
  return (
    <div>Profile</div>
  )
}
