import React, { Suspense } from 'react'
import Product from '../components/Product'
import Review from '../components/Review'

export default function ProductDetails() {
  return (
    <div>
      <h1>Product Details</h1>
      <Suspense fallback={<h1>Loading Products</h1>}>
      <Product/>
      </Suspense>
      <Suspense fallback={<h1>Loading Reviews</h1>}>
      <Review/>
      </Suspense>
    </div>
  )
}
