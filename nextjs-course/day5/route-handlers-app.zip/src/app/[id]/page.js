import React from 'react'

export default function UserProfile() {
  return (
    <div>UserProfile</div>
  )
}
