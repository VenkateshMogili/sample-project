import { cookies, headers } from "next/headers";
import { NextResponse } from "next/server"

export default async function middleware(request){
  const Authorization = headers().get("Authorization");
  const Token = cookies().get("token");
  if(!Token){
  return NextResponse.redirect(new URL("/",request.url));
  }
}

export const config={
  matcher:['/api/profile','/api/blogs']
}