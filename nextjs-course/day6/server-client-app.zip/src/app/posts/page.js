import Link from 'next/link';
import React from 'react'
export async function getData(){
  const res=await fetch("https://jsonplaceholder.typicode.com/posts");
  return res.json();
}

export default async function Posts() {
  const posts=await getData();
  return (
    <div className='m-3'>
      <h1 className='m-2'>Posts</h1>
      {posts.map((post,index)=>(
        <p key={index} className='m-2 border p-2'>
          <Link href={'/posts/'+post.id}>{post.title}</Link>
          </p>
      ))}
    </div>
  )
}
