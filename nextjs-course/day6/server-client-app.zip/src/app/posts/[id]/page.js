import React from 'react'

export async function getData(id){
  const res=await fetch("https://jsonplaceholder.typicode.com/posts/"+id);
  return res.json();
}


export async function generateStaticParams(){
  const res=await fetch("https://jsonplaceholder.typicode.com/posts");
  const posts=await res.json();

  return posts.map(post=>({
    id:post.id.toString()
  }))
}

export async function generateMetadata({params}){
  const post = await getData(params.id);
  return {
    title:post.title
  }
}

export default async function PostPage({params}) {
  const post = await getData(params.id);
  return (
    <div className='m-3'>
      <h1 className='m-2'>Single Post Page</h1>
      <div className='border p-2 rounded bg-blue-400 text-white'>
      <p className='m-2'>{post.title}</p>
      <p className='m-2'>{post.body}</p>
      </div>
    </div>
  )
}
