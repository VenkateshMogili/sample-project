"use client";

import { createContext } from "react";

export const BlogContext=createContext();

export default function ThemeProvider({children}){
  return <BlogContext.Provider value="Vivek">{children}</BlogContext.Provider>
}