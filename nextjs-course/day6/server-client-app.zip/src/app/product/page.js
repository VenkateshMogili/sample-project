"use client";

import React, { useContext, useEffect, useState } from 'react'
// import { getItem } from './localStorage';
import { BlogContext } from '../theme-provider';

// eslint-disable-next-line @next/next/no-async-client-component
export default function Product() {
  // eslint-disable-next-line react-hooks/rules-of-hooks
  const [input,setInput]=useState();
  // eslint-disable-next-line react-hooks/rules-of-hooks
  const blogName = useContext(BlogContext);
  // const item=getItem();
  console.log(blogName);

  const [posts,setPosts]=useState(null);

  useEffect(()=>{
    async function fetchData(){
      const res=await fetch("https://jsonplaceholder.typicode.com/todos");
      const posts=await res.json();
      setPosts(posts);
    }
    fetchData();
  },[])

  if(!posts) return <h1>Loading...</h1>
  return (
    <div>
      <h1>Blogs in Client</h1>
      {posts.length>0 && posts.map((post,index)=>(
        <p key={index}>{post.title}</p>
      ))}
    </div>
  )
}
