import "client-only";

export const getItem=()=>{
  localStorage.getItem("item");
}