import "server-only";
import React from 'react'
import Carousel from './carousel';

export async function getData(){
  // console.log(process.env.API_KEY);
  const res=await fetch("https://api.vercel.app/blog",{
    headers:{
      authorization:process.env.API_KEY
    }
  })
  return res.json();
}

export default async function Blogs() {
  const data=await getData();
  // console.log(data);

  const blogsData = await fetch("https://api.vercel.app/blog",{
    cache:'no-store'
  });
  const posts=await blogsData.json();
  return (
    <div>
      <h1>Blogs</h1>
      {posts.map((post,index)=>(
        <p key={index}>{post.title}</p>
      ))}
      <Carousel>
                <div>
                    <img src="/next.svg" />
                    <p className="legend">Legend 1</p>
                </div>
                <div>
                    <img src="/next.svg" />
                    <p className="legend">Legend 2</p>
                </div>
                <div>
                    <img src="/next.svg" />
                    <p className="legend">Legend 3</p>
                </div>
            </Carousel>
    </div>
  )
}
