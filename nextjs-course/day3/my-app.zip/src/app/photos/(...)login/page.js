import React from 'react'

export default function LoginIntercepted() {
  return (
    <div>
      <h1>Login Modal</h1>
    </div>
  )
}
