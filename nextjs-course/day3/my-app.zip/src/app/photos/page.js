import Link from 'next/link'
import React from 'react'

export default function Photos() {
  return (
    <div>
      <h1>Photos List</h1>
      <Link href="/photos/1">Photo 1</Link>
      <br/>
      <Link href="/photos/2">Photo 2</Link>
      <br/>
      <Link href="/photos/3">Photo 3</Link>
      <br/>
      <Link href="/login">Login</Link>
    </div>
  )
}
