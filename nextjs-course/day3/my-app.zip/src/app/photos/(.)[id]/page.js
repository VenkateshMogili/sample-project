import React from 'react'
import Image from 'next/image'
import birdImage from '../../images/bird.jpg';

export default function PhotoModal({params}) {
  return (
    <div className="modal">
      <p>Intercepted PhotoModal - {params.id}</p>
    <Image src={birdImage} width={200} height={200} alt="photo"/>
    </div>
  )
}
