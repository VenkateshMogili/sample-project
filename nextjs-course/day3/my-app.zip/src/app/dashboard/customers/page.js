import { redirect } from 'next/navigation'
import React from 'react'

export const metadata={
  title:"Customers"
}

export default async function Customers() {
  // await new Promise((resolve,reject)=>setTimeout(resolve,3000));
  const response = await fetch("https://jsonplaceholder.typicode.com/todos");
  let todos = await response.json();
  // redirect("/dashboard");
  return (
    <div className='table table-2'>
        <h2>Customers</h2>
        <table>
          <thead>
            <tr>
              <th>S.No</th>
              <th>Name</th>
            </tr>
          </thead>
          <tbody>
            {todos.map((todo,index)=>(
            <tr key={index}>
            <td>{todo.id}</td>
            <td>{todo.title}</td>
          </tr>
            ))}
          </tbody>
        </table>
      </div>
  )
}
