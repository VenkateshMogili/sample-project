"use client"
import {useEffect} from 'react';

export default function Error({error,reset}){

  useEffect(()=>{
    console.log(error);
  },[error])

  return (
    <div className="error-container">
    <h1>Error in Customers {`${error}`}</h1>
    <button onClick={reset}>Try Again</button>
    </div>
  )
}