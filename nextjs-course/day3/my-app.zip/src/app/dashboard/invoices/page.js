import React from 'react'

export const metadata={
  title:{
    absolute:"Invoices"
  }
}

export default async function Invoices() {
  await new Promise((resolve,reject)=>setTimeout(resolve,3000));
  return (
    <div className='table table-2'>
        <h2>Invoices</h2>
        <table>
          <thead>
            <tr>
              <th>Id</th>
              <th>Name</th>
            </tr>
          </thead>
          <tbody>
            <tr>
              <td>1</td>
              <td>React</td>
            </tr>
            <tr>
              <td>2</td>
              <td>JavaScript</td>
            </tr>
            <tr>
              <td>3</td>
              <td>NodeJS</td>
            </tr>
            <tr>
              <td>4</td>
              <td>Angular</td>
            </tr>
            <tr>
              <td>5</td>
              <td>React Native</td>
            </tr>
            <tr>
              <td>6</td>
              <td>NextJS</td>
            </tr>
          </tbody>
        </table>
      </div>
  )
}
