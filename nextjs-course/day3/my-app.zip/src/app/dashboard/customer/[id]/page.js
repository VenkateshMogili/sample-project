import React from 'react'

export function generateMetadata({params}){
  return {
    title:'Customer - '+params.id
  }
}

export default function CustomerDetails(props) {
  // console.log(props);
  return (
    <div>
      <h1>Customer Details For {props.params.id}</h1>
    </div>
  )
}
