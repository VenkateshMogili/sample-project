"use client";
import "../globals.css";
import Image from "next/image";
import adminLogo from '../images/admin-logo.jpg';
import Link from "next/link";
import { usePathname, useRouter } from "next/navigation";
import { useState } from "react";

export default function DashboardLayout({ children }) {
  const pathname = usePathname();
  const router = useRouter();
  const [input,setInput]=useState("");
  return (
    <div className="app-container">
      <div className="side-menu-container">
        <Image src={adminLogo} width={200} height={200} alt="admin logo" />

        <div className="side-menu-links">
          <Link href="/dashboard" className={pathname === '/dashboard' ? 'active' : ''}>Dashboard</Link>
          <Link href="/dashboard/customers" className={pathname === '/dashboard/customers' ? 'active' : ''}>Customers</Link>
          <Link href="/dashboard/invoices" className={pathname === '/dashboard/invoices' ? 'active' : ''}>Invoices</Link>

          <button onClick={() => router.push('/dashboard')}>Navigate to Dashboard</button>
        </div>

        <button>Logout</button>
      </div>
      <div>
        <input type="text" placeholder="Search" className="search-input" value={input} onChange={(e)=>setInput(e.target.value)}/>
      {children}
      </div>
    </div>
  );
}
