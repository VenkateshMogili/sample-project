import React from 'react'

export default function BlogComment(props) {
  console.log(props);
  return (
    <div>
      <h1>Blog {props.params.blogId} Comment {props.params.commentId}</h1>
    </div>
  )
}
