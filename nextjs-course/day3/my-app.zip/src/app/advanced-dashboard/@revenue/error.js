"use client"
import {useEffect} from 'react';

export default function Error({error}){

  useEffect(()=>{
    console.log(error);
  },[error])

  return (
    <div className="error-container slot">
    <h1>Error in Revenue {`${error}`}</h1>
    </div>
  )
}