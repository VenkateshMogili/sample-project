import React from 'react'

export default function Revenue() {

  return (
    <div className='slot'>
      <h1>Revenue Slot</h1>
      </div>
  )
}
