import React from 'react'

export default async function Users() {
  await new Promise((resolve,reject)=>setTimeout(resolve,3000));
  return (
    <div className='slot'>
      <h1>Users Slot</h1>
      </div>
  )
}
