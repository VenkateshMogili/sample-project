import Link from 'next/link'
import React from 'react'

export default function Notifications() {
  return (
    <div className='slot'>
      <h1>Default Notifications Slot</h1>
      <Link href="/advanced-dashboard/archived" className="link">Archived</Link>
      </div>
  )
}
