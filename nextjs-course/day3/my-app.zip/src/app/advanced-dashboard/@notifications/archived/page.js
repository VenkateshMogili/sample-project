import Link from 'next/link'
import React from 'react'

export default function ArchivedNotifications() {
  return (
    <div className='slot'>
      <h1>Archived Notifications Slot</h1>
      <Link href="/advanced-dashboard" className="link">Default</Link>
      </div>
  )
}
