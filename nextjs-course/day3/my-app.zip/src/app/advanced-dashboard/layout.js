import "../globals.css";

export const metadata = {
  title: {
    default: "Advanced Dashboard",
    template: 'Advanced Dashboard | %s'
  },
  description: "Developed using Next.js",
};

export default function AdvancedDashboardLayout({ children,users,notifications,revenue,login }) {
  const isLoggedIn = false;
  return isLoggedIn?(
    <div>
      {children}

      <div className="dashboard-slots">
        {users}
        {notifications}
        {revenue}
      </div>
    </div>
  ):login
}
