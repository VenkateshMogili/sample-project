import React from 'react'

export default function AdvancedDashboard() {
  return (
    <div>
      <h1>Advanced Dashboard</h1>
    </div>
  )
}
