import React from 'react'

export default function Card(props) {
  return (
    <div className='card'>
      <h2>{props.title}</h2>
      <h3>{props.count}</h3>
      </div>
  )
}
