import { redirect } from 'next/navigation'
import React from 'react'

export default function Customers() {
  // redirect("/dashboard");
  return (
    <div className='table table-2'>
        <h2>Customers</h2>
        <table>
          <thead>
            <tr>
              <th>S.No</th>
              <th>Name</th>
            </tr>
          </thead>
          <tbody>
            <tr>
              <td>1</td>
              <td>Venkatesh</td>
            </tr>
            <tr>
              <td>2</td>
              <td>Vivek</td>
            </tr>
            <tr>
              <td>3</td>
              <td>Chinni</td>
            </tr>
            <tr>
              <td>4</td>
              <td>Siva</td>
            </tr>
            <tr>
              <td>5</td>
              <td>Lahari</td>
            </tr>
            <tr>
              <td>6</td>
              <td>Ramani</td>
            </tr>
          </tbody>
        </table>
      </div>
  )
}
