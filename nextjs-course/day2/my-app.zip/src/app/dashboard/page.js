import React from 'react'
import Card from '../components/card'
import Table from '../components/table'

export default function Dashboard() {
  const customersData=[
    {
      sNo:1,
      name:'Venkatesh'
    },
    {
      sNo:2,
      name:'Vivek'
    },
    {
      sNo:3,
      name:'Chinni'
    }
  ]
  const invoicesData=[
    {
      sNo:1,
      name:'React'
    },
    {
      sNo:2,
      name:'JavaScript'
    },
    {
      sNo:3,
      name:'NodeJS'
    }
  ]
  return (
    <div>
    <div className='cards'>
      <Card title="Customers" count="1000"/>
      <Card title="Invoices" count="2000"/>
      <Card title="Income" count="Rs.100000"/>
    </div>
    <div className='tables'>
      <Table title="Recent Customers" data={customersData} fields={['S.No','Name']}/>
      <Table title="Recent Invoices" data={invoicesData} fields={['Id','Name']}/>
    </div>
    </div>
  )
}
