import React from 'react'

export default function Table(props) {
  return (
    <div className='table'>
        <h2>{props.title}</h2>
        <table>
          <thead>
            <tr>
            {props.fields.map((field,index)=>(
              <th key={index}>{field}</th>
            ))}
            </tr>
          </thead>
          <tbody>
            {props.data.map((item,index)=>(
            <tr key={index}>
            <td>{item.sNo}</td>
            <td>{item.name}</td>
          </tr>
            ))}
          </tbody>
        </table>
      </div>
  )
}
