import React from 'react'

export default function Comments(props) {
  console.log(props);
  const [id,name]=props.params.slug || [];
  return (
    <div>
      <h1>Comments Page: Id: {id} and name {name}</h1>
    </div>
  )
}
