import Loader from "react-loader-spinner";
import "react-loader-spinner/dist/loader/css/react-spinner-loader.css";
export const LoaderContainer = () => {
  return <Loader type="ThreeDots" color="#00BFFF" height={20} width={100} />;
};
