### Install npm packages for backend
```npm install```

### Start the backend server
```npm start```

### Install npm packages for frontend
```cd frontend/```
```npm install```

### Start the frontend server
```npm start```