const mongoose = require("mongoose");

const CoursesSchema = new mongoose.Schema({
  coursename: String,
  description: {
    type: String,
  },
  technologies: {
    type: String,
  },
  updatedat: {
    type: Date,
    default: Date.now(),
  },
  createdat: {
    type: Date,
    default: Date.now(),
  },
});

module.exports = mongoose.model("Course", CoursesSchema);
