const mongoose = require("mongoose");
const BlackListModel = mongoose.model("BlackList");

const addBlackList = (data, callback) => {
  BlackListModel.insertMany([data], callback);
};

const updateBlackList = (token, email, callback) => {
  BlackListModel.findOneAndUpdate({email}, {$set: token}, callback);
};

const fetchBlackList = (email, callback) => {
  BlackListModel.findOne({email}, callback);
};
const fetchBlackListAccount = (email, token, callback) => {
  BlackListModel.findOne({email, token}, callback);
};

module.exports = {
  addBlackList,
  fetchBlackList,
  updateBlackList,
  fetchBlackListAccount,
};
