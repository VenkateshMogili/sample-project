const mongoose = require("mongoose");
const UserModel = mongoose.model("User");
const createUser = (data, callback) => {
  UserModel.insertMany([data], callback);
};

const fetchUser = (email, callback) => {
  UserModel.findOne({email}, callback);
};
const updateUser = (data, email, callback) => {
  UserModel.findOneAndUpdate({email}, {$set: data}, callback);
};
const deleteUserAccount = (email, callback) => {
  UserModel.findOneAndRemove({email}, callback);
};
const verifyUserAccount = (refreshtoken, callback) => {
  UserModel.findOne(
    {
      refreshtoken,
      expiretoken: {$gt: Date.now()},
    },
    callback,
  );
};
const signinUserAccount = (email, callback) => {
  UserModel.findOne({email, verified: 1, activestatus: 1}, callback);
};

module.exports = {
  createUser,
  fetchUser,
  updateUser,
  deleteUserAccount,
  verifyUserAccount,
  signinUserAccount,
};
