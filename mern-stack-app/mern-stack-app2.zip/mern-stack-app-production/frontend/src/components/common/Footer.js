import React from "react";

export default function Footer() {
  return (
    <div>
      <nav className="navbar navbar-expand-lg navbar-dark bg-dark">
        <div className="container-fluid">
          <a className="navbar-brand" href="/#">
            <b className="text-success">MERN</b> Stack Application
          </a>
        </div>
      </nav>
    </div>
  );
}
