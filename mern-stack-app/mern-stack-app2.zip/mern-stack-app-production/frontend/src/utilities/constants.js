export const WRONG_EMAIL = "Mail is not valid";
export const WRONG_PASSWORD = "Password must have at least 1 number, 1 alphabet, 1 special character";
