const mongoose = require("mongoose");

const BlackListSchema = new mongoose.Schema({
  token: String,
  email: {
    type: String,
    required: true,
  },
  updatedat: {
    type: Date,
    default: Date.now(),
  },
  createdat: {
    type: Date,
    default: Date.now(),
  },
});

module.exports = mongoose.model("BlackList", BlackListSchema);
