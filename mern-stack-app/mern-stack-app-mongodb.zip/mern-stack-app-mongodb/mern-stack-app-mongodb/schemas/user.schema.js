const mongoose = require("mongoose");

const UserSchema = new mongoose.Schema({
  name: {
    type: String,
    required: true,
  },
  email: {
    type: String,
    required: true,
  },
  password: {
    type: String,
    required: true,
  },
  profilepic: String,
  role: {
    type: String,
    default: "user",
  },
  verified: {
    type: Number,
    default: 0,
  },
  refreshtoken: String,
  expiretoken: Date,
  activestatus: {
    type: Number,
    default: 1,
  },
  updatedat: {
    type: Date,
    default: Date.now(),
  },
  createdat: {
    type: Date,
    default: Date.now(),
  },
});

module.exports = mongoose.model("User", UserSchema);
