const mongoose = require("mongoose");

const connection = mongoose.connect(
  "mongodb+srv://<username>:<password>@cluster0.s9ckl.mongodb.net/<databasename>?retryWrites=true&w=majority",
  {useNewUrlParser: true, useUnifiedTopology: true},
  (error) => {
    if (!error) {
      console.log("Database connected");
    } else {
      console.log("Database not connected");
    }
  },
);

module.exports = connection;

require("../schemas/user.schema");
require("../schemas/blacklist.schema");
require("../schemas/courses.schema");
