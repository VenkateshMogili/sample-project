require("dotenv").config();
const jwt = require("jsonwebtoken");
// const {fetchBlackListAccount} = require("../models/blacklist.model");
const {fetchBlackListAccount} = require("../models/mblacklist.model");

const authenticate = (req, res, next) => {
  let token = req.headers.authorization;
  if (typeof token !== "undefined") {
    let finalToken = token.split(" ")[1];
    jwt.verify(finalToken, process.env.SECRET_KEY, (error, user) => {
      if (!error) {
        fetchBlackListAccount(user.email, finalToken, (err, result) => {
          if (result != null) {
            req.user = user;
            next();
          } else {
            res.send({success: false, message: "Unauthorized"});
          }
        });
      } else {
        res.send({success: false, message: "Unauthorized"});
      }
    });
  } else {
    res.send({success: false, message: "Unauthorized"});
  }
};

module.exports = authenticate;
