require("dotenv").config();
// const {
//   // createUser,
//   fetchUser,
//   updateUser,
//   deleteUserAccount,
//   verifyUserAccount,
//   signinUserAccount,
// } = require("../models/user.model");
const {
  createUser,
  fetchUser,
  updateUser,
  deleteUserAccount,
  verifyUserAccount,
  signinUserAccount,
} = require("../models/muser.model");
const bcrypt = require("bcrypt");
const {commonResponse, sendMail} = require("../common");
const jwt = require("jsonwebtoken");
// const {fetchBlackList, updateBlackList, addBlackList, fetchBlackListAccount} = require("../models/blacklist.model");
const {fetchBlackList, updateBlackList, addBlackList, fetchBlackListAccount} = require("../models/mblacklist.model");

const signupUser = (req, res) => {
  bcrypt.hash(req.body.password, 12).then((hash) => {
    let user = {...req.body, password: hash};
    createUser(user, (err, result) => {
      if (!err) {
        sendMail("signup", req, res, "Account Created Successfully", "User Created Successfully");
      } else {
        res.send({success: false, message: "Already user exists"});
      }
    });
  });
};
const getUser = (req, res) => {
  fetchUser(req.params.email, (err, users) => {
    users.password = "";
    commonResponse({
      res,
      success: err ? false : true,
      message: err ? "User not found" : "User fetched Successfully!",
      data: [users],
      req,
    });
  });
};
const editUser = (req, res) => {
  updateUser(req.body, req.body.email, (err, users) => {
    commonResponse({
      res,
      success: users != null ? true : false,
      message: users != null ? "User Updated Successfully" : "User Not Found!",
      data: null,
      req,
    });
  });
};
const deleteUser = (req, res) => {
  let user = {...req.body, activestatus: 0};
  updateUser(user, req.body.email, (err, users) => {
    commonResponse({
      res,
      success: users != null ? true : false,
      message: users != null ? "User Deleted Successfully" : "User Not Found!",
      data: null,
      req,
    });
  });
};
const harddeleteUser = (req, res) => {
  deleteUserAccount(req.body.email, (err, users) => {
    commonResponse({
      res,
      success: users != null ? true : false,
      message: users != null ? "User Deleted Permanently" : "User Not Found!",
      data: null,
      req,
    });
  });
};
const verifyUser = (req, res) => {
  verifyUserAccount(req.params.token, (err, result) => {
    if (result != null) {
      updateUser({refreshtoken: null, expiretoken: null, verified: 1}, result.email, (err, users) => {
        if (users != null) {
          res.send(
            "<h1>User Verified Successfully</h1><script>window.location.href='https://mern-stack-application.netlify.app/login'</script>",
          );
        } else {
          res.send("<h1>User Not Verified</h1>");
        }
      });
    } else {
      res.send("<h1>User Not Verified</h1>");
    }
  });
};

const signinUser = (req, res) => {
  signinUserAccount(req.body.email, (err, user) => {
    if (user != null) {
      bcrypt.compare(req.body.password, user.password).then((result) => {
        if (result) {
          const token = jwt.sign(user._doc, process.env.SECRET_KEY, {expiresIn: "1d"});
          fetchBlackList(req.body.email, (err, result) => {
            if (result != null) {
              updateBlackList({token}, req.body.email, (err, userData) => {
                if (userData != null) {
                  commonResponse({
                    res,
                    success: true,
                    message: "User Logged in Successfully",
                    data: null,
                    token,
                    email: req.body.email,
                  });
                } else {
                  res.send({success: false, message: "Invalid Password"});
                }
              });
            } else {
              addBlackList({token, email: req.body.email}, (err, userData) => {
                if (!err) {
                  commonResponse({
                    res,
                    success: true,
                    message: "User Logged in Successfully",
                    data: null,
                    token,
                    email: req.body.email,
                  });
                } else {
                  res.send({success: false, message: "Invalid Password"});
                }
              });
            }
          });
        } else {
          res.send({success: false, message: "Invalid Password"});
        }
      });
    } else {
      res.send({success: false, message: "User not found!"});
    }
  });
};
const forgetpassword = (req, res) => {
  fetchUser(req.body.email, (err, users) => {
    if (users != null) {
      sendMail("forgetpassword", req, res, "Reset Your Password", "Please check your email to reset password");
    } else {
      res.send({success: false, message: "User not found!"});
    }
  });
};
const resetPassword = (req, res) => {
  verifyUserAccount(req.body.token, (err, result) => {
    if (result != null) {
      bcrypt.hash(req.body.password, 12).then((hash) => {
        updateUser({password: hash, refreshtoken: null, expiretoken: null}, result.email, (err, users) => {
          if (users != null) {
            res.send({success: true, data: null, message: "Password reset successfully!"});
          } else {
            res.send("<h1>User Not Verified</h1>");
          }
        });
      });
    } else {
      res.send({success: false, message: "User not found!"});
    }
  });
};

const changepassword = (req, res) => {
  signinUserAccount(req.body.email, (err, user) => {
    if (user != null) {
      bcrypt.compare(req.body.oldpassword, user.password).then((result) => {
        if (result) {
          bcrypt.hash(req.body.password, 12).then((hash) => {
            let user = {
              password: hash,
            };
            updateUser(user, req.body.email, (err, users) => {
              commonResponse({
                res,
                success: users != null ? true : false,
                message: users != null ? "Password Changed Successfully" : "User Not Found!",
                data: null,
                req,
              });
            });
          });
        } else {
          res.send({success: false, message: "Invalid Old Password"});
        }
      });
    } else {
      res.send({success: false, message: "User not found!"});
    }
  });
};

const logout = (req, res) => {
  fetchBlackListAccount(req.body.email, req.body.token, (err, result) => {
    if (result != null) {
      updateBlackList({token: ""}, req.body.email, (err, userData) => {
        if (userData != null) {
          commonResponse({
            res,
            success: true,
            message: "User Logged out Successfully",
            data: null,
            req,
          });
        } else {
          res.send({success: false, message: "User Not Logged out"});
        }
      });
    } else {
      res.send({success: false, message: "User Not Logged out"});
    }
  });
};
module.exports = {
  signupUser,
  getUser,
  editUser,
  deleteUser,
  harddeleteUser,
  verifyUser,
  signinUser,
  forgetpassword,
  resetPassword,
  changepassword,
  logout,
};
