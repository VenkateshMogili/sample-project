import React from "react";

export default function Example() {
	return (
		<div>
			<h1>Example</h1>
		</div>
	);
}
function Example2() {
	return <h2>Example2</h2>;
}
function Example3() {
	return <h2>Example3</h2>;
}
export { Example2, Example3 };
