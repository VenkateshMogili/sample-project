import React from "react";

export default function About() {
	return (
		<div className="mt-5">
			<h1>About</h1>
			<p>My name is Venkatesh Mogili. I'm a Full Stack Developer.</p>
			<h1>👨‍💻</h1>
		</div>
	);
}
