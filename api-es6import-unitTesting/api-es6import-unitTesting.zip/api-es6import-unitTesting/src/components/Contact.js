import React from "react";

export default function Contact() {
	return (
		<div>
			<h1>Contact Us</h1>
			<h2>Email: mogilivenkatesh3@gmail.com</h2>
			<h2>LinkedIn: Venkatesh Mogili</h2>
		</div>
	);
}
