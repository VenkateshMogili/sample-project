function menuOpen() {
  let menuElement = document.getElementById("menu");
  menuElement.classList.toggle("menu-open")
}