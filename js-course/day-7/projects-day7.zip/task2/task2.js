//notes
let notes = [];

//output
let output = document.getElementById("output");
let selectedIndex = null;
//load notes
function loadNotes(filterItems = notes) {
  let finalNotes = '';
  filterItems.length > 0 ? filterItems.map((item, index) => {
    finalNotes += `
    <div class="item">
      <h3>${item.title}</h3>
      <div class="controls">
        <button onclick="editNote(${index})">Edit</button>
        <button onclick="deleteNote(${index})">Delete</button>
      </div>
    </div>
    `
  }) : finalNotes += `<h2>No Notes Found!</h2>`;
  output.innerHTML = finalNotes;
}

//add/edit note
async function addEditNote() {
  let inputValue = document.getElementById("inputValue");
  let newNotes = { title: inputValue.value };
  if (selectedIndex != null) {
    //edit
    await fetch('https://jsonplaceholder.typicode.com/todos/' + parseInt(parseInt(selectedIndex) + parseInt(1)), {
      method: "PUT",
      headers: {
        "content-type": "application/json"
      },
      body: JSON.stringify(newNotes)
    }).then(response => response.json())
      .then(data => {
        notes[selectedIndex] = newNotes;
        selectedIndex = null;
      })
      .catch(error => {
        console.log(error)
      })
  } else {
    //add
    await fetch('https://jsonplaceholder.typicode.com/todos', {
      method: "POST",
      headers: {
        "content-type": "application/json"
      },
      body: JSON.stringify(newNotes)
    }).then(response => response.json())
      .then(data => {
        console.log(data)
        notes.push(data);
      })
      .catch(error => {
        console.log(error)
      })
  }
  inputValue.value = ""
  loadNotes();
}

//edit note
function editNote(index) {
  let filterItem = notes[index];
  let inputValue = document.getElementById("inputValue");
  inputValue.value = filterItem.title;
  selectedIndex = index;
}

//delete note
async function deleteNote(index) {
  await fetch('https://jsonplaceholder.typicode.com/todos/' + parseInt(parseInt(index) + parseInt(1)), {
    method: "DELETE"
  }).then(response => response.json())
    .then(data => {
      notes.splice(index, 1);
      loadNotes();
    })
    .catch(error => {
      console.log(error)
    })
}

//search notes
function searchNotes() {
  let searchInput = document.getElementById("searchInput")
  let filteredNotes = notes.filter(note => note.title.toLowerCase().indexOf(searchInput.value.toLowerCase()) !== -1);
  loadNotes(filteredNotes)
}
//sort by
function sortBy() {
  let sortedItems = notes.reverse();
  loadNotes(sortedItems);
}

//get notes
function getNotes() {
  fetch('https://jsonplaceholder.typicode.com/todos', {
    method: "GET"
  }).then(response => response.json())
    .then(data => {
      notes = data;
      loadNotes();
    })
    .catch(error => {
      console.log(error)
    })
}