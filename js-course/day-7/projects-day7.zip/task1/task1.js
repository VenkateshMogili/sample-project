let loader = document.getElementById("loader");
let mainContent = document.getElementById("main-content");
function loading() {
  show();
  setTimeout(() => {
    hide();
    loadItems();
    totalPrice();
  }, 2000);
}
function show() {
  loader.style.display = "block";
  mainContent.style.display = "none";
}
function hide() {
  loader.style.display = "none";
  mainContent.style.display = "block";
}
//items
let items = [
  {
    image: "img1.png",
    title: "Sweet Item",
    price: "$5",
    category: "Sweets"
  },
  {
    image: "img2.png",
    title: "Cup Cake",
    price: "$20",
    category: "Cup Cakes"
  },
  {
    image: "img3.png",
    title: "Cake Item",
    price: "$15",
    category: "Cakes"
  },
  {
    image: "img3.png",
    title: "Sweet Item",
    price: "$15",
    category: "Sweets"
  },
  {
    image: "img1.png",
    title: "Cup Cake",
    price: "$5",
    category: "Cup Cakes"
  },
  {
    image: "img2.png",
    title: "Cake Item",
    price: "$10",
    category: "Cakes"
  }
]

//output
let output = document.getElementById("output")
//load Items
function loadItems(filteredItems = items) {
  let finalResult = ''
  filteredItems.length > 0 ? filteredItems.map(item => {
    finalResult += `
     <div class="item">
      <img src="images/${item.image}" alt="thumbnail" class="item-thumbnail"/>
      <div class="item-details">
      <p>${item.title}</p>
      <p>${item.price}</p>
      </div>
    </div>
    `
  }) : finalResult += `<h2>No Results Found!</h2>`;
  output.innerHTML = finalResult;
}

//search item
function searchItem() {
  let inputValue = document.getElementById("searchInput")
  let filteredItems = items.filter(item => item.title.toLowerCase().indexOf(inputValue.value.toLowerCase()) !== -1 || item.price.toLowerCase().indexOf(inputValue.value.toLowerCase()) !== -1);
  loadItems(filteredItems)
}

//filter by
function filterBy(filterValue) {
  if (filterValue !== 'All') {
    let filteredItems = items.filter(item => item.category.includes(filterValue));
    loadItems(filteredItems)
  } else if (filterValue === 'All') {
    loadItems(items)
  }
}

//total price
function totalPrice() {
  let totalpriceElement = document.getElementById("totalprice");
  let sum = items.reduce((prevValue, currentValue) => {
    let splittedPrice = currentValue.price.split("$")[1];
    let numberDollar = parseInt(splittedPrice);
    return prevValue + numberDollar;
  }, 0);
  totalpriceElement.innerHTML = "$" + sum;
}