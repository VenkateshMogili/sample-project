// functions
function helloWorld() {
  let totalArguments = arguments.length;
  return this;
}
let result = helloWorld(10, 20, 30);
console.log(result);
// helloWorld.hobby = 'Youtuber';
// console.log(helloWorld.hobby);

// let run = function() {
//   return 'run';
// };
// console.log(run());

let running = (age) => {
  let a = 10;
  return this;
};

console.log(running(10));

function executeIt() {
  console.log(this);
  return this;
}

var person = {
  firstName: 'Venkatesh',
  fullname: function() {
    return this.firstName;
  },
};
console.log(person.fullname());
// console.log(executeIt());

// document.getElementById('btn').addEventListener('click', (event) => {
//   console.log(event);
// });

var username = 'Venkatesh';
(function(username) {
  console.log('output', username);
  document.getElementById('loader').style.display = 'block';
  username = 'Vivek';
  setTimeout(() => {
    document.getElementById('loader').style.display = 'none';
  }, 1000);
  return 1;
})(username);

console.log(username);

let numbers = [1, 2, 3];
function map2(value) {
  return value + 2;
}
let result2 = numbers.map(map2);
console.log(result2);

function asample() {
  var a = 10;
  var b = 10;
  console.log('Hello', a);
  return function innerFunction() {
    return a + 10;
  };
  // return innerFunction;
}
let a = asample()();
// console.dir(a);
// let output = a();
console.log(a);
console.dir(asample());
