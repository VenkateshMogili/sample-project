// // Access DOM Elements
// const result = document.getElementById("root");
// // console.log(result);
// let paras = document.getElementsByTagName("p")[0].innerHTML;
// // console.log(paras);
// let classes = document.getElementsByClassName("hello")[0];
// // console.log(classes);
// // let singleElement = document.querySelectorAll(".hello");
// let singleElementId = document.querySelectorAll("p");
// console.log(singleElementId);
// // Query Selector

// console.log(document.title);
// console.log(document.scripts);
// console.log(document.links);
// result.innerHTML = "<h1>Hello this is root</h1>";
// console.log(result.attributes[0]);
// result.setAttribute("class", "sample");
// result.setAttribute("title", "This is heading");
// // result.innerText = "<h1>Hello this is root</h1>";

// // Styling with JavaScript
// result.style.color = "red";
// result.style.fontSize = "40px";
// classes.style = "color:blue;font-size:100px;font-family:Arial";

// // Add/Remove Classes
// let heading = document.getElementsByClassName("jsclass")[0];
// heading.classList.add("mystyle");
// heading.classList.add("mystyle2");
// heading.classList.remove("mystyle");
// console.log(heading.classList.length);
// console.log(heading);
// heading.classList.toggle("darktheme", false);

// function setTheme(theme) {
//   document.body.classList.toggle("darktheme");
//   // if (theme === "dark") {
//   //   // heading.classList.add("darktheme");
//   //   document.body.classList.toggle("darktheme");
//   //   // document.body.classList.add("darktheme");
//   //   // document.body.classList.remove("lighttheme");
//   // } else {
//   //   document.body.classList.toggle("lighttheme", true);
//   //   // document.body.classList.remove("darktheme");
//   //   // document.body.classList.add("lighttheme");
//   //   // heading.classList.add("lighttheme");
//   // }
// }

// Create New Elements
let h1 = document.createElement("h1");
h1.innerHTML = "Hello World";
let h2 = document.createElement("h2");
h2.innerHTML = "Hello World 2";
let p = document.createElement("p");
p.innerHTML = "Hello World 2 paragraph";
document.body.appendChild(h1);
document.body.appendChild(h1);
document.body.appendChild(h2);
// document.body.removeChild(h2);
document.body.replaceChild(p, h2);

document.write("<h1>Hello</h1>");
document.write("<h1>Hello</h1>");
document.write("<h1>Hello</h1>");
// Add/Remove Event Listeners

let button = document.createElement("button");
button.innerHTML = "Click here";
document.body.appendChild(button);
button.setAttribute("id", "btn");
function handleClick() {
  alert("clicked");
}
document.getElementById("btn").removeEventListener("click");
document.getElementById("btn").addEventListener("click", handleClick);
