let open = document.getElementById("open");
let close = document.getElementById("close");
let modal = document.getElementById("modal");
//menu action
open.addEventListener("click", () => {
  modal.style.display = "block";
  modal.classList.add("fadeIn");
  modal.classList.remove("fadeOut");
})
//close action
close.addEventListener("click", () => {
  modal.classList.add("fadeOut");
  modal.classList.remove("fadeIn");
  setTimeout(() => {
    modal.style.display = "none";
  }, 400);
})