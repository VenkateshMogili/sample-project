let open = document.getElementById("open");
let close = document.getElementById("close");
let menuList = document.getElementById("menuList");
//menu action
open.addEventListener("click", () => {
  menuList.style.display = "block";
  menuList.classList.add("slideRight");
  menuList.classList.remove("slideLeft");
})
//close action
close.addEventListener("click", () => {
  menuList.classList.add("slideLeft");
  menuList.classList.remove("slideRight");
  setTimeout(() => {
    menuList.style.display = "none";
  }, 400);
})