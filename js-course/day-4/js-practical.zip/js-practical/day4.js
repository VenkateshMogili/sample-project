// const username = window.prompt('Enter your name?', 'Venkatesh');

// console.log('Hello');
// alert('Hello');

// let remove = confirm('Are you sure want to delete?');
// console.log(remove);

// set timeout
// setTimeout(() => {
//   console.log('after 5 second');
// }, 5000);

// setTimeout(() => {
//   fetch('https://jsonplaceholder.typicode.com/users').then((res) => res.json()).then((data) => console.log(data));
// }, 5000);

// let users = fetch('https://jsonplaceholder.typicode.com/todos')
//   .then((res) => res.json())
//   .then((data) => console.log(data));

// console.log(users);
// let expireTime = prompt('Enter how many seconds');
// let timeout = setTimeout(() => {
//   alert('Alarm is ringing');
// }, expireTime * 1000);

// function stopTimeout() {
//   clearTimeout(timeout);
// }
// let count = 10;
// let interval = setInterval(() => {
//   console.log('Hello');
//   let result = '';
//   if (count > 0) {
//     count--;
//   }
//   if (count === 0) {
//     result = 'Timeout';
//     clearInterval(interval);
//   } else {
//     result = count;
//   }
//   document.getElementById('output').innerHTML = result;
// }, 1000);

// navigator
// console.log(navigator.appName);
// console.log(navigator.appCodeName);
// console.log(navigator.appVersion);
// console.log(navigator.clipboard);
// console.log(navigator.geolocation);
// console.log(navigator.platform);
// console.log(navigator.userAgent);

// location
// console.log(location);

// console.log(location.href);
// console.log(location.pathname);
// function gotoLink(url) {
//   // location.assign(url);
//   // location.href = url;
//   location.replace(url);
// }
// // setInterval(reloadPage, 2000);
// function reloadPage() {
//   location.reload();
// }
function goBack() {
  history.back();
}
function goForward() {
  history.forward();
}

// console.log(history.state);

// console.log(screen);
// console.log(screen.availWidth);
// if (screen.availWidth >= 1500) {
//   alert('this is browser');
// } else {
//   alert('this is mobile');
// }

console.log(window);
console.log(window.innerWidth);
console.log(window.innerHeight);

var newWindow;
function openNewWindow() {
  newWindow = open('https://google.com', 'Google Page', 'width=500,height=500');
}

function closeNewWindow() {
  newWindow.close();
}
