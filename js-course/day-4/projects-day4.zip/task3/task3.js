//items
let items = []

//output
let output = document.getElementById("items")

function addTask() {
  let title = prompt("Enter task title");
  let description = prompt("Enter task description");
  items.push({ title, description });
  loadTasks();
}

function loadTasks() {
  let result = '';
  for (let i = 0; i < items.length; i++){
    result += `
    <div class="item">
      <button class="delete" onclick="deleteTask(${i})">Delete</button>
      <h2>${items[i].title}</h2>
      <p>${items[i].description}</p>
    </div>
    `
  }
  output.innerHTML = result;
}

function deleteTask(index) {
  items.splice(index, 1);
  loadTasks();
}