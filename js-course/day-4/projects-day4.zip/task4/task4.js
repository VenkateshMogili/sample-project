//timing
let timer = 0;

var timeInterval;
//output
let output = document.getElementById("output")
function startTimer() {
  timeInterval = setInterval(() => {
    timer++;
    let hours = Math.floor(timer / 3600);
    let minutes = Math.floor((timer - (hours * 3600))/60);
    let seconds = Math.floor(timer % 60);
    let modifiedHours = hours < 10 ? "0" + hours : hours;
    let modifiedMinutes = minutes < 10 ? "0" + minutes : minutes;
    let modifiedSeconds = seconds < 10 ? "0" + seconds : seconds;
    output.innerHTML = modifiedHours + ":" + modifiedMinutes + ":" + modifiedSeconds;
  },1000)
}

function stopTimer() {
  clearInterval(timeInterval)
}

function resetTimer() {
  timer = 0;
  output.innerHTML = "00:00:00";
  stopTimer();
}