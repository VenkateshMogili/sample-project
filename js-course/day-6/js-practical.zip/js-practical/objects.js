var person = {
  firstName: 'venkatesh',
  lastName: 'Mogili',
  address: {street: {substreet: 2}},
  fullName: () => {
    let age = 20;
    return this.person.firstName + '' + age;
  },
};
// console.log(person);

// let user = Object.assign(person, {name: 'venkatesh'});

// console.log(user);

// console.log(person.firstname);
// person['first name'] = 'Vivek';
// console.log(person);

// console.log(person['first name']);

let {firstName: name, address: {street: {substreet}}} = person;
console.log(name, substreet);

console.log(person.fullName());

// for (let element in person) {
//   console.log(person[element]);
// }

console.log(Object.keys(person));
let user = {};
console.log(Object.keys(user).length);
if (Object.keys(user).length > 0) {
  console.log('user is not empty');
} else {
  console.log('user is empty');
}
// console.log(user);
// if (user == true) {
//   console.log('user is empty');
// }
let validate = {name: 'venkatesh', age: 20};
let validate2 = {profession: 'full stack', name: 'vivek'};
console.log(Object.values(validate).includes(null));

console.log(Object.entries(validate));

let result = {...validate, streeet: 1, ...validate2};
console.log(result);

let result2 = JSON.stringify(validate);

console.log(result2);

let result3 = JSON.parse(result2);
console.log(result3);

let messages = localStorage.getItem('messages');
console.log(messages);

let output = JSON.parse(messages);
console.log(output);
delete validate.name;
console.log(validate);
