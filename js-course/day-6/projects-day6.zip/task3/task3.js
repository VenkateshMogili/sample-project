//questions
const questions = [
  {
    id: 1,
    question: "Question 1",
    options: [
      "option 1",
      "option 2",
      "option 3",
      "option 4"
    ],
    answer: "option 1"
  },
  {
    id: 2,
    question: "Question 2",
    options: [
      "option 1",
      "option 2",
      "option 3",
      "option 4"
    ],
    answer: "option 2"
  },
  {
    id: 3,
    question: "Question 3",
    options: [
      "option 1",
      "option 2",
      "option 3",
      "option 4"
    ],
    answer: "option 3"
  }
]

//current question
let currentQuestion = 1;
let totalQuestions = 3;
let score = 0;

//output
let output = document.getElementById("output")

//loadQuestions
function loadQuestions() {
  let options = '';
  questions[currentQuestion - 1].options.map(option => {
    options += `
    <p>${option}</p>
    <button onclick="selectAnswer('${option}')">Select Answer</button>
    `
  })

  let result = `
  <h2>${questions[currentQuestion - 1].question}</h2>
    ${options}
    <br /><br />
    <p>Question ${currentQuestion}/${totalQuestions}</p>
  `;
  output.innerHTML = result;
}

//select answer
function selectAnswer(answer) {
  if (questions[currentQuestion - 1].answer === answer) {
    score += 1;
  }
  if (currentQuestion < 3) {
    currentQuestion += 1;
    loadQuestions()
  } else if (currentQuestion === 3) {
    output.innerHTML = "<h1>Quiz Completed! Your Score " + score + "</h1>";
  }
}