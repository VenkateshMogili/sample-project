//messages
let messages = [];

//messages output
let output = document.getElementById("messages");
let message = document.getElementById("message")
//load messages
function loadMessages() {
  let finalResult = '';
  messages.length > 0 ? messages.map((message, index) => {
    //finalResult += `
    //<p class="${message.sender === "Venkatesh" ? 'sent' : 'received'}">${message.text}</p>
    //`
    finalResult += `
    <p class="${index % 2 === 0 ? 'sent' : 'received'}">${message.text}
    <span class='datemessage'>${moment(message.date).format("DD-MM-YYYY HH:mm:ss A")}</span></p>
    `
  }) : finalResult += `<h2>Start Conversation</h2>`;
  output.innerHTML = finalResult;
}

//send message
function sendMessage() {
  let messageValue = message.value;
  if (messageValue.trim().length > 0) {
    let newMessage = {
      text: messageValue,
      date: new Date()
    };
    messages.push(newMessage);
    message.value = ""
    loadMessages();
  } else {
    alert("Please enter valid message")
  }
}