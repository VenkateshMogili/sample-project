// let today = new Date();
// console.log(today);

// let yesterday = new Date(2021, 05, 14);
// console.log(yesterday);

// let tomorrow = new Date("June 15, 2021");
// console.log(tomorrow);

// let twodaysback = new Date(1623581305375);
// console.log(twodaysback);

// console.log(twodaysback.toDateString());
// console.log(twodaysback.toISOString());

// console.log(today.getFullYear());
// console.log(today.getMonth());
// console.log(today.getDate());
// console.log(today.getHours());
// console.log(today.getMinutes());
// console.log(today.getSeconds());
// console.log(today.getMilliseconds());
// console.log(today.getTime());
// let days = ["Sunday", "Wednessday", "Thursday", "Friday", "Saturday", "Sunday", "Monday"];
// console.log(days[today.getDay()]);
// console.log(Date.now());

// let expiredate = new Date("2021-06-13T24:00:00").getTime();

// let timer = setInterval(() => {
//   let now = new Date().getTime();
//   let difference = expiredate - now;
//   let seconds = Math.floor((difference / 1000) % 60),
//     minutes = Math.floor((difference / (1000 * 60)) % 60),
//     hours = Math.floor((difference / (1000 * 60 * 60)) % 24),
//     days = Math.floor(difference / (24 * 60 * 60 * 1000));
//   let dd = days < 10 ? "0" + days + " Days" : days + " Days";
//   let hh = hours < 10 ? "0" + hours + " Hours" : hours + " Hours";
//   let mm = minutes < 10 ? "0" + minutes + " Minutes" : minutes + " Minutes";
//   let ss = seconds < 10 ? "0" + seconds + " Seconds" : seconds + " Seconds";

//   let result = dd + " " + hh + " " + mm + " " + ss;
//   document.getElementById("output").innerHTML = result;
//   document.getElementById("output").style.fontSize = "26px";
//   document.getElementById("output").style.color = "blue";
//   if (difference <= 0) {
//     clearInterval(timer);
//   }
//   // main logic
// }, 1000);

// let initialTime = new Date("2021-06-12T24:00:00").getTime();

// let timer = setInterval(() => {
//   let now = new Date().getTime();
//   let difference = now - initialTime;
//   console.log(difference);
//   let seconds = Math.floor((difference / 1000) % 60),
//     minutes = Math.floor((difference / (1000 * 60)) % 60),
//     hours = Math.floor((difference / (1000 * 60 * 60)) % 24),
//     days = Math.floor(difference / (24 * 60 * 60 * 1000));
//   let dd = days < 10 ? "0" + days + " Days" : days + " Days";
//   let hh = hours < 10 ? "0" + hours + " Hours" : hours + " Hours";
//   let mm = minutes < 10 ? "0" + minutes + " Minutes" : minutes + " Minutes";
//   let ss = seconds < 10 ? "0" + seconds + " Seconds" : seconds + " Seconds";

//   let result = dd + " " + hh + " " + mm + " " + ss;
//   document.getElementById("output").innerHTML = result;
//   document.getElementById("output").style.fontSize = "26px";
//   document.getElementById("output").style.color = "blue";
//   if (difference <= 0) {
//     clearInterval(timer);
//   }
//   // main logic
// }, 1000);

// let name = "Venkatesh Mogili is a full stack Mogili developer developer.";
// // console.log(name.length);
// // let result = name.replace(/ /g, "+");
// // console.log(result);

// // function searchUser() {
// //   let username = document.getElementById("username").value;
// //   console.log(name.indexOf(/ /g));
// // }

// let output = name.slice(0, -10);
// console.log(output);

// let output2 = name.substring(0, 10);
// console.log(output2);

// let output3 = name.substr(10, 20);
// console.log(output3);

// // let output4 = name.replaceAll("Mogili", "M");
// let output4 = name.replace(/Mogili/g, "M");
// console.log(output4);

// console.log(Math.PI);
// let number = -4.4;
// console.log(Math.round(number));
// console.log(Math.floor(number));
// console.log(Math.ceil(number));
// console.log(Math.trunc(number));
// console.log(Math.pow(5, 2));
// console.log(Math.sqrt(25));
// console.log(Math.abs(number));
// let minValue = Math.min(1, 2, 3, 4, 5);
// let maxValue = Math.max.apply(null, [1, 2, 3, 4, 5]);
// console.log(maxValue);

// let pictures = ["1.png", "2.png", "3.png"];
// console.log(Math.random());

// let randomValue = pictures[Math.floor(Math.random() * 3 + 1) - 1];
// console.log(randomValue);

// try {
//   throw "Something went wrong";
// } catch (error) {
//   console.log(error);
// } finally {
//   console.log("Final Output");
// }

$(document).ready(function() {
  $("#show").click(function() {
    $("#output").show();
  });
  $("#hide").click(function() {
    $("#output").hide();
  });
  $("#toggle").click(function() {
    // $("#output").slideToggle();
    // $("#output").delay(1000).fadeToggle();
    // $("#output").animate({width: 100, height: 100, background: "black"});
    // $("#output").animate({width: 200, height: 300});
    // $(this).hide();
    // $(".form").toggle();
    // $("p:first").toggle();
  });
  $.ajax({
    url: "https://jsonplaceholder.typicode.com/users/1",
    type: "PUT",
    data: JSON.stringify({name: "Venkatesh"}),
    success: function(result, error) {
      console.log(result);
    },
  });
});
