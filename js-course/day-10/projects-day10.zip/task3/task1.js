let generate = document.getElementById("generate");
let copy = document.getElementById("copy");
let password = document.getElementById("password");
let randomPassword = "";
generate.addEventListener("click", () => {
  randomPassword = Math.random().toString(36).slice(2);
  password.innerHTML = randomPassword;
})
function copyToclipboard() {
  var textArea = document.createElement("textarea");
  textArea.value = randomPassword;
  document.body.appendChild(textArea);
  textArea.focus();
  textArea.select();
  try {
    document.execCommand('copy');
    alert("Copied Successfully!")
  } catch (err) {
    alert("unable to copy!")
  }
  document.body.removeChild(textArea);
}