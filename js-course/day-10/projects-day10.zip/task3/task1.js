//generate random password
let randomPassword = "";
let password = document.getElementById("password");
const generatePassword = () => {
  //let strNumbers="ABCDabcd12@#$!@#"
  randomPassword = Math.random().toString(36).slice(2);
  password.innerHTML = randomPassword;
}
//copy to clipboard
function copyToClipboard() {
  let textArea = document.createElement("textarea");
  textArea.value = randomPassword;
  document.body.appendChild(textArea);
  textArea.focus();
  textArea.select();
  try {
    document.execCommand("copy");
    alert("Copied to clipboard successfully!")
  } catch {
    alert("Unable to copy!")
  }
  document.body.removeChild(textArea);
}