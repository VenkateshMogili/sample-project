$(document).ready(function () {
  $("li.q").on("click", function () {
    $(this).next().slideToggle(500)
      .siblings("li.a").slideUp();
  })
})