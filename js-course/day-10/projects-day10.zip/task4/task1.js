//document
$(document).ready(function () {
  //on click
  $("li.q").click(function () {
    //slide toggle
    $(this).next().slideToggle(500)
      .siblings("li.a").slideUp();
    //slide up
  })
})
