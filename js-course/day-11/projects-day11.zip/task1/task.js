const quotes = [
  { quote: "Try again and again until you reach your goal.", author: "Swami Vivekananda" },
  { quote: "Practice Makes Anything Perfect", author: "Anonymous" },
  { quote: "Once the time is gone, it never come back", author: "Anonymous" },
];

let quoteResult = document.getElementById("quote");
let authorResult = document.getElementById("author");
function generateQuote() {
  let randomQuote = quotes[Math.floor(Math.random() * 3) + 0];
  let { quote, author } = randomQuote;
  quoteResult.innerHTML = quote;
  authorResult.innerHTML = author;
}
