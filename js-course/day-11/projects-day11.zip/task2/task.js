let person = {
  name: {
    first: "",
    last: ""
  },
  location: {
    street: {
      name: "",
      number: ""
    }
  },
  phone: "",
  email: "",
  picture: {
    large: "",
    thumbnail: ""
  }
}

//output
let output = document.getElementById("user");
function generatePerson() {
  //get api
  let url = "https://randomuser.me/api"
  fetch(url).then(res => res.json())
    .then(data => {
      let newPerson = data.results[0];
      console.log(newPerson)
      let { picture, name, location, phone, email } = newPerson;
      let { large } = picture;
      let { first, last } = name;
      let { street } = location;
      let { name: streetName, number } = street;
      output.innerHTML = `
  <img src="${large}" alt="">
      <p>First Name: <b>${first}</b></p>
      <p>Last Name: <b>${last}</b></p>
      <p>Location: <b>${streetName}, ${number}</b></p>
      <p>Phone: <b>${phone}</b></p>
      <p>Email: <b>${email}</b></p>
  `
    })
}