export const username = "Venkatesh";
export const age = 20;

export default function helloWorld() {
  console.log("Hello world!");
}
