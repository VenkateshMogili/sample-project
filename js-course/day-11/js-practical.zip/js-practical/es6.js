// let car = {
//   color: "blue",
//   name: "Tesla",
// };
// console.log(Object.keys(car));
// console.log(Object.values(car));
// console.log(Object.entries(car));

// let orderId = "5";
// let orderId = "order_";
// console.log(orderId.padStart(10, 0));
// console.log(orderId.padEnd(10, 0));

// console.log(Math.pow(5, 2));
// console.log(5 ** 2);
// let x = 5;
// // let result = x ** 2;
// x **= 2;
// console.log(x);

// let users = ["venkatesh", "vivek10"];
// console.log(users.includes("vivek"));

let name = "23789";
// let check = new RegExp(/^\d/gim);
// let check = new RegExp(/[a-zA-Z]/g);
let check = new RegExp(/[0-9]/g);
// console.log(check.test(name));
console.log(check.exec(name));
console.log(check.toString());
// let longText = "Hello world Hello";
// let result = longText.replace(/Hello/g, "Hi");
// console.log(result);
