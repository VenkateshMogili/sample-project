"use strict";
// var a = 10;
// console.log(a);

// let person = {
//   firstName: "Venkatesh",
//   get getFirstName() {
//     console.log(this.firstName);
//     return this.firstName;
//   },
//   set setFirstName(name) {
//     this.firstName = name;
//     return this.firstName;
//   },
// };
// person.getFirstName;
// person.setFirstName = "Vivek";
// person.getFirstName;

// person["lastName"] = "Mogili";
// console.log(person);

// Object.defineProperty(person, "age", {
//   value: 20,
// });
// console.log(person);

// function helloWorld(age = 0, years, ...remaining) {
//   console.log(age);
//   console.log(years);
//   console.log(remaining);
// }

// helloWorld(20, 30, 40, 50);
// console.log(Math.trunc(-4.3));
// console.log(Math.trunc(4.3));
// console.log(Math.sign(-4));
// console.log(Math.sign(4));
// console.log(Math.sign(0));
// console.log(Math.cbrt(27));
// console.log(Math.log2(2));
// console.log(Math.log10(10));
// Number
// console.log(Number.EPSILON);
// console.log(Number.MIN_SAFE_INTEGER);
// console.log(Number.MAX_SAFE_INTEGER);
// console.log(Number.isInteger("10"));
// console.log(Number.isSafeInteger(-9007199254740990));

// console.log(10 / 0);
// let finite = 10 / 1;
// console.log(isFinite(finite));
// console.log(isNaN(10));
