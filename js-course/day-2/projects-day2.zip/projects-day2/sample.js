console.log("Hello");
console.log("Hi");
setTimeout(() => {
  console.log("Final")
}, 1000);
console.log("Bye");