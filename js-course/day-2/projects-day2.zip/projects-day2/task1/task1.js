function findDay() {
  let input = prompt("Enter the date");
  let days = ["Sunday", "Monday", "Tuesday", "Wednessday", "Thursday", "Friday", "Saturday"];
  let day = days[new Date(input).getDay()];
  document.getElementById("output").innerHTML = day;
}