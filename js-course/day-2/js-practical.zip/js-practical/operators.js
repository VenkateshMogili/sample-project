// let a = 10;
// let b = "10";

// console.log(a==b)
// console.log(a === b)


let a = true;
let b = false;
let c = true;

if (a && b && c) {
  console.log("matched")
}

if (a && !b && c) {
  console.log("matched")
}

// let getName = prompt("Enter your name");
// console.log(getName);

// let confirmUser = confirm("Are you sure want to delete?");
// console.log(confirmUser);


console.log(window);