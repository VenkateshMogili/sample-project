let a = 10;
let name = "venkatesh";
let username = "venkatesh";

// console.log(name===username)
console.log(a);
console.log(name)

let user3 = { year: 2021, address: { street: { dno:""}} }
let user4 = { ...user3 };
let user = { year: 2021,address:{street:"sample"} };//1001
let customer = JSON.parse(JSON.stringify(user));//1002
console.log(user);
console.log(customer);

console.log(user === customer)
customer.year = 2022;

console.log(user);


// functions

function getUser() {
  return "Venkatesh"
};

getUser.username = "Vivek";
console.log(getUser())
console.log(getUser.username)
console.log(getUser.name)
console.log(getUser.arguments)


console.log(5 ** 2);

let bb = 5;
console.log(bb++);
console.log(bb--);
console.log(bb);


let username5 = "venkatesh";
let number = 20;
username5 += number;
console.log(username5);


