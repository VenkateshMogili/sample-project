//items
let projects = [
  {
    title: "Project 1",
    description: "This is project 1",
    link:"1.html"
  },
  {
    title: "Project 2",
    description: "This is project 2",
    link: "2.html"
  },
  {
    title: "Project 3",
    description: "This is project 3",
    link: "3.html"
  },
  {
    title: "Project 4",
    description: "This is project 4",
    link: "4.html"
  },
  {
    title: "Project 5",
    description: "This is project 5",
    link: "5.html"
  },
  {
    title: "Project 6",
    description: "This is project 6",
    link: "6.html"
  }
]

//output
let output = document.getElementById("items");
function loadProjects() {
  let result = '';
  for (let i = 0; i < projects.length; i++){
    result +=`
    <div class="item">
      <h1>${projects[i].title}</h1>
      <p>${projects[i].description}</p>
      <a href="${projects[i].link}" target="_blank"><button>Learn</button></a>
    </div>`
  }
  output.innerHTML = result;
}