//take inputs
let username = document.querySelector("#username");
let password = document.querySelector("#password");

//output
let output = document.querySelector("#output")

function validateEmail(email) {
  const re = /^[a-z0-9][a-z0-9-_\.]+@([a-z]|[a-z0-9]?[a-z0-9-]+[a-z0-9])\.[a-z0-9]{2,10}(?:\.[a-z]{2,10})?$/;
  return re.test(String(email).toLowerCase());
}

const login = (e) => {
  e.preventDefault();
  if (username.value.length > 0 && validateEmail(username.value) && username.value === "admin@gmail.com" && password.value === "admin") {
    output.innerHTML = "Logged in Successfully!";
    window.location.href = "/task1/dashboard.html";
  } else {
    output.innerHTML="Logged in failed!"
  }
}