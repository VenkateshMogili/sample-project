// conditional
let a = '10';
if (typeof a != 'number') {
  console.log('a is greater than 10');
}
if (a === '10') {
  console.log('a is 10');
} else {
  console.log('a is not a number');
}

// Ternary

let b = 5;
let c = 10;
let users = [1, 2, 3];
let result = b > 5 ? (c === 10 ? 'C is 10' : 'Greater than or equal to 5') : 'None';
console.log(result);

let output = users.length > 0 ? 'Users List' : 'No Users Found!';
console.log(output);

// Switch statements
let type = 'ADD_USER';
switch (type) {
  case 'add_USER':
    console.log('Adding User');
    break;
  case 'EDIT_USER':
    console.log('Editing User');
    break;
  default:
    console.log('No case matched');
}

// For Loop
let cars = ['A', 'B', 'C'];
text = '';
for (let i = 0; i < cars.length; i++) {
  text += cars[i] + '<br/>';
}

// for in
let user = {name: 'venkatesh', age: 20, profession: 'full stack'};
for (let key in user) {
  console.log(key);
  console.log(user[key]);
}
let elements = [1, 2, 3];
for (let element in elements) {
  console.log(element);
  text += element + '<br/>';
}

// for of
let elementss = [1, 2, 3];
for (let element of elements) {
  console.log(element);
  // text += element + '<br/>';
}

let userss = [{name: 'vivek'}, {name: 'venkatesh'}];
for (let user of userss) {
  console.log(user);
  // text += element + '<br/>';
}
// document.getElementById('output').innerHTML = text;
// While Loop
let z = 0;
// while (z > 0) {
//   console.log(z);
//   z--;
// }

// for (; z > 0;) {
//   console.log(z);
//   z--;
// }

// Do-While Loops
do {
  console.log('first statment');
  z--;
} while (z > 0);

// Nested Loops

// let people = [[1, 2, 3], [2], [3]];
// for (let i = 0; i < people.length; i++) {
//   for (let j = 0; j < people[i].length; j++) {
//     console.log(people[i][j]);
//   }
// }

// Break and Continue
// for (let i = 0; i < 5; i++) {
//   if (i === 3) {
//     break;
//   }
//   console.log(i);
// }

// for (let i = 0; i <= 5; i++) {
//   if (i === 3) {
//     continue;
//   }
//   console.log(i);
// }

// Exercise on Conditional and Loops
// Take inputs from user (username, password and  number of users required)
// If password is wrong then again ask user to enter again.
// If correct password, then ask user to enter the details for each user (Name, Role, Profession)
// Loop through list of users, If particular user has userType Admin then change the userRole as 1 otherwise 0
// If user profession is full stack then ask user to enter experience.

// Finally, after entering all the users data display it in a table format with delete option.

// let finalUsers = [{name: 'venkatesh'}];
// for (let user of finalUsers) {
//   let {name} = user;
//   console.log(name);
// }
// let success = false;
// let outputs = '<table><tr><th>Name</th><th>Role</th><th>Profession</th><th>Experience</th></tr>';
// while (!success) {
//   let username = prompt('Username');
//   let password = prompt('Password');
//   if (username === 'admin' && password === 'admin') {
//     console.log('success');
//     const numberOfUsers = prompt('Please enter number of users required');
//     let finalUsers = [];
//     for (let i = 0; i < numberOfUsers; i++) {
//       let name = prompt('Enter your name');
//       let role = prompt('Enter your role');
//       let profession = prompt('Enter your profession');
//       role = role === 'admin' ? 1 : 0;
//       let experience = 0;
//       if (profession === 'full stack') {
//         experience = prompt('Enter your number of years experience');
//       }
//       let finalUser = {name, role, profession, experience};
//       finalUsers.push(finalUser);
//     }
//     for (let user of finalUsers) {
//       let {name, role, profession, experience} = user;
//       outputs +=
//         '<tr><td>' + name + '</td><td>' + role + '</td><td>' + profession + '</td><td>' + experience + '</td></tr>';
//     }
//     success = true;
//   } else {
//     console.log('fail');
//   }
// }
// outputs += '</table>';
// document.getElementById('output').innerHTML = outputs;

let types = 6;
switch (types) {
  case 5:
  case 6:
    console.log('Adding User');
    break;
  case 7:
    console.log('Editing User');
    break;
  default:
    console.log('No case matched');
}

let str = 'JavaScript';

// for (let character of str) {
//   console.log(character);
// }

for (let character in str) {
  console.log(str[character]);
}
