const blogs = [
  {
    id: 1,
    title: "sample",
    completed: true
  }
];
let output = document.getElementById("output")
class Todo {
  addTodo(todo) {
    blogs.push(todo);
  }
  updateTodo(id) {
    let findIndex = blogs.findIndex(todo => todo.id === id);
    let updatedTodo = { ...blogs[findIndex], completed: !blogs[findIndex].completed }
    blogs[findIndex] = updatedTodo;
  }
  deleteTodo(id) {
    let findIndex = blogs.findIndex(todo => todo.id === id);
    blogs.splice(findIndex, 1);
  }
}

function addTodo() {
  let title = document.getElementById("taskInput");
  let newId = blogs.length > 0 ? blogs[blogs.length - 1].id + 1 : 1;
  let newTodo = new Todo();
  newTodo.addTodo({ id: newId, title: title.value, completed: false })
  showTodos();
}

function showTodos() {
  let resultOutput = "";
  blogs.map((todo) => {
    resultOutput += `<div class="item">
      <input type="checkbox" ${todo.completed === true ? "checked" : ""}  onchange="updateTodos(${todo.id})" />
      <p style="${todo.completed ? 'text-decoration:line-through' : ''}">${todo.title}</p>
      <button id="delete" onclick="deleteTodos(${todo.id})">X</button>
    </div>`;
  });
  output.innerHTML = resultOutput;
}
function deleteTodos(id) {
  let todo = new Todo();
  todo.deleteTodo(id);
  showTodos();
}
function updateTodos(id, todo) {
  let todoObj = new Todo();
  todoObj.updateTodo(id);
  showTodos();
}