const blogs = [
  {
    id: 1,
    title: "sample",
    completed: false
  },
  {
    id: 2,
    title: "sample 2",
    completed: true
  }
];

let output = document.getElementById("blogs");

function showBlogs() {
  let result = "";
  blogs.map((blog) => {
    result += `
    <div class="blog">
      <input type="checkbox" ${blog.completed === true ? "checked" : ""} onchange="updateBlog(${blog.id})" />
      <p style="${blog.completed === true ? 'text-decoration:line-through' : ''}">${blog.title}</p>
      <button onclick="deleteBlog(${blog.id})">X</button>
    </div>
    `
  });
  output.innerHTML = result;
}
showBlogs();

class Blog {
  addBlog(blog) {
    blogs.push(blog)
  }

  updateBlog(id) {
    let findIndex = blogs.findIndex(blog => blog.id === id);
    blogs[findIndex] = { ...blogs[findIndex], completed: !blogs[findIndex].completed }
  }

  deleteBlog(id) {
    let findIndex = blogs.findIndex(blog => blog.id === id);
    blogs.splice(findIndex, 1);
  }
}

let blog = new Blog();
function addBlog() {
  let title = document.getElementById("blogText");
  if (title.value.length > 0) {
    let newId = blogs.length > 0 ? blogs[blogs.length - 1].id + 1 : 1;
    blog.addBlog({ id: newId, title: title.value, completed: false });
    showBlogs();
    title.value = "";
  } else {
    alert("Please fill the input!")
  }
}

function deleteBlog(id) {
  blog.deleteBlog(id);
  showBlogs();
}

function updateBlog(id) {
  blog.updateBlog(id);
  showBlogs();
}