let laptops = [
  {
    id: 1,
    name: "Dell",
    price: "$100"
  },
  {
    id: 2,
    name: "HP",
    price: "$100"
  },
  {
    id: 3,
    name: "Apple",
    price: "$100"
  },
  {
    id: 4,
    name: "Acer",
    price: "$100"
  }
];
let cart = [];

let output = document.getElementById("laptops");

function showLaptops() {
  let result = "";
  laptops.map(({ name, price, id }) => {
    result += `
    <div class="laptop">
      <img src="laptop.jpg" alt="">
      <div class="laptopdetails">
        <p class="name">${name}</p>
        <p class="price">${price}</p>
      </div>
      <button onclick="addToCart(${id})">Add To Cart</button>
    </div>
    `
  })
  output.innerHTML = result;
}
showLaptops();

class Laptop {
  addToCart(id) {
    if (!cart.includes(id)) {
      cart.push(id);
    } else {
      alert("Already added")
    }
  }
}

let laptopInstance = new Laptop();
function addToCart(id) {
  laptopInstance.addToCart(id);
  let cartOutput = document.getElementById("cart");
  cartOutput.innerHTML = "Cart (" + cart.length + ")";
}