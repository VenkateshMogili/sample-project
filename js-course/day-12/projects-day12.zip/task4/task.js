const laptops = [
  {
    name: "Dell",
    price: "$100",
  },
  {
    name: "HP",
    price: "$100",
  },
  {
    name: "Apple",
    price: "$100",
  },
  {
    name: "Acer",
    price: "$100",
  }
];
let cart = [];
let cartId = document.getElementById("cart")
let laptopsOutput = document.getElementById("laptops")
class Laptop {
  addToCart(item) {
    if (!cart.includes(item)) {
      cart.push(item);
    } else {
      alert("Already added")
    }
  }
}

let laptopObj = new Laptop();

function addToCart(index) {
  laptopObj.addToCart(laptops[index]);
  showCart();
}
function showCart() {
  cartId.innerHTML = "Cart (" + cart.length + ")";
}
function showLaptops() {
  let result = "";
  laptops.map((laptop, index) => {
    result += `
     <div class="laptop">
      <img src="laptop.jpg" alt="">
      <div class="laptopdetails">
        <p class="name">${laptop.name}</p>
        <p class="price">$${laptop.price}</p>
      </div>
      <button class="buy" onclick="addToCart(${index})">Add To Cart</button>
    </div>
    `
  })
  laptopsOutput.innerHTML = result;
}
showLaptops();