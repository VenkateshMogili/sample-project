class Person {
  constructor(name, designation) {
    this.name = name;
    this.designation = designation;
  }
  learn() {
    console.log("Learning");
  }
  eat() {
    console.log("Eating");
  }
  sleep() {
    console.log("sleeping");
  }
}

class Developer extends Person {
  constructor(name, designation, companyName) {
    super(name, designation);
    this.companyName = companyName;
  }
  coding() {
    console.log("JavaScript coding...");
  }
}
class Dancer extends Person {
  constructor(name, designation, schoolName) {
    super(name, designation);
    this.schoolName = schoolName;
  }
  dancing() {
    console.log("Classical dancing...");
  }
}

let venkatesh = new Developer("Venkatesh", "Fullstack", "Youtube");
let venkatesh2 = new Dancer("Venkatesh", "Fullstack", "Dancing school");
console.log(venkatesh);
console.log(venkatesh2);
venkatesh.eat();
