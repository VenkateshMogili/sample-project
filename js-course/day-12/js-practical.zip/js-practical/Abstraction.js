class Bank {
  constructor(name, account_number, account_type) {
    var name = name;
    this.account_number = account_number;
    var account_type = account_type;
    this.getName = () => {
      return name;
    };
    this.setName = (newName) => {
      name = newName;
    };
  }
}

let sbi = new Bank("SBI", 12345, "Savings");

console.log(sbi);
console.log(sbi.getName());
sbi.setName("ICICI");
console.log(sbi.getName());
console.log(sbi.account_number);
