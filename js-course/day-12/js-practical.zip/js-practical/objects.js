// let mobile = {name: "Redmi"};
// console.log(mobile.name);

// let mobile = Object.create({});
// mobile.name = "Redmi";
// console.log(mobile);

// function Mobile() {
//   return "mobile";
// }
// let mobile = new Mobile();
// mobile.name = "Redmi";
// console.log(mobile);

class Mobile {}
let mobile = new Mobile();
mobile.name = "Redmi";
console.log(mobile);
console.log(typeof mobile);
