class User {
  constructor(username, id) {
    this.username = username;
    this.id = id;
  }
  editUser(username) {
    this.username = username;
  }
}
let users = [];

function addNewUser() {
  let id = users.length > 0 ? users[users.length - 1].id + 1 : 1;
  let user = new User("Venkatesh", id);
  users.push(user);
  getAllUsers();
}
function deleteUser(id) {
  let finalUsers = users.filter((user) => user.id != id);
  users = finalUsers;
  getAllUsers();
}
function editUser(id, data) {
  let user = new User("Venkatesh", id);
  let findIndex = users.findIndex((user) => user.id === id);
  user.editUser(data);
  users[findIndex].username = user.username;
  getAllUsers();
}
function getAllUsers() {
  let result = "";
  if (users.length > 0) {
    users.forEach((user) => {
      result += `
    <div class="item">
      <img src="user.png" width="100" height="100"/>
      <br/>
      <small>${user.username}</small>
      <br/>
      <button class="btn bg-blue" onclick="deleteUser(${user.id})">Remove</button>
      <br/>
      <button class="btn bg-black" onclick="editUser(${user.id},'vivek')">Edit</button>
    </div>`;
    });
  } else {
    result += "No Users Found!";
  }
  document.querySelector(".items").innerHTML = result;
}
