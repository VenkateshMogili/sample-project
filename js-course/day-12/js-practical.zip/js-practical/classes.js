class Mobile {
  constructor(name, color) {
    this.name = name;
    this.color = color;
    this.state = {
      name: "Venkatesh",
      age: 20,
    };
  }
  setState(newObject) {
    console.log(this.state.name);
    this.state = {...this.state, ...newObject};
    console.log("Calling");
  }
  calling() {
    console.log(this.state.name);
    console.log("Calling");
  }
  getName() {
    return this.name;
  }
  setName(newName) {
    this.name = newName;
  }
}

let redmi = new Mobile("Redmi Note 10", "Black");
console.log(redmi.color);
let iphone = new Mobile("Iphone", "Blue");
console.log(iphone.getName());
iphone.setName("Iphone 10");
console.log(iphone.name);
console.log(iphone.state.name);
iphone.calling();
iphone.setState({name: "Vivek"});
console.log(iphone.state);
