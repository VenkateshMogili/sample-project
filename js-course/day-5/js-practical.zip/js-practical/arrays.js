// let userIds = ['abcd1', 'dbcs2', 'abcd2'];

// console.log(userIds);

// let users = ['venkatesh', 20, 'vivek', 30];

// console.log(users);

// let multipleArrays = [
//   'venkatesh',
//   20,
//   {name: 'vivek'},
//   function running() {
//     return 1;
//   },
// ];

// console.log(multipleArrays);
// console.log(multipleArrays[3]());

// let multi = [[1, 2], [2, 3]];
// console.log(multi);
// console.log(multi[0]);

// let newArray = new Array(3);
// newArray[0] = 1;
// console.log(newArray);

// let values = [1, 2, 3];
// values[100] = 99;
// console.log(values);
// console.log(values[3]);

// let books = [1, 2, 3];
// books.push(4);
// books.push(5);
// books.pop();
// books.unshift(10);
// books.unshift(11);
// books.shift();
// books.shift();

// console.log(books);
// console.log(books.toString());

// let finalString = books.toString();
// let splittedString = finalString.split(',').join('+');
// console.log(splittedString);
// // let splittedString = JSON.parse('[' + finalString + ']');
// // console.log(splittedString);
// books.splice(1, 2);
// books.splice(1, 0, 1, 2, 3);
// console.log(books);

// let users = ['a', 'b', 'c'];
// let users2 = ['a', 'b', 'c'];

// let result = books.concat(users).concat(users2);
// console.log(result);

// let subArray = result.slice(1, 5);
// console.log(subArray);

// let copyArray = result.slice();
// copyArray[0] = 10;
// console.log(copyArray);

// let nonSorted = [10, 20, 5, 1, 8, 2, 4];
// console.log(nonSorted);

// let output = nonSorted.sort();
// let output2 = nonSorted.slice().reverse();
// console.log(output);
// console.log(output2);
// let customSort = nonSorted.sort((a, b) => {
//   if (a < b) {
//     return -1;
//   } else if (a > b) {
//     return 1;
//   }
//   return 0;
// });

// console.log(customSort);

// destructuring
let users = ['10venkatesh', 20, 30, 40, 50, 60, 10];
// let [a, , ...remaining] = users;
// // console.log(age);
// // console.log(enrolls);
// // console.log(users[0]);
// // console.log(users[0]);
// // console.log(users[0]);
// // console.log(users[0]);
// console.log(a);
// // console.log(b);
// console.log(remaining);
// let output = [];
// let result = users.forEach((element, index, backupUsers) => {
//   console.log(element);
//   let obj = {};
//   obj.value = element;
//   obj.label = element;
//   output.push(obj);
// });
// console.log(result);

// console.log(output);

// let output2 = users.map((element, index, backupUsers) => {
//   console.log(element);
//   let obj = {};
//   obj.value = element;
//   obj.label = element;
//   return obj;
// });
// console.log(output2);

// let output3 = users.filter((element, index, backupUsers) => {
//   if (element != 10) {
//     return element;
//   }
// });
// console.log(output3);

// let output4 = users.find((element, index, backupUsers) => {
//   if (element == 10) {
//     return element;
//   }
// });
// console.log(output4);

// let output5 = users.findIndex((element, index, backupUsers) => {
//   if (element == 10) {
//     return element;
//   }
// });
// console.log(output5);
// let sum = 0;
// let output6 = users.reduce((prevValue, currentValue) => {
//   return prevValue + currentValue;
// }, 10);
// console.log(output6);

// let valid = users.every((element, index, array) => element >= 10);
// console.log(valid);

// let valid2 = users.some((element, index, array) => element > 10);
// console.log(valid2);

let matched = users.filter((element) => element.toString().indexOf('venkatesh') !== -1);

console.log(matched);

let books = [1, 2, 3];
let book2 = [4, 5, 6];
console.log([...books, 10, 20, ...book2]);

let matched2 = users.includes('10venkatesh');
console.log(matched2);

let todos = [{title: 'Sample'}, {title: 'vivek'}];
function allTodos() {
  let result = '';
  todos.forEach((todo, index) => {
    result += `<p style="text-align: left;">${todo.title}
    <button onclick="deleteTask(${index})" style="float:right">Delete</button></p>`;
  });

  document.getElementById('tasks').innerHTML = result;
}
function addTodo() {
  let title = document.getElementById('title').value;
  todos.push({title});
  document.getElementById('title').value = '';
  allTodos();
}

function deleteTask(indexx) {
  console.log(indexx);
  let result = todos.filter((element, index) => index !== indexx);
  todos = result;
  console.log(todos);
  allTodos();
}
