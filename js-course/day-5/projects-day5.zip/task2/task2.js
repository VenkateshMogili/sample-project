//notes
let notes = [];

//output
let output = document.getElementById("output");
let selectedIndex = null;
//load notes
function loadNotes(filterItems = notes) {
  let finalNotes = '';
  filterItems.length > 0 ? filterItems.map((item, index) => {
    finalNotes += `
    <div class="item">
      <h3>${item.title}</h3>
      <div class="controls">
        <button onclick="editNote(${index})">Edit</button>
        <button onclick="deleteNote(${index})">Delete</button>
      </div>
    </div>
    `
  }) : finalNotes += `<h2>No Notes Found!</h2>`;
  output.innerHTML = finalNotes;
}

//add/edit note
function addEditNote() {
  let inputValue = document.getElementById("inputValue");
  let newNotes = { title: inputValue.value };
  if (selectedIndex != null) {
    //edit
    notes[selectedIndex] = newNotes;
    selectedIndex = null;
  } else {
    //add
    notes.push(newNotes);
  }
  inputValue.value = ""
  loadNotes();
}

//edit note
function editNote(index) {
  let filterItem = notes[index];
  let inputValue = document.getElementById("inputValue");
  inputValue.value = filterItem.title;
  selectedIndex = index;
}

//delete note
function deleteNote(index) {
  notes.splice(index, 1);
  loadNotes();
}

//search notes
function searchNotes() {
  let searchInput = document.getElementById("searchInput")
  let filteredNotes = notes.filter(note => note.title.toLowerCase().indexOf(searchInput.value.toLowerCase()) !== -1);
  loadNotes(filteredNotes)
}
//sort by
function sortBy() {
  let sortedItems = notes.reverse();
  loadNotes(sortedItems);
}