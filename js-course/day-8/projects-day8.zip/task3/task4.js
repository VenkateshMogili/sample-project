//messages
let messages = [];

//messages output
let output = document.getElementById("messages");
let message = document.getElementById("message")
//load messages
function loadMessages() {
  let messages = localStorage.getItem("messages") != null ? JSON.parse(localStorage.getItem("messages")) : null;
  let finalResult = '';
  messages.length > 0 ? messages.map((message, index) => {
    //finalResult += `
    //<p class="${message.sender === "Venkatesh" ? 'sent' : 'received'}">${message.text}</p>
    //`
    finalResult += `
    <p class="${index % 2 === 0 ? 'sent' : 'received'}">${message.text}
    <span class='datemessage'>${moment(message.date).format("DD-MM-YYYY HH:mm:ss A")}</span></p>
    `
  }) : finalResult += `<h2>Start Conversation</h2>`;
  output.innerHTML = finalResult;
}

//send message
function sendMessage() {
  let messageValue = message.value;
  if (messageValue.trim().length > 0) {
    let newMessage = {
      text: messageValue,
      date: new Date()
    };
    let messages1 = localStorage.getItem("messages") != null ? JSON.parse(localStorage.getItem("messages")) : null;
    messages1.push(newMessage);
    localStorage.setItem("messages", JSON.stringify(messages1));
    message.value = "";
    let parsedMessages = localStorage.getItem("messages") != null ? JSON.parse(localStorage.getItem("messages")) : null;
    messages = parsedMessages;
    loadMessages();
  } else {
    alert("Please enter valid message")
  }
}