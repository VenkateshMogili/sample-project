// generators
// function* numbers() {
//   let c = yield 30;
// }
// function* hello() {
//   yield;
//   let a = yield 10;
//   let b = yield 20;
//   yield* numbers();
//   yield setTimeout(() => {
//     console.log('api call');
//   }, 1000);
//   // return a;
// }
// let output = hello();
// console.log(output.next());
// console.log(output.next());
// console.log(output.next());
// console.log(output.next());
// console.log(output.next());

function getUsername(e) {
  console.log(e.target.value);
}

function formSubmitted(e) {
  console.log(e);
  e.preventDefault();
  let form = e.target[0].value;
  console.log(form);
}

function drop(event) {
  event.preventDefault();
  var data = event.dataTransfer.getData('text');
  event.target.appendChild(document.getElementById(data));
}
function allowDrop(event) {
  event.preventDefault();
}

function drag(event) {
  event.dataTransfer.setData('text', event.target.id);
}

function typing(e) {
  console.log(e.target.value);
}

function mouseover(e) {
  console.log(e);
}

// localstorage

localStorage.setItem('example', JSON.stringify({name: 'Venkatesh'}));
// let data = JSON.parse(localStorage.getItem('example'));
let data = localStorage.getItem('example');
console.log(data);
localStorage.removeItem('example');

sessionStorage.setItem('example', JSON.stringify({name: 'Venkatesh'}));
// let data = JSON.parse(sessionStorage.getItem('example'));
let data2 = sessionStorage.getItem('example');
console.log(data2);
sessionStorage.removeItem('example');
// debugger;
document.cookie = 'name=Venkatesh';
