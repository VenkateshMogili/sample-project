//detect output
let output = document.getElementById("output");

//action
function changeBackground(color) {
  output.style.backgroundColor = color;
  output.style.color = "white";
  output.style.border = "5px solid " + color;
}