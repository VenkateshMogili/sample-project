//take input
let input = document.getElementById("input");
let textValue = "";
function addInput(inputValue) {
  textValue += inputValue;
  input.value = textValue;
}
function clearInput() {
  input.value = "";
  textValue = "";
}
function output() {
  let outputValue = eval(textValue);
  textValue = outputValue;
  input.value = textValue;
}
function takeInput(event) {
  textValue = event.target.value;
}