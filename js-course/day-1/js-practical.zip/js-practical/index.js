

// sample comment


/*comment one
comment 2
*/

// var alert = 'venkatesh'

// alert("Hello World!")

var a = 10;
function sample() {
  a = 20;
  if (a === 20) {
    let c = 20;
    c = 30;
    // console.log(c);
    const d = {name:"Venkatesh"};
    d.name="Vivek";
    console.log(d);
  }
    // console.log(c)
  // console.log(c);
}
sample();

let b = 10;

// console.log(a)

var a = 40;
// console.log(a)