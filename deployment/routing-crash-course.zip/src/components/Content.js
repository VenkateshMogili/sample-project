import React from "react";
// TODO: How children prop works?
export default function Content(props) {
	return (
		<div>
			{/* {props.children} */}
			<h1 style={{ margin: 300 }}>💐Welcome to React Routing Crash Course💐</h1>
		</div>
	);
}
