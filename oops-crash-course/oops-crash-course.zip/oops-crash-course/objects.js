// #1 Object Literal
let mobile = { username: "Venkatesh" };

// #2 Object.create()
// let mobile = Object.create({});
// mobile.username="Venkatesh";

// #3 Functions are objects in javascript
// function Mobile(){
//   return "mobile";
// }
// let mobile = new Mobile();
// mobile.username ="Venkatesh";
// mobile["username"]="Venkatesh";

// #4 Using Classes
// class Mobile{

// }
// let mobile = new Mobile();
// mobile.username = "Venkatesh";
console.log(mobile);
console.log(typeof mobile);
