const express = require("express");
const router = express.Router();
const { fetchUsers } = require("../controllers/user.controller");

router.get("/users", fetchUsers);

module.exports = router;