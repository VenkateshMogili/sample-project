const mongoose = require("mongoose");

const connection = mongoose.connect("mongodb://127.0.0.1:27017/pagination", (error) => {
  if (!error) {
    console.log("Database connected")
  } else {
    console.log("Not connected", error)
  }
})

module.exports = connection;