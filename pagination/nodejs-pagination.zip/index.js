const express = require("express");
const app = express();
const cors = require("cors")
const connection = require("./db");
app.use(express.json());
app.use(cors({ origin: "*" }))

const port = 5000;
app.use("/api", require("./routes/user.route"));

app.get("/", (req, res) => {
  res.send("Hello")
})
app.listen(port, () => {
  console.log("Server Started On Port: " + port);
})