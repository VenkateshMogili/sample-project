const mongoose = require("mongoose");
const UserModel = require("../model/user.model")

const fetchUsers = async (req, res) => {
  const pageNumber = req.query.page > 0 ? req.query.page - 1 : 0;//1,2,3,4,5
  const pageSize = req.query.pageSize;
  const totalCount = await UserModel.find({}).count();
  UserModel.find({}).skip(pageNumber * pageSize).limit(pageSize).then((result) => {
    if (result.length > 0) {
      res.send({ data: result, pageCount: Math.ceil(totalCount / pageSize), success: true })
    } else {
      res.send({ data: null, success: false })
    }
  })
}

module.exports = {
  fetchUsers
}