import Container from "./components/Container";
function App() {
	return (
		<div>
			<Container />
		</div>
	);
}

export default App;
