import React from "react";
import "./App.css";
import FeedbackForm from "./components/FeedbackForm";
import SampleForm from "./components/SampleForm";
export default function App() {
  return (
    <div className="App">
      {/* <SampleForm /> */}
      <FeedbackForm />
    </div>
  );
}
