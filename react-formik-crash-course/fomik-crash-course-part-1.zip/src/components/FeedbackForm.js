import React, { useState } from 'react';
import { Formik, Form, Field, ErrorMessage, FieldArray, FastField } from 'formik';
import * as Yup from 'yup';
import ShowError from './ShowError'

export default function FeedbackForm() {
  const [formValues, setFormValues] = useState({})
  const initialValues = {
    email: "",
    name: "Venkatesh",
    phone: "12987219",
    address: "",
    socialmedia: {
      facebook: "",
      linkedin: ""
    },
    mobileNumbers: ["", ""],
    phoneNumbers: [""]
  }
  const savedValues = {
    email: "venkatesh@gmail.com",
    name: "Venkatesh Mogili",
    phone: "12987219239847",
    address: "aksjdfl",
    socialmedia: {
      facebook: "asdf",
      linkedin: "asdfsadf"
    },
    mobileNumbers: ["2324", "234324"],
    phoneNumbers: ["123123"]
  }
  const validationSchema = Yup.object({
    email: Yup.string().email("Invalid Email Format").required("Required"),
    // name: Yup.string().required("Required"),
    phone: Yup.number().required("Required"),
    // address: Yup.string().required("Required"),
    // socialmedia: Yup.object({
    //   facebook: Yup.string().required("Required")
    // }),
    // mobileNumbers: Yup.array().required("Required"),
    // phoneNumbers: Yup.array().required("Required")
  })
  const onSubmit = (values, form) => {
    console.log("form submitted", values, form);
    setTimeout(() => {
      form.setSubmitting(false);
      form.resetForm()
    }, 1000);
  }
  const validateName = (value) => {
    let error;
    if (!value) {
      error = "Required Name"
    }
    return error;
  }
  return (
    <div>
      <Formik initialValues={initialValues} validationSchema={validationSchema} onSubmit={onSubmit} validateOnMount >
        {
          (formik) => {
            console.log("form", formik.errors)
            return (<Form>
              <h1>Formik Feedback</h1>
              <label htmlFor="email">Your Email</label>
              <Field type="email" name="email" id="email" />
              <ErrorMessage name="email" component={ShowError} />
              <label htmlFor="name">Your Name</label>
              <Field type="text" name="name" id="name" as="textarea" validate={validateName} />
              <ErrorMessage name="name" component={ShowError} />
              <label htmlFor="phone">Your Phone Number</label>
              <Field type="text" name="phone" id="phone" placeholder="Enter your mobile number" />
              <ErrorMessage name="phone" component={ShowError} />
              <label htmlFor="address">Your Address</label>
              <FastField name="address" id="address">
                {
                  (props) => {
                    console.log("address props");
                    const { meta, field } = props;
                    return <textarea {...field}></textarea>
                  }
                }
              </FastField>
              <ErrorMessage name="address" component={ShowError} />
              <label htmlFor="facebook">Your Facebook ID</label>
              <Field type="text" name="socialmedia.facebook" id="facebook" placeholder="Enter your facebook id" />
              <ErrorMessage name="socialmedia.facebook" component={ShowError} />
              <label htmlFor="linkedin">Your Linkedin ID</label>
              <Field type="text" name="socialmedia.linkedin" id="linkedin" placeholder="Enter your linkedin id" />
              <ErrorMessage name="socialmedia.linkedin" component={ShowError} />

              <label htmlFor="mobile1">Your Mobile Number 1</label>
              <Field type="text" name="mobileNumbers[0]" id="mobile1" placeholder="Enter your mobile number" />
              <ErrorMessage name="mobileNumbers[0]" component={ShowError} />
              <label htmlFor="mobile2">Your Mobile Number 2</label>
              <Field type="text" name="mobileNumbers[1]" id="mobile2" placeholder="Enter your mobile number" />
              <ErrorMessage name="mobileNumbers[1]" component={ShowError} />
              <label htmlFor="mobileNumbers">Your Phone Numbers</label>
              <FieldArray name="phoneNumbers">
                {
                  (fieldArgs) => {
                    // console.log(fieldArgs);
                    const { form, push, remove } = fieldArgs;
                    const { values } = form;
                    const { phoneNumbers } = values;
                    return <div>
                      {phoneNumbers != undefined && phoneNumbers.map((phoneNumber, index) => (
                        <div key={index} className="flex-row">
                          <Field name={`phoneNumbers[${index}]`} />
                          {phoneNumbers.length > 1 && <button className="addremove" onClick={() => remove(index)}>-</button>}
                          <button className="addremove" onClick={() => push("")}>+</button>
                        </div>
                      ))}
                    </div>
                  }
                }
              </FieldArray>
              <ErrorMessage name="mobileNumbers[1]" component={ShowError} />
              <br />
              <button type="button" onClick={() => formik.validateForm()}>Validate Form</button>
              <button type="button" onClick={() => formik.setFieldTouched("email")}>Touch Element</button>
              <button type="button" onClick={() => formik.setTouched({
                email: true,
                name: true
              })}>Touch Form</button>
              <button type="button" onClick={() => formik.validateField("email")}>Validate Element</button>
              <button type="button" onClick={() => setFormValues(savedValues)}>Load Data</button>
              <input type="reset" value="Reset Form" />
              {/* <button type="submit" className="submitBtn" disabled={!(formik.dirty && formik.isValid)}>Submit</button> */}
              <button type="submit" className="submitBtn" disabled={formik.isSubmitting}>Submit</button>
              <p className="footer">Powered By Venkatesh Mogili</p>
            </Form>)
          }
        }
      </Formik>
    </div>
  )
}
