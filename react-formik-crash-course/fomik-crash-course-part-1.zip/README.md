# Getting Started with VMTraining Project Setup


## 1.Download the zip file and extract it. 
```cd formik-crash-course```

## 2.Install the npm packages

### `npm install`

## 3.Run the project

### `npm start`

Runs the app in the development mode.

Open [http://localhost:5500](http://localhost:5500) to view it in the browser.