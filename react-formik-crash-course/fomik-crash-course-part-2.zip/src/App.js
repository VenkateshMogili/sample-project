import React from "react";
import "./App.css";
import Navigation from "./components/Navigation";
import { Route, Switch } from "react-router-dom";
import Register from "./components/Register";
import Login from "./components/Login";
import Enroll from "./components/Enroll";

export default function App() {
  return (
    <div className="App">
      <div className="container">
      <Navigation />
      <Switch>
        <Route path="/register" component={Register} />
        <Route path="/login" component={Login} />
        <Route path="/enroll" component={Enroll} />
        </Switch>
        </div>
    </div>
  );
}
