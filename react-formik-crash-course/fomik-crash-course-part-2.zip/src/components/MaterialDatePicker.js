import { ErrorMessage, Field } from 'formik'
import React from 'react'
import ShowError from './ShowError';
import {
  TimePicker,
  DatePicker,
  DateTimePicker,
} from 'formik-material-ui-pickers';

export default function MaterialDatePicker(props) {
  const { label, name, ...rest } = props;
  return (
    <div>
      {/*<Field component={DatePicker} label={label} name={name} id={name}  {...rest} />*/}
      {/*<Field component={TimePicker} label={label} name={name} id={name}  {...rest} />*/}
      <Field component={DateTimePicker} label={label} name={name} id={name}  {...rest} />
      <ErrorMessage name={name} component={ShowError} />
    </div>
  )
}
