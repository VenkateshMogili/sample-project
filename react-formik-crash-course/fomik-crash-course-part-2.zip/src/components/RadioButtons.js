import { ErrorMessage, Field } from 'formik'
import React from 'react'
import ShowError from './ShowError'

export default function RadioButtons(props) {
  const { label, name, options, ...rest } = props;
  return (
    <div>
      <label htmlFor={name}>{label}</label>
      <div className="m-3">
      <Field name={name} id={name} {...rest}>
        {
          (fieldProps) => {
            const { field } = fieldProps;
            return options.map((option, index) => (
              <React.Fragment key={index}>
                <input type="radio" id={option.value} {...field} value={option.value} checked={field.value===option.value} />
                <label htmlFor={option.value}>{option.key}</label>
              </React.Fragment>
            ))
          }
        }
        </Field>
      </div>
      <ErrorMessage name={name} component={ShowError} />
    </div>
  )
}
