import React from 'react'
import * as Yup from 'yup';
import { Form, Formik } from 'formik';
import FormControl from './FormControl';

export default function Enroll() {
  const courseOptions = [
    {
      key: "Select course", value: ""
    },
    {
      key: "HTML 5", value: "html5"
    },
    {
      key: "JavaScript", value: "javascript"
    }
  ];
  const prerequisitesOptions = [
    {
      key: "Basic Computer Knowledge", value: "basiccomputer"
    },
    {
      key: "English", value: "english"
    }
  ]

  const courseTypes = [
    {
      key: "Enroll", value: "enroll"
    },
    {
      key: "Purchase", value: "purchase"
    }
  ]
  const initialValues = {
    name: "",
    firstname: "",
    lastname:"",
    email: "",
    courseOption: "",
    prerequisites: [],
    coursetype: "",
    enrolldate: null
  }
  const validationSchema = Yup.object({
    name: Yup.string().required("Required"),
    firstname: Yup.string().required("Required"),
    lastname: Yup.string().required("Required"),
    email: Yup.string().email("Invalid email format").required("Required"),
    courseOption: Yup.string().required("Required"),
    prerequisites: Yup.array().length(1),
    coursetype: Yup.string().required("Required"),
  })

  const onSubmit = (values, form) => {
    console.log("form submitted", values, form);
    setTimeout(() => {
      form.setSubmitting(false);
      form.resetForm()
    }, 1000);
  }
  return (
    <div>
      <Formik initialValues={initialValues} validationSchema={validationSchema} onSubmit={onSubmit}>
        {
          (formik)=>(
          <Form>
            <h1>VM Training</h1>
            <h2>Course Enrollment</h2>
              <FormControl label="First Name" name="firstname" placeholder="Enter your first name" control="input" type="text" />
              <FormControl label="Last Name" name="lastname" placeholder="Enter your last name" control="input" type="text" />
            <FormControl label="Email" name="email" placeholder="Enter your email address" control="input" type="email" />
            <FormControl label="Choose Course" name="courseOption" control="select" options={courseOptions} />
            <FormControl label="Prerequisites" name="prerequisites" control="checkbox" options={prerequisitesOptions} />
            <FormControl label="Choose Course Type" name="coursetype" control="radio" options={courseTypes} />
              {formik.values.coursetype === "enroll" && <FormControl label="Enrollment Date" name="enrolldate" control="date" />}
            <input type="submit" className="submitBtn" disabled={formik.isSubmitting} value="Confirm" />
            <a href="/#" className="forgetpassword">Logout</a>
            </Form>
          )
        }
      </Formik>
    </div>
  )
}
