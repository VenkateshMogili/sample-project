import React from 'react'
import * as Yup from 'yup';
import { Form, Formik } from 'formik';
import FormControl from './FormControl';
import { Link } from 'react-router-dom';

export default function Register() {
  const initialValues = {
    email: "",
    password: "",
    confirmpassword:"",
  }
  const validationSchema = Yup.object({
    email: Yup.string().email("Invalid email format").required("Required"),
    password: Yup.string().required("Required"),
    confirmpassword: Yup.string().required("Required").oneOf([Yup.ref('password')],'Passwords must match')
  })

  const onSubmit = (values, form) => {
    console.log("form submitted", values, form);
    setTimeout(() => {
      form.setSubmitting(false);
      form.resetForm()
    }, 1000);
  }
  return (
    <div>
          <Formik initialValues={initialValues} validationSchema={validationSchema} onSubmit={onSubmit}>
            <Form>
          <h1>VM Training</h1>
          <h2>Registration</h2>
          <FormControl label="Email" name="email" placeholder="Enter your email address" control="input" type="email" />
          <FormControl label="Password" name="password" placeholder="Enter your password" control="input" type="password" />
          <FormControl label="Confirm Password" name="confirmpassword" placeholder="Enter your confirmpassword" control="input" type="password" />
          <input type="submit" className="submitBtn" value="Register"/>
          <Link to="/login" className="forgetpassword">Login</Link>
            </Form>
          </Formik>
    </div>
  )
}
