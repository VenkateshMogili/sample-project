import React from 'react'
import * as Yup from 'yup';
import { Form, Formik } from 'formik';
import FormControl from './FormControl';

export default function Login() {
  const initialValues = {
    email: "",
    password: "",
  }
  const validationSchema = Yup.object({
    email: Yup.string().email("Invalid email format").required("Required"),
    password: Yup.string().required("Required")
  })

  const onSubmit = (values, form) => {
    console.log("form submitted", values, form);
    setTimeout(() => {
      form.setSubmitting(false);
      form.resetForm()
    }, 1000);
  }
  return (
    <div>
          <Formik initialValues={initialValues} validationSchema={validationSchema} onSubmit={onSubmit}>
            <Form>
          <h1>VM Training</h1>
          <h2>Login</h2>
          <small>Please enter your username or work email address</small>
          <FormControl label="Email" name="email" placeholder="Enter your email address" control="input" type="email" />
          <FormControl label="Password" name="password" placeholder="Enter your password" control="input" type="password" />
          <input type="submit" className="submitBtn" value="Login"/>
          <a href="/#" className="forgetpassword">Forget Password?</a>
            </Form>
          </Formik>
    </div>
  )
}
