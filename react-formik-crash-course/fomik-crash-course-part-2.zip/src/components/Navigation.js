import React from 'react'
import { NavLink } from 'react-router-dom'

export default function Navigation() {
  return (
    <nav>
      <NavLink to="/register" className="navoption" activeClassName="active">Register</NavLink>
      <NavLink to="/login" className="navoption" activeClassName="active">Login</NavLink>
      <NavLink to="/enroll" className="navoption" activeClassName="active">Enroll</NavLink>
    </nav>
  )
}
