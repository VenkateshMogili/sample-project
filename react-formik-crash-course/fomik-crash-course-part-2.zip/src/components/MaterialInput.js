import {  Field } from 'formik'
import React from 'react'
import { TextField } from 'formik-material-ui';

export default function MaterialInput(props) {
  const { label, name, ...rest } = props;
  return (
    <div>
      <Field component={TextField} label={label} name={name} id={name} {...rest} />
    </div>
  )
}
