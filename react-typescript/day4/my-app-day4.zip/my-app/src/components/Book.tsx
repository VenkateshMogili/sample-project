import React, { useState } from 'react'

type AuthorProps = {
  name: string
  country: string
}

export default function Book() {
  const [pages, setPages] = useState<number>(0);
  const [author, setAuthor] = useState<AuthorProps>({} as AuthorProps);

  const handleSetPages = () => {
    setPages(20);
  }

  const handleAuthor = () => {
    setAuthor({
      name: "Venkatesh Mogili",
      country: "India"
    })
  }
  return (
    <div>
      <button onClick={handleSetPages}>Set Pages</button>
      <button onClick={handleAuthor}>Set Author Details</button>
      <h2>Book Details:</h2>
      <p>This book contains {pages} pages. This book written by {author.name}, from {author.country}.</p>
    </div>
  )
}
