import './App.css';
import Book from './components/Book';
import Input from './components/Input';
import Laptop from './components/Laptop';
import Timer from './components/Timer';
import User from './components/User';
import UserContextProvider from './components/UserContext';

function App() {

  return (
    <div>
      {/*<Book />*/}
      {/* <Laptop /> */}
      {/* <UserContextProvider>
      <User/>
      </UserContextProvider> */}
      {/* <Input/> */}
      <Timer/>
    </div>
  );
}

export default App;
