import React, { useState } from 'react'
import "./Recipe.css"

type RecipeProps = {
  image: string
  label: string
  ingredientLines: string[]
  dishType: string[]
  calories: number
  url: string
  uri: string
}

export type RecipeObjectProps = {
  recipe: RecipeProps
  handleFavorite: (uri: string) => void
  favorites: string[]
}

export default function Recipe({ recipe, handleFavorite, favorites }: RecipeObjectProps) {
  const { image, label, ingredientLines,uri } = recipe;
  const [showInfo, setShowInfo] = useState<boolean>(ingredientLines.length > 3);
  const isFavorite = favorites.findIndex(item => item === uri) > -1;
  return (
    <div className='recipe-item'>
      <img src={image} className='recipe-thumbnail' alt="Recipe Thumbnail" />
      <div className='recipe-title'>
      <h4 className='recipe-label'>{label}</h4>
        <i className={`fa fa-${isFavorite ? 'heart' : 'heart-o'}`} onClick={() => handleFavorite(uri)} />
      </div>
      <h5>Ingredients:</h5>
      <ol type="1">
        {ingredientLines.length > 0 && ingredientLines.slice(0, showInfo ? 3 : ingredientLines.length).map((ingredient, index:number) => (
          <li key={index}>{ingredient}</li>
        ))}
        {showInfo && <p className='more-info' onClick={() => setShowInfo(!showInfo)}>More Info</p>}
        {ingredientLines.length>3 && !showInfo && <p className='more-info' onClick={() => setShowInfo(!showInfo)}>View Less Info</p>}
      </ol>
    </div>
  )
}
