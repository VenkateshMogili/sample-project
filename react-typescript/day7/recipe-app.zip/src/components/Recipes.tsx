import React, { FormEvent, useState } from 'react'
import "./Recipes.css";
import { APIConfig } from '../apiconfig';
import Recipe, { RecipeObjectProps } from './Recipe';

export default function Recipes() {
  const [query, setQuery] = useState<string>("");
  const [recipes, setRecipes] = useState<RecipeObjectProps[]>([]);
  const [favorites, setFavorites] = useState<string[]>([])

  const handleFavorite = (uri: string) => {
    const existingFavorites = [...favorites];
    const matched = existingFavorites.findIndex(item => item === uri) > -1;
    if (matched) {
      setFavorites(existingFavorites.filter(item => item !== uri));
    } else {
      existingFavorites.push(uri);
      console.log("uri", existingFavorites)
      setFavorites(existingFavorites);
    }
  }

  const handleSubmit = (e:FormEvent) => {
    e.preventDefault();
    getRecipes();
  }

  const getRecipes = async() => {
    const response = await fetch("https://api.edamam.com/api/recipes/v2?q=" + query + "&app_id=" + APIConfig.APP_ID + "&app_key=" + APIConfig.APP_KEY + "&type=public");
    const searchResult = await response.json();
    setRecipes(searchResult.hits);
    console.log("searchResult", searchResult);
  }

  // useEffect(() => {
  //   getRecipes();
  // },[query])

  return (
    <div>
      <div className='App'>
        <h1 className='heading'>Recipe App</h1>
        <form className='input-group' onSubmit={handleSubmit}>
          <input type="text" className='search-input' value={query} onChange={(e) => setQuery(e.target.value)} />
          <button type="submit" className='search-btn'>Search</button>
        </form>
      </div>
      <div className='recipe-items'>
        {recipes.length>0 && recipes.map((recipe,index:number)=>(
          <Recipe recipe={recipe.recipe} key={index} handleFavorite={handleFavorite} favorites={favorites} />
        ))}
      </div>
    </div>
  )
}
