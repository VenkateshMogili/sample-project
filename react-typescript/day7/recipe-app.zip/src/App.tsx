import Recipes from "./components/Recipes";

function App() {
  return (
    <div>
      <Recipes/>
    </div>
  );
}

export default App;
