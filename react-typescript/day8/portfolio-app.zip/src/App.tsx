import Home from './components/Home';
import Navbar from './components/Navbar';
import "./components/Home.css";
import About from './components/About';
import Skills from './components/Skills';
import Work from './components/Work';
import Resume from './components/Resume';

function App() {
  return (
    <div>
      <Navbar />
      <div className='container'>
        <Home />
        <About/>
        <Skills/>
        <Work/>
        <Resume/>
      </div>
    </div>
  );
}

export default App;
