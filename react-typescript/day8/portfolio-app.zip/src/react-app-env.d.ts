/// <reference types="react-scripts" />
declare module 'react-scroll';
declare namespace React{
  interface HTMLAttributes<T> extends DOMAttributes<T>{
    name?:string
  }
}
declare module '*.pdf';