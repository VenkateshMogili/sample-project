import React from 'react'
import "./Work.css";

export default function Work() {
  return (
    <div name="work" className='work-container'>
      <h1>Work</h1>
      <p>Check out some of my most recent work</p>
      <div className='work-list'>
        <div className='project-item'>
        <button>Project 1</button>
        <div className='project-details'>
          <h4>Project Details</h4>
          <p>It is simple MERN Stack Application.</p>
          <a href="https://google.com">Demo</a>
          <a href="https://google.com">Code</a>
        </div>
        </div>
        <div className='project-item'>
        <button>Project 2</button>
        <div className='project-details'>
          <h4>Project Details</h4>
          <p>It is simple MERN Stack Application.</p>
          <a href="https://google.com">Demo</a>
          <a href="https://google.com">Code</a>
        </div>
        </div>

        <div className='project-item'>
        <button>Project 3</button>
        <div className='project-details'>
          <h4>Project Details</h4>
          <p>It is simple MERN Stack Application.</p>
          <a href="https://google.com">Demo</a>
          <a href="https://google.com">Code</a>
        </div>
        </div>

        <div className='project-item'>
        <button>Project 4</button>
        <div className='project-details'>
          <h4>Project Details</h4>
          <p>It is simple MERN Stack Application.</p>
          <a href="https://google.com">Demo</a>
          <a href="https://google.com">Code</a>
        </div>
        </div>
        <div className='project-item'>
        <button>Project 5</button>
        <div className='project-details'>
          <h4>Project Details</h4>
          <p>It is simple MERN Stack Application.</p>
          <a href="https://google.com">Demo</a>
          <a href="https://google.com">Code</a>
        </div>
        </div>
        <div className='project-item'>
        <button>Project 6</button>
        <div className='project-details'>
          <h4>Project Details</h4>
          <p>It is simple MERN Stack Application.</p>
          <a href="https://google.com">Demo</a>
          <a href="https://google.com">Code</a>
        </div>
        </div>
      </div>
    </div>
  )
}
