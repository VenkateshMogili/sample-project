import React from 'react'
import { Link, animateScroll as scroll } from 'react-scroll';
import { FaLinkedin, FaGithub } from 'react-icons/fa'
import { HiOutlineMail } from 'react-icons/hi';
import { BsFillPersonLinesFill} from 'react-icons/bs';
import './Navbar.css';

export default function Navbar() {
  const scrollToTop = () => {
    scroll.scrollToTop();
  }
  return (
    <div>
    <div className='navbar'>
      <h1 className='heading'>Venkatesh Mogili</h1>
      <div className='menu'>
        <Link to="home" onClick={scrollToTop} smooth={true} duration={500}>Home</Link>
        <Link to="about" smooth={true} duration={500}>About</Link>
        <Link to="skills" smooth={true} duration={500}>Skills</Link>
        <Link to="work" smooth={true} duration={500}>Work</Link>
        <Link to="resume" smooth={true} duration={500}>Resume</Link>
      </div>
    </div>
    <div className='social-icons'>
        <FaLinkedin color="white" size={40} />
        <FaGithub color="white" size={40} />
        <HiOutlineMail color="white" size={40} />
        <BsFillPersonLinesFill color="white" size={40}/>
      </div>
    </div>
  )
}
