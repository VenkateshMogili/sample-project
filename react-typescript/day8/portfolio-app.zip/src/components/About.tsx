import React from 'react'
import "./About.css";

export default function About() {
  return (
    <div name="about" className='about-container'>
      <h1>About</h1>
      <div className='about-me'>
      <h1>Hi. I'm Venkatesh Mogili, nice to meet you. Please take a look around.</h1>
        <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Animi, nesciunt quos libero ab molestias, quis enim recusandae facilis tempore explicabo commodi totam mollitia ducimus eligendi. Dolores sequi veritatis quae architecto.</p>
      </div>
    </div>
  )
}
