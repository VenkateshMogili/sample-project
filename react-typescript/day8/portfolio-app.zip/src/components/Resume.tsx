import React from 'react'
import "./Resume.css";
import ResumePDF from '../assets/VenkateshMogili-Resume.pdf';

export default function Resume() {
  return (
    <div name="resume" className='resume-container'>
      <h1>Resume</h1>
      <button className='download-resume'>Download Resume</button>
      <embed src={ResumePDF} width={"100%"} height={700}/>
      <button className='download-resume'>Download Resume</button>
    </div>
  )
}
