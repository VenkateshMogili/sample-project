import React from 'react'
import { FaArrowRight } from 'react-icons/fa';
import userIcon from '../assets/user.png';
import {Link} from 'react-scroll';
import "./Home.css";

export default function Home() {
  return (
    <div className='home-container'>
    <div className='description'>
      <h1 className='developer'>I'm a Full Stack<br />
        Web<br />
        Developer</h1>
      <p className='experience'>I have 5+ years of experience in full stack web and mobile app development. Currently, I love to work on web applications using technologies such as React, NodeJS and MongoDB.</p>
      <Link to="about" smooth={true} duration={500}>
        <button className='about-btn'>About Me <FaArrowRight color="white" className='arrow'/>  </button>
        </Link>
      </div>
      <div className='user-profile'>
        <img src={userIcon} alt="User" className='user-icon' />
      </div>
    </div>
  )
}
