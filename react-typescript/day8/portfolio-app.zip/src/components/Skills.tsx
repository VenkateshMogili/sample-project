import React from 'react'
import "./Skills.css";

export default function Skills() {
  return (
    <div name="skills" className='skills-container'>
      <h1>Skills</h1>
      <p>I enjoy diving into and learning new things. Here's a list of technologies I've worked with</p>
      <div className='skills-list'>
        <button>HTML</button>
        <button>CSS</button>
        <button>JAVASCRIPT</button>
        <button>REACT</button>
        <button>GITHUB</button>
        <button>NODE JS</button>
        <button>MONGODB</button>
        <button>AWS</button>
        <button>Django</button>
        <button>Sass</button>
        <button>NextJS</button>
        <button>GraphQL</button>
      </div>
    </div>
  )
}
