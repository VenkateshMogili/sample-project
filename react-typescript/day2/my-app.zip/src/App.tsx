import './App.css';
import Example1 from './Example1';
import Hotels from './Hotels';
import Todos from './Todos';

function App() {
  return (
    <div>
      {/*<Example1 />
      <Todos />*/}
      <Hotels />
    </div>
  );
}

export default App;
