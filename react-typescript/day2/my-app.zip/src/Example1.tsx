import Profile from "./Profile";

export default function Example1() {
  return (
    <div>
      <h1 className="list-style">Amazing Scientists</h1>
      <Profile />
      <Profile />
      <Profile />
    </div>
  )
}