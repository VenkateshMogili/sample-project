import React, { useState } from 'react'

export default function VMOnlineBooking() {
  const [numberOfEmployees, setNumberOfEmployees] = useState<number>(0);
  const [numberOfBeds, setNumberOfBeds] = useState<number>(0);

  return (
    <div>
      <Venkatesh
        numberOfEmployees={numberOfEmployees}
        setNumberOfEmployees={setNumberOfEmployees}
        numberOfBeds={numberOfBeds}
        setNumberOfBeds={setNumberOfBeds}
      />
      <Ramani
        numberOfEmployees={numberOfEmployees}
        setNumberOfEmployees={setNumberOfEmployees}
        numberOfBeds={numberOfBeds}
        setNumberOfBeds={setNumberOfBeds}
      />
    </div>
  )
}

interface User {
  name: string;
}
export function Venkatesh(props: { numberOfEmployees: number, setNumberOfEmployees: Function, numberOfBeds: number, setNumberOfBeds: Function }) {

  const [numberOfEmployeesVenkatesh, setNumberOfEmployeesVenkatesh] = useState<number>(5);
  const [numberOfBedsVenkatesh, setNumberOfBedsVenkatesh] = useState<number>(3);
  const [users] = useState<User[]>([
    { name: "Venkatesh" },
    { name: "Ramani" },
    { name: "Chinni" },
    { name: "Siva" },
    { name: "Chinni" },
  ]);
  const addToCart = () => {
    console.log("Add to cart");
  }
  function buyNow(event: React.MouseEvent<HTMLButtonElement, MouseEvent>, numberOfBedsVenkatesh: number) {
    console.log("Buy Now", event, numberOfBedsVenkatesh);
  }
  const buyNow2 = (event: React.MouseEvent<HTMLButtonElement, MouseEvent>) => {
    console.log("Buy Now 2", event);
  }

  return (
    <div style={{ border: "2px solid red", padding: 10 }}>
      <h1>Venkatesh</h1>
      <button onClick={() => props.setNumberOfEmployees((prevValue: number) => prevValue + numberOfEmployeesVenkatesh)}>Add Employees</button>
      <button onClick={() => props.setNumberOfBeds((prevValue: number) => prevValue + numberOfBedsVenkatesh)}>Add Beds</button>
      <button onClick={addToCart}>Add to cart</button>
      <button onClick={(e) => buyNow(e, numberOfBedsVenkatesh)}>Buy Now</button>
      <button onClick={buyNow2}>Buy Now</button>
      <p>Employees: {numberOfEmployeesVenkatesh}</p>
      <p>Beds: {numberOfBedsVenkatesh}</p>
      <hr />
      <p>Global Employees:
        {props.numberOfEmployees === 100 && <b style={{ color: "blue" }}>{props.numberOfEmployees}</b>},
        {props.numberOfEmployees !== 100 ? <b>{props.numberOfEmployees}</b> : null}
        {/*{props.numberOfEmployees === 105 && null}*/}

        Number Of Beds: {props.numberOfBeds === 6 ? <b>"Out Of Stock"</b> : "In Stock"}</p>
      {users.map((user: User, index: number) => (
        <p key={index}>{user.name}</p>
      ))}
    </div>
  )
}

export function Ramani(props: { numberOfEmployees: number, setNumberOfEmployees: Function, numberOfBeds: number, setNumberOfBeds: Function }) {
  const [numberOfEmployeesRamani, setNumberOfEmployeesRamani] = useState<number>(8);
  const [numberOfBedsRamani, setNumberOfBedsRamani] = useState<number>(2);

  return (
    <div style={{ border: "2px solid orange", padding: 10 }}>
      <h1>Ramani</h1>
      <button onClick={() => props.setNumberOfEmployees((prevValue: number) => prevValue + numberOfEmployeesRamani)}>Add Employees</button>
      <button onClick={() => props.setNumberOfBeds((prevValue: number) => prevValue + numberOfBedsRamani)}>Add Beds</button>
      <p>Employees: {numberOfEmployeesRamani}</p>
      <p>Beds: {numberOfBedsRamani}</p>
      <hr />
      <p>Global Employees: <b>{props.numberOfEmployees}</b><b style={{ color: "blue" }}>{props.numberOfEmployees}</b>, Number Of Beds: {props.numberOfBeds}</p>
    </div>
  )
}