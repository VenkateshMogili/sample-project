import Profile2 from "./Profile2";
import "./App.css";

export default function Todos() {
  return (
    <div>
      <Heading />
      <Profile2 />
      <ul>
        <List />
        <List />
        <List />
      </ul>
      <li className="list-style">Hello</li>
    </div>
  )
}

function List() {
  const listStyle = {
    color: "blue",
  }
  return <li style={listStyle}>Task 1</li>
}
function Heading() {
  return <h1 style={{ color: "red" }}>Venkatesh Mogili Todos</h1>
}