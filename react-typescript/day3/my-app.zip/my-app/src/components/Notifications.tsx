import React from "react"

type NotificationsProps = {
  children: React.ReactNode
}
export default function Notifications(props: NotificationsProps) {
  return (
    <div>
      <h1>Notifications</h1>
      {props.children}
    </div>
  )
}
