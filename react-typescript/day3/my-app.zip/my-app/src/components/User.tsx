import { MarksProps } from "./marskProps.types"

type UserProps = {
  name: string
  age: number
  fullName: {
    firstName: string
    lastName: string
  }
  marks: MarksProps[]
}

export default function User({ name, fullName, age }: UserProps) {
  return (
    <div>{name} {fullName.firstName + " " + fullName.lastName} and {age}</div>
  )
}
