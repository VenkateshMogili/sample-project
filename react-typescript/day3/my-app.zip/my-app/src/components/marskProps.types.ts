export type MarksProps = {
  subject: string
  marks: number
}