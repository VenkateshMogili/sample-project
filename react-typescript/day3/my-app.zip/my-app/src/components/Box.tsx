import React from 'react'
type BoxProps = {
  styles: React.CSSProperties
}

export default function Box(props: BoxProps) {
  return (
    <div style={props.styles}>Box</div>
  )
}
