import { useState } from 'react';
import './App.css';
import Button from './components/Button';
import Input from './components/Input';
import Notification from './components/Notification';
import Notifications from './components/Notifications';
import User from './components/User';
import Box from './components/Box';

function App() {
  const [user, setUser] = useState('')
  const fullName = {
    firstName: "Venkatesh",
    lastName: "Mogili"
  }
  const marks = [{
    subject: "React",
    marks: 90
  },
  {
    subject: "JavaScript",
    marks: 95
  }];
  const handleClick = (event: React.MouseEvent<HTMLButtonElement>) => {
    console.log("Clicked", event);
  }
  return (
    <div>
      {/*<User name="Venkatesh Mogili" age={20} fullName={fullName} marks={marks} />*/}
      {/*<Notifications>
        <Notification status='info'>You have successfully Logged In</Notification>
        <Notification status='info'></Notification>
      </Notifications>*/}
      {/*<Button handleClick={handleClick} />*/}
      {/*<Input value={user} handleChange={(event) => setUser(event.target.value)} />
      {user}*/}
      <Box styles={{ width: 200, height: 200, backgroundColor: "red", padding: 10, margin: 10 }} />
    </div>
  );
}

export default App;
