import './App.css';
import Book from './components/Book';
import BookStore from './components/BookStore';
import CustomButton from './components/CustomButton';
import Input from './components/Input';
import Laptop from './components/Laptop';
import MagicNumber from './components/MagicNumber';
import Timer from './components/Timer';
import Toast from './components/Toast';
import User from './components/User';
import UserContextProvider from './components/UserContext';
import Account from './components/authentication/Account';
import PrivateRoute from './components/authentication/PrivateRoute';

function App() {

  return (
    <div>
      {/*<Book />*/}
      {/* <Laptop /> */}
      {/* <UserContextProvider>
      <User/>
      </UserContextProvider> */}
      {/* <Input/> */}
      {/* <Timer/> */}
      {/* <BookStore bookName="Wings Of Fire"/> */}
      {/* <PrivateRoute isLoggedIn={true} component={Account}/> */}
      {/* <MagicNumber value={10} isPositive/> */}
      {/* <Toast position='center'/> */}
      <CustomButton variant='primary' onClick={()=>console.log('Clicked')} type='button'>
        Primary Button
        </CustomButton>
    </div>
  );
}

export default App;
