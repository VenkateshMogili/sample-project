import React, { useEffect, useRef } from 'react'

type InputProps= React.ComponentProps<'input'>

export default function Input({...rest}:InputProps) {
  const inputRef=useRef<HTMLInputElement>(null!);

  useEffect(()=>{
    inputRef.current.focus();
  },[])

  return (
    <div>
      <input type="text" ref={inputRef} {...rest}/>
    </div>
  )
}
