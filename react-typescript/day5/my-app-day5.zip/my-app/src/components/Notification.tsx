type NotificationProps = {
  status: 'warning' | 'error' | 'info',
  children?: string
}

export default function Notification(props: NotificationProps) {
  return (
    <div>
      <h1>Notification Type</h1>
      <p>{props.status}</p>
      {props.children}
    </div>
  )
}
