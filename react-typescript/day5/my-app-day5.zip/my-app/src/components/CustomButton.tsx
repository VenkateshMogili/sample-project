import React from 'react'

type CustomButtonProps={
  variant: 'primary'|'secondary'
  children:string
} & Omit<React.ComponentProps<'button'>,'children'>

export default function CustomButton({variant,children,...rest}:CustomButtonProps) {
  return (
    <div>
      <button className={`btn-${variant}`} {...rest}>{children}</button>
    </div>
  )
}
