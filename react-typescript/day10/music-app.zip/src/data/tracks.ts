export const tracks=[
  {
	name:"Naatu Naatu",
	singer:"Kaala Bhairava & Rahul Sipligunj",
	poster:"assets/images/1-rrr.jpg",
	src:"assets/music/1-Naatu Naatu.mp3"
},
{
	name:"Prathikadalo",
	singer:"Ravi Basrur and Team",
	poster:"assets/images/2-salaar.jpg",
	src:"assets/music/2-Prathikadalo.mp3"
},
{
	name:"Samayama",
	singer:"Hesham Abdul Wahab",
	poster:"assets/images/3-hi_nanna.jpg",
	src:"assets/music/3-Samayama.mp3"
},
{
	name:"DJ Tillu - Title Song",
	singer:"Ram Miriyala",
	poster:"assets/images/4-dj_tillu.jpg",
	src:"assets/music/4-DJ Tillu Title Song.mp3"
},
]