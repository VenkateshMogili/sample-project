import { useCallback, useEffect, useRef, useState } from 'react';
import './App.css';
import Credits from './components/Credits';
import ThemeChanger from './components/ThemeChanger';
import ProgressBar from './components/ProgressBar';
import PlayerControls from './components/PlayerControls';
import { tracks } from './data/tracks';
import PlayerMenu from './components/PlayerMenu';
import Account from './components/Account';
import Playlist from './components/Playlist';

export const formatTime=(time:number)=>{
  if(time && !isNaN(time)){
    const minutes = Math.floor(time/60);
    const seconds = Math.floor(time%60);
    const formattedMinutes=minutes<10?"0"+minutes:minutes;
    const formattedSeconds=seconds<10?"0"+seconds:seconds;
    return formattedMinutes+":"+formattedSeconds;
  }
  return "00:00";
}

function App() {
  const [theme,setTheme]=useState<string>("Dark");
  const audioRef=useRef<HTMLAudioElement>(null!);
  const [isPlaying,setIsPlaying]=useState<boolean>(false);
  const [currentTime,setCurrentTime]=useState<number>(0);
  const [duration,setDuration]=useState<number>(0);
  const progressBarRef=useRef<HTMLProgressElement>(null!);
  const playAnimationRef=useRef<number>(0);
  const [songs,setSongs]=useState(tracks);
  const [currentSong,setCurrentSong]=useState(0);
  const [loop,setLoop]=useState<boolean>(false);
  const [account,setAccount]=useState<boolean>(false);
  const [playlist,setPlaylist]=useState<boolean>(false);

  const handlePlay=()=>{
    if(isPlaying){
      audioRef.current.pause();
      setIsPlaying(false);
    } else{
      audioRef.current.play();
      setIsPlaying(true);
    }
  }

  const repeat=useCallback(()=>{
    const currentTime=audioRef.current.currentTime;
    setCurrentTime(currentTime);
    progressBarRef.current.value=currentTime;
    progressBarRef.current.style.setProperty(
      '--range-progress',
      `${(progressBarRef.current.value/duration)*100}%`
    )
    playAnimationRef.current=requestAnimationFrame(repeat);
  },[audioRef,setCurrentTime,currentTime,progressBarRef,duration])

  const playAudio=()=>{
    audioRef.current.play();
    playAnimationRef.current=requestAnimationFrame(repeat);
  }

  const pauseAudio=()=>{
    audioRef.current.pause();
    cancelAnimationFrame(playAnimationRef.current);
  }

  useEffect(()=>{
    if(audioRef.current.ended && loop){
      playAudio()
    } else if(audioRef.current.ended && !loop){
      pauseAudio();
    } else if(isPlaying){
      playAudio();
    } else{
      pauseAudio();
    }
  },[audioRef,loop,isPlaying,repeat])

  const downloadSong=()=>{
    const a=document.createElement('a');
    a.href=songs[currentSong].src;
    a.download=songs[currentSong].name+".mp3";
    a.click();
    document.body.appendChild(a);
    document.body.removeChild(a);
  }
  const loopSong=()=>{
    setLoop(!loop);
  }
  return (
    <div className={`container ${theme==="Dark"?'dark':'light'}`}>
      <Credits name={songs[currentSong].name} singer={songs[currentSong].singer}/>
      <ThemeChanger theme={theme} setTheme={setTheme}/>
      <ProgressBar src={songs[currentSong].poster} musicSrc={songs[currentSong].src} audioRef={audioRef} currentTime={currentTime} duration={duration} progressBarRef={progressBarRef} setDuration={setDuration}/>
      <PlayerControls theme={theme} isPlaying={isPlaying} handlePlay={handlePlay} setCurrentSong={setCurrentSong} currentSong={currentSong} total={songs.length}/>
      <PlayerMenu theme={theme} downloadSong={downloadSong} loopSong={loopSong} loop={loop} setAccount={setAccount} setPlaylist={setPlaylist}/>
      {account && <Account closePopup={()=>setAccount(false)}/>}
      {playlist && <Playlist closePopup={()=>setPlaylist(false)} songs={songs} setCurrentSong={setCurrentSong} setIsPlaying={setIsPlaying} currentSong={currentSong}/>}
    </div>
  );
}

export default App;
