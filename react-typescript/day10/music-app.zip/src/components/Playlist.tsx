import React from 'react'
import "./Playlist.css"
import { AccountProps } from './Account'

type PlaylistProps= AccountProps & {
  songs:{
    name:string
    singer:string
    poster:string
    src:string
  }[]
  setCurrentSong:(song:number)=>void
  setIsPlaying:(isPlaying:boolean)=>void
  currentSong:number
}

export default function Playlist({closePopup,songs,setCurrentSong,setIsPlaying,currentSong}:PlaylistProps) {
  return (
    <div className='playlist-container'>
      <button className='close-account' onClick={closePopup}>X</button>
      <div className='songs-container'>
        {songs.length>0 && songs.map((song,index)=>(
          <div className={`songs-list ${currentSong===index?'active':''}`} onClick={()=>{
            setCurrentSong(index);
            setIsPlaying(true);
            closePopup();
          }}>
        <p key={index}>{song.name}</p>
        <i className='fa fa-play-circle'/>
        </div>
        ))}
      </div>
      </div>
  )
}
