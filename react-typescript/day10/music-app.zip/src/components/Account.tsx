import React from 'react'
import "./Account.css";

export type AccountProps={
  closePopup:()=>void
}
export default function Account({closePopup}:AccountProps) {
  return (
    <div className='account-container'>
      <button className='close-account' onClick={closePopup}>X</button>
      <h1>Venkatesh Mogili</h1>
      <p>mogilivenkatesh3@gmail.com</p>
    </div>
  )
}
