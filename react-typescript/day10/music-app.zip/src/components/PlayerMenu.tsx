import React from 'react'
import "./PlayerMenu.css"

type PlayerMenuProps={
  theme:string
  downloadSong:()=>void
  loopSong:()=>void
  loop:boolean
  setAccount:(account:boolean)=>void
  setPlaylist:(playlist:boolean)=>void
}

export default function PlayerMenu({theme,downloadSong,loopSong,loop,setAccount,setPlaylist}:PlayerMenuProps) {
  return (
    <div className={`menu-icons ${theme}`}>
      <i className='fa fa-user' onClick={()=>setAccount(true)}/>
      <i className='fa fa-cloud-download' onClick={downloadSong}/>
      <i className={`fa fa-refresh ${loop?'is-loop':''}`} onClick={loopSong}/>
      <i className='fa fa-list' onClick={()=>setPlaylist(true)}/>
    </div>
  )
}
