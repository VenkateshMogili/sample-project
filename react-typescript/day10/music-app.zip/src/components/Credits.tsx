import React from 'react'
import "./Credits.css";

type CreditsProps={
  name:string
  singer: string
}
export default function Credits({name,singer}:CreditsProps) {
  return (
    <div>
      <h3>{name}</h3>
      <p>-- {singer} --</p>
    </div>
  )
}
