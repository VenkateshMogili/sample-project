import React from 'react'
import "./PlayerControls.css"

type PlayerControlsProps={
  isPlaying: boolean
  handlePlay:()=>void
  theme: string
  setCurrentSong:(currentSong:number)=>void
  currentSong: number
  total:number
}

export default function PlayerControls({isPlaying,handlePlay,theme,setCurrentSong,currentSong,total}:PlayerControlsProps) {
  return (
    <div className={`controls ${theme}`}>
      <i className='fa fa-step-backward' onClick={()=>currentSong>0?setCurrentSong(currentSong-1):null}/>
      {isPlaying?<i className='fa fa-pause-circle' onClick={handlePlay}/>:<i className='fa fa-play-circle' onClick={handlePlay}/>}
      <i className='fa fa-step-forward' onClick={()=>currentSong<total-1?setCurrentSong(currentSong+1):null}/>
    </div>
  )
}
