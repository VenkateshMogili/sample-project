import React from 'react'
import "./ThemeChanger.css";

type ThemeChangerProps={
  theme: string
  setTheme:(theme:string)=>void;
}

export default function ThemeChanger({theme,setTheme}:ThemeChangerProps) {
  return (
    <div>
      {
      theme==="Dark"?
      <i className='fa fa-toggle-off' onClick={()=>setTheme("Light")}/>:
      <i className='fa fa-toggle-on' onClick={()=>setTheme("Dark")}/>
      }
    </div>
  )
}
