import React, { useEffect } from 'react'
import "./ProgressBar.css"
import { formatTime } from '../App'

type ProgressBarProps={
  src:string
  musicSrc:string
  audioRef: any
  currentTime: number
  duration: number
  progressBarRef:any
  setDuration:(duration:number)=>void
}

export default function ProgressBar({src,musicSrc,audioRef,currentTime,duration,progressBarRef,setDuration}:ProgressBarProps) {
  const onLoadedMetadata=()=>{
    const seconds=audioRef.current.duration;
    setDuration(seconds);
    progressBarRef.current.max=seconds;
  }

  useEffect(()=>{
    audioRef.current.src=musicSrc;
  },[musicSrc])
  return (
    <div>
      <div>
      <img src={src} alt="album poster" className='poster'/>
      </div>
      <audio controls={false} ref={audioRef} onLoadedMetadata={onLoadedMetadata}>
        <source src={musicSrc} type="audio/mp3"/>
      </audio>
      <div className='progress-bar'>
        <p>{formatTime(currentTime)}</p>
        <input
        type="range"
        min="0"
        className='timeline'
        defaultValue="0"
        ref={progressBarRef}
        onChange={(e)=>{
          audioRef.current.currentTime=e.target.value;
        }}/>
        <p>{formatTime(duration)}</p>
      </div>
    </div>
  )
}
