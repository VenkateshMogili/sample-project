import './App.css';
import Example1 from './Example1';
import Todos from './Todos';

function App() {
  return (
    <div>
      <Example1 />
      <Todos />
    </div>
  );
}

export default App;
