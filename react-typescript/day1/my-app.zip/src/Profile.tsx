export default function Profile() {
  return (
    <img src="https://i.imgur.com/MK3eW3As.jpg" alt='scientist' />
  )
}