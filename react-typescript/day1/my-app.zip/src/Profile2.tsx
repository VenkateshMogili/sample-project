export default function Profile2() {
  return (
    <img src="https://i.imgur.com/yXOvdOSs.jpg" alt='scientist' />
  )
}