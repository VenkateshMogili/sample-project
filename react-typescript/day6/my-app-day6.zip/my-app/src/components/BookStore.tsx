import React, { Component } from 'react'

type ComponentProps={
  bookName: string
}

type ComponentState={
  numberOfBooks: number
}

export default class BookStore extends Component<ComponentProps,ComponentState> {
  state={
    numberOfBooks:10
  }

  render() {
    return (
      <div>
        <h1>Book Store</h1>
        <p>{this.props.bookName} - {this.state.numberOfBooks}</p>
      </div>
    )
  }
}
