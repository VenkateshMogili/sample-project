import React from 'react'

type MagicValueProps={
  value: number
}

type MagicNumberPositive=MagicValueProps & {
  isPositive: boolean
  isNegative?:never
  isZero?:never
}

type MagicNumberNegative=MagicValueProps & {
  isNegative: boolean
  isPositive?:never
  isZero?:never
}

type MagicNumberZero=MagicValueProps & {
  isZero: boolean
  isPositive?:never
  isNegative?:never
}

type MagicNumberProps= MagicNumberPositive|MagicNumberNegative|MagicNumberZero;

export default function MagicNumber({value,isPositive,isNegative,isZero}:MagicNumberProps) {
  return (
    <div>
      <h1>MagicNumber</h1>
      <p>{value}</p>
      <p>{isPositive && 'Positive'}</p>
      <p>{isNegative && 'Negative'}</p>
      <p>{isZero && 'Zero'}</p>
      </div>
  )
}
