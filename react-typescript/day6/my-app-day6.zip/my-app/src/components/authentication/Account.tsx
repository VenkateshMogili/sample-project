import React from 'react'

export type AccountProps={
  name: string
}

export default function Account({name}:AccountProps) {
  return (
    <div>
      <h1>Account</h1>
      <p>User: {name}</p>
    </div>
  )
}
