import React from 'react'
import Login from './Login'
import { AccountProps } from './Account'

type PrivateRouteProps={
  isLoggedIn: boolean
  component: React.ComponentType<AccountProps>
}

export default function PrivateRoute({isLoggedIn,component:Component}:PrivateRouteProps) {
  if(isLoggedIn){
    return <Component name="Venkatesh Mogili"/>
  } else{
    return <Login/>
  }
}
