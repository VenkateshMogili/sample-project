import { useContext } from "react"
import { UserContext } from "./UserContext"

export default function User() {
  const userContext=useContext(UserContext);

  const handleLogin=()=>{
    userContext.setUser({
      name:"Venkatesh Mogili",
      email:"mogilivenkatesh3@gmail.com"
    })
  }

  const handleLogout=()=>{
    userContext.setUser(null);
  }

  return (
    <div>
      <button onClick={handleLogin}>Login</button>
      <button onClick={handleLogout}>Logout</button>
      <div>
        <p>User Name: {userContext.user?.name}</p>
        <p>User Email: {userContext.user?.email}</p>
      </div>
    </div>
  )
}
