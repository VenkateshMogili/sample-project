import React from 'react'

type ListProps<T>={
  items:T[]
}

export default function List<T extends {id:number}>({items}:ListProps<T>) {
  return (
    <div>
      {items.map(item=>(
        <p>{item.id}</p>
      ))}
    </div>
  )
}
