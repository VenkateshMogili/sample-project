import { useReducer } from 'react'

type LaptopState = {
  laptopCount: number
}

type UpdateAction = {
  type: 'increment' | 'decrement'
  payload: number
}

type ResetAction = {
  type: 'reset'
}

type LaptopAction = UpdateAction | ResetAction;

const intialState: LaptopState = {
  laptopCount: 0
}

const laptopReducer = (state: LaptopState, action: LaptopAction) => {
  switch (action.type) {
    case 'increment':
      return { ...state, laptopCount: state.laptopCount + action.payload };
    case 'decrement':
      return { ...state, laptopCount: state.laptopCount - action.payload };
    case 'reset':
      return intialState;
    default:
      return state;
  }
}

export default function Laptop() {

  const [state, dispatch] = useReducer(laptopReducer, intialState);

  return (
    <div>
      <button onClick={() => dispatch({ type: 'increment', payload: 5 })}>Buy Laptop</button>
      <button onClick={() => dispatch({ type: 'decrement', payload: 5 })}>Sell Laptop</button>
      <button onClick={() => dispatch({ type: 'reset' })}>Reset Laptops</button>

      <h2>Laptops Count:{state.laptopCount}</h2>
    </div>
  )
}
