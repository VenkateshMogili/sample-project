import React from 'react'
import Notification from './Notification'

export default function CustomComponent(props:React.ComponentProps<typeof Notification>) {
  return (
    <div>CustomComponent {props.status}</div>
  )
}
