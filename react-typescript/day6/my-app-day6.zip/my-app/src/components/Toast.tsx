import React from 'react'

type HorizontalProps='left'|'center'|'right'
type VerticalProps='top'|'center'|'bottom'
// top-left, top-center, top-right
// bottom-left, bottom-center, bottom-right
// center

type ToastProps={
  position: Exclude<`${HorizontalProps}-${VerticalProps}`,'center-center'> | 'center'
}

export default function Toast({position}:ToastProps) {
  return (
    <div>Toast - {position}</div>
  )
}
