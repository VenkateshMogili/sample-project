import React from 'react'

type TextProps<E extends React.ElementType>={
  children: React.ReactNode
  as?:E
}

type TextComponentProps<E extends React.ElementType>=TextProps<E> & Omit<React.ComponentProps<E>,keyof TextProps<E>>

export default function Text<E extends React.ElementType='div'>({children,as}:TextComponentProps<E>) {
  const Component=as||'div';
  return (
    <Component>{children}</Component>
  )
}
