import React from 'react'
import "./Header.css"

type HeaderProps={
  timer: string
  currentQuestion: number
  total: number
  score: number
}

export default function Header({timer,currentQuestion,total,score}:HeaderProps) {
  return (
    <div>
      <div className='header'>
      <h1>React Quiz App</h1>
      <p>{timer}</p>
      </div>
      <div className='question-section'>
        <p>Question {currentQuestion} out of {total}</p>
        <p className='score'>Score: {score}</p>
      </div>
    </div>
  )
}
