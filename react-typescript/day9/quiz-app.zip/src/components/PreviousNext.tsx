import React from 'react'
import "./PreviousNext.css"

type PreviousNextProps={
  currentQuestion:number
  total:number
  setCurrentQuestion:(currentQuestion:number)=>void;
  validateScore:()=>void;
}

export default function PreviousNext({currentQuestion,total,setCurrentQuestion,validateScore}:PreviousNextProps) {
  return (
    <div className='next-container'>
      <button className='previous' style={{background:currentQuestion===1?'grey':'rgb(205, 197, 50)'}} disabled={currentQuestion===1} onClick={()=>setCurrentQuestion(currentQuestion-1)}>Previous</button>

      {currentQuestion===total?<button className='next' onClick={()=>validateScore()}>Submit</button>:<button className='next' style={{background:currentQuestion===total?'grey':'rgb(205, 197, 50)'}} disabled={currentQuestion===total} onClick={()=>setCurrentQuestion(currentQuestion+1)}>Next</button>}
    </div>
  )
}
