import "./Question.css"
import { QuestionsProps } from '../App'

type QuestionProps={
  question: QuestionsProps
  currentQuestion: number
  handleAnswers:(currentQuestion:number,answer:string)=>void
  answers: string[]
}

export default function Question({question,currentQuestion,handleAnswers,answers}:QuestionProps) {
  const {question:questionText,options}=question;
  return (
    <div className='question-container'>
      <h1>{questionText}</h1>
      <ul>
        <li>a) <input type="radio" name="answer" checked={answers[currentQuestion-1]===options[0]} value={options[0]} onChange={()=>handleAnswers(currentQuestion,options[0])} id="option1" />
          <label htmlFor='option1'>{options[0]}</label>
        </li>
        <li>b) <input type="radio" name="answer" checked={answers[currentQuestion-1]===options[1]} value={options[1]} onChange={()=>handleAnswers(currentQuestion,options[1])} id="option2" />
          <label htmlFor='option2'>{options[1]}</label>
        </li>
        <li>c) <input type="radio" name="answer" checked={answers[currentQuestion-1]===options[2]} value={options[2]} onChange={()=>handleAnswers(currentQuestion,options[2])} id="option3" />
          <label htmlFor='option3'>{options[2]}</label>
        </li>
        <li>d) <input type="radio" name="answer" checked={answers[currentQuestion-1]===options[3]} value={options[3]} onChange={()=>handleAnswers(currentQuestion,options[3])} id="option4" />
          <label htmlFor='option4'>{options[3]}</label>
        </li>
      </ul>
    </div>
  )
}
