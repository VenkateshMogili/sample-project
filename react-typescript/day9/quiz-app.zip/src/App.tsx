import {useEffect, useRef, useState} from 'react';
import './App.css';
import Header from './components/Header';
import Question from './components/Question';
import PreviousNext from './components/PreviousNext';

export type QuestionsProps={
  question: string
  options: string[]
  answer:string
}

function App() {
  const [timer,setTimer]=useState<number>(300);
  const timerRef=useRef<number>(0);
  const [questions,]=useState<QuestionsProps[]>([
    {
      question:"What is ReactTS?",
      options:["Option 1","Option 2","Option 3","Option 4"],
      answer:"Option 1"
    },
    {
      question:"What is React TypeScript?",
      options:["Option 1","Option 2","Option 3","Option 4"],
      answer:"Option 2"
    },
    {
      question:"What is Nodejs?",
      options:["Option 1","Option 2","Option 3","Option 4"],
      answer:"Option 2"
    },
    {
      question:"What is NextJs?",
      options:["Option 1","Option 2","Option 3","Option 4"],
      answer:"Option 2"
    }
  ]);
  const [currentQuestion,setCurrentQuestion]=useState<number>(1);
  const [score,setScore]=useState<number>(0);
  const [answers,setAnswers]=useState<string[]>([])

  useEffect(()=>{
    timerRef.current=window.setInterval(()=>{
      setTimer((timer)=>timer-1);
    },1000)

    if(timer<=0){
      window.clearInterval(timerRef.current);
    }

    return ()=> window.clearInterval(timerRef.current)
  },[timer])

  const handleTimer=()=>{
    const minutes=Math.floor(timer/60);
    const seconds=timer-minutes*60;
    const formattedTime=(minutes<10?"0"+minutes:minutes)+":"+(seconds<10?"0"+seconds:seconds);
    return formattedTime;
  }

  const handleAnswers=(currentQuestion:number,answer:string)=>{
    const existingAnswers=[...answers];
    existingAnswers[currentQuestion-1]=answer;
    setAnswers(existingAnswers)
  }

  const validateScore=()=>{
    const finalScore=answers.reduce((prev,current,index:number)=>{
      return prev+(questions[index].answer === current?10:0)
    },0);
    setScore(finalScore);
    window.clearInterval(timerRef.current);
    setTimer(0);
  }
  return (
    <div>
      <Header timer={handleTimer()} currentQuestion={currentQuestion} total={questions.length} score={score}/>
      {timer>0?<div>
      <Question question={questions[currentQuestion-1]} currentQuestion={currentQuestion} handleAnswers={handleAnswers} answers={answers}/>
      <PreviousNext currentQuestion={currentQuestion} setCurrentQuestion={setCurrentQuestion} total={questions.length} validateScore={validateScore}/>
      </div>:
      <h1 style={{textAlign:"center"}}>Thank you</h1>}
    </div>
  );
}

export default App;
