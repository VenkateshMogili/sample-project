//npm modules
const express = require('express');
const jwt = require('jsonwebtoken');
// const users = [{id: '2f24vvg', email: 'test@test.com', password: 'password'}];
const app = express();

const bcrypt = require('bcrypt');
const saltRounds = 10;

app.use(express.json());
app.use(express.urlencoded({extended: true}));
app.set('view engine', 'ejs');

let secretKey = 'secretKey';
if (typeof localStorage === 'undefined' || localStorage === null) {
  var LocalStorage = require('node-localstorage').LocalStorage;
  localStorage = new LocalStorage('./scratch');
}
app.post('/generateHash', (req, res) => {
  bcrypt.hash(req.body.password, saltRounds, function(err, hash) {
    // Store hash in your password DB.
    res.json({hash});
  });
});

app.post('/saveMyDetails', (req, res) => {
  localStorage.setItem('data', JSON.stringify(req.body));
  console.log(localStorage.getItem('data'));
  res.send('Success');
});

app.post('/login', (req, res) => {
  let users = JSON.parse(localStorage.getItem('data'));
  if (req.body.email == users.email && req.body.password === users.password) {
    let token = jwt.sign({user: req.body}, secretKey, {expiresIn: '20s'});
    res.json({token});
  } else {
    res.json({error: 'Unauthorized'});
  }
});

app.get('/products', authenticate, (req, res) => {
  res.send('Secure Access');
});

function authenticate(req, res, next) {
  let token = req.headers['authorization'];
  jwt.verify(token, secretKey, (err, user) => {
    if (err) {
      res.json({error: err});
    } else {
      req.user = user;
      next();
    }
  });
}

app.get('/signup', (req, res) => {
  console.log(req.query);
  res.render('newuser', {
    user: req.query,
  });
});

app.listen(3000, () => {
  console.log('Listening on localhost:3000');
});
