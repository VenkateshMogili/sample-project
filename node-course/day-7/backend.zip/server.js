//npm modules
const express = require('express');
const uuid = require('uuid').v4;
const session = require('express-session');
const FileStore = require('session-file-store')(session);
const passport = require('passport');
const LocalStrategy = require('passport-local').Strategy;

const users = [{id: '2f24vvg', email: 'test@test.com', password: 'password'}];

passport.use(
  new LocalStrategy({usernameField: 'email'}, (email, password, done) => {
    // here is where you make a call to the database
    // to find the user based on their username or email address
    // for now, we'll just pretend we found that it was users[0]
    const user = users[0];
    if (email === user.email && password === user.password) {
      console.log('Local strategy returned true');
      return done(null, user);
    }
  }),
);

passport.serializeUser((user, done) => {
  done(null, user.id);
});
passport.deserializeUser((id, done) => {
  const user = users[0].id === id ? users[0] : false;
  done(null, user);
});

// create the server
const app = express();

app.use(express.json());
app.use(express.urlencoded({extended: true}));

app.use(
  session({
    genid: () => {
      return uuid();
    },
    store: new FileStore(),
    secret: 'secret key',
    resave: false,
    saveUninitialized: true,
  }),
);

app.use(passport.initialize());
app.use(passport.session());

app.get('/', (req, res) => {
  res.send('you just hit the home page\n');
});

app.get('/login', (req, res) => {
  res.send('You logged in successfully!');
});
app.post('/login', (req, res, next) => {
  passport.authenticate('local', (err, user, info) => {
    req.login(user, (err) => {
      console.log('Inside req.login() callback');
      console.log(`req.session.passport: ${JSON.stringify(req.session.passport)}`);
      console.log(`req.user: ${JSON.stringify(req.user)}`);
      return res.send('You were authenticated & logged in!\n');
    });
  })(req, res, next);
});

app.get('/products', authenticate, (req, res) => {
  res.send('Secure Access');
});

function authenticate(req, res, next) {
  if (req.isAuthenticated()) {
    next();
  } else {
    res.redirect('/');
  }
}

// tell the server what port to listen on
app.listen(3000, () => {
  console.log('Listening on localhost:3000');
});
