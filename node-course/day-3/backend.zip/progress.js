var ProgressBar = require('progress');
const chalk = require('chalk');

var bar = new ProgressBar(':bar', {complete: '=', total: 100});
var timer = setInterval(function() {
  bar.tick();
  if (bar.complete) {
    console.log(chalk.green('100% Completed'));
    clearInterval(timer);
  }
}, 10);
