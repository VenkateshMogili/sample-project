function users() {
  console.time('users()');
  for (let i = 0; i < 1000000000; i++) {
    // print
  }
  console.timeEnd('users()');
}
users();
