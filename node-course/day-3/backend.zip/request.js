const http = require('http');

let options = {
  hostname: 'localhost',
  port: 4500,
  path: '/',
  method: 'GET',
};
let request1 = http.request(options, (res) => {
  res.on('data', (data) => {
    process.stdout.write(data);
  });
});

request1.on('error', (error) => {
  console.log(error);
});

request1.end();

const https = require('https');

let options1 = {
  hostname: 'jsonplaceholder.typicode.com',
  port: 443,
  path: '/users',
  method: 'GET',
};
var ProgressBar = require('progress');
const chalk = require('chalk');

let request2 = https.request(options1, (res) => {
  var bar = new ProgressBar(':bar', {total: 100});
  res.on('data', (data) => {
    // process.stdout.write(data);
    var timer = setInterval(function() {
      bar.tick();
      if (bar.complete) {
        console.log(chalk.green('100% Completed'));
        clearInterval(timer);
      }
    }, 10);
  });
});

request2.on('error', (error) => {
  console.log(error);
});

request2.end();

// post
let options3 = {
  hostname: 'jsonplaceholder.typicode.com',
  port: 443,
  path: '/users',
  method: 'POST',
  headers: {
    'content-type': 'application/json',
  },
};
let data1 = JSON.stringify({
  name: 'venkatesh',
});
let request3 = https.request(options3, (res) => {
  res.on('data', (data) => {
    process.stdout.write(data);
  });
});

request3.on('error', (error) => {
  console.log(error);
});
request3.write(data1);

request3.end();

// update
let options4 = {
  hostname: 'jsonplaceholder.typicode.com',
  port: 443,
  path: '/users/1',
  method: 'PUT',
  headers: {
    'content-type': 'application/json',
  },
};
let data2 = JSON.stringify({
  name: 'venkatesh',
});
let request4 = https.request(options4, (res) => {
  res.on('data', (data) => {
    process.stdout.write(data);
  });
});

request4.on('error', (error) => {
  console.log(error);
});
request4.write(data2);

request4.end();

// delete
let options5 = {
  hostname: 'jsonplaceholder.typicode.com',
  port: 443,
  path: '/users/1',
  method: 'DELETE',
};
let request5 = https.request(options5, (res) => {
  res.on('data', (data) => {
    process.stdout.write(data);
  });
});

request5.on('error', (error) => {
  console.log(error);
});

request5.end();

const axios = require('axios');
axios.get('https://jsonplaceholder.typicode.com/users').then((response) => console.log(response.data));

const fetch = require('node-fetch');
fetch('https://jsonplaceholder.typicode.com/users')
  .then((response) => response.json())
  .then((data) => console.log(data));
