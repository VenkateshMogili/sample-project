const chalk = require('chalk');
// Console with colors

// warning
console.log(chalk.yellow('Warning'));
// error
console.log(chalk.red('Error'));
// info
console.log(chalk.blue('Info'));

// log
// log "Error" with red color

// log "Success" with green color
console.log(chalk.green('Success'));

// log "In Progress..." with background yellow and red color
console.log(chalk.bgYellow.red('In Progress...'));

// log "Failed" with background red and white color
console.log(chalk.bgRed.white('Failed'));

// log "Active" with background blue and white color
console.log(chalk.bgBlue.white('Active'));
