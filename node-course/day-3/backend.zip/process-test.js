require('dotenv').config();
// process env variable
console.log(process.env.API_KEY);
// process to get current working directory

console.log(process.cwd());
// process to get current process id
console.log(process.pid);

// process exit
function Sample() {
  process.exit(1);
}
Sample();
