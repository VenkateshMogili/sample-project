const mysql = require('mysql');
const configuration = {
  host: 'localhost',
  port: 3306,
  user: 'root',
  password: '',
  database: 'nodejsdatabase',
  multipleStatements: true,
};

let connection = mysql.createConnection(configuration);

connection.connect((err) => {
  if (!err) {
    console.log('connected successfully');
  } else {
    console.log('connection failed');
  }
});

// connection.query('CREATE DATABASE example2');
// connection.query('DROP DATABASE example');

let query = '';
// insert
query = "INSERT INTO users(username,password) VALUES('mogiliv3@gmail.com','vivek')";
// connection.query(query, (err) => {
//   if (!err) {
//     console.log('User created successfully!');
//   } else {
//     console.log('Error', err);
//   }
// });

// query = "SELECT * FROM users WHERE username='mogiliv3@gmail.com' and password='vivek'";
// connection.query(query, (err, result) => {
//   if (result.length > 0) {
//     console.log('User created successfully!', result);
//   } else {
//     console.log('Error', err);
//   }
// });

let username = '1 OR 1=1;show databases;DROP DATABASE sample';
// let username = '1 OR ""="';
let password = 'vivek" OR ""=";';
query = 'SELECT * FROM users WHERE id=' + username;
// query = 'SELECT * FROM users WHERE username="' + username + '"  and password="' + password + '"';
connection.query(query, (err, result) => {
  if (result.length > 0) {
    console.log('User created successfully!', result);
  } else {
    console.log('Error', err);
  }
});

module.exports = connection;

// SQL Injection and protection
// let id = "4 OR 1=1";
// // let email = 'venkatesh@gmail.com" OR ""="';
// // let password = 'venkatesh" OR ""="';
// query = "SELECT * FROM users WHERE id=" + mysql.escape(id);
// // query = 'SELECT * FROM users WHERE email="' + email + '" and password="' + password + '"';
// connection.query(query, (err, result) => {
// 	if (result.length > 0) {
// 		console.log(result);
// 	} else {
// 		console.log(err);
// 	}
// });
