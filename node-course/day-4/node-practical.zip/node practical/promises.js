function step1(value, error) {
  return new Promise((resolve, reject) => {
    if (!error) {
      resolve(value + 10);
    } else {
      reject('Promise failed at step1');
    }
  });
}
function step2(value, error) {
  return new Promise((resolve, reject) => {
    if (!error) {
      resolve(value + 10);
    } else {
      reject('Promise failed at step2');
    }
  });
}
function step3(value, error) {
  return new Promise((resolve, reject) => {
    if (!error) {
      resolve(value + 10);
    } else {
      reject('Promise failed at step3');
    }
  });
}
// Promise.all([step1,step2,step3])
step1(10, false)
  .then((result1) => step2(result1, false))
  .then((result2) => step3(result2, true))
  .then((result3) => console.log(result3))
  .catch((error) => console.log(error));
// step2(result1, function(result2, error) {
//   console.log(result2);
//   if (!error) {
//     step3(result2, function(result3, error) {
//       if (!error) {
//         console.log('Result: ', result3);
//       }
//     });
//   }
// });

const text = Promise.resolve('Hello');
let age = 20;
let timeout = new Promise((resolve, reject) => {
  setTimeout(resolve, 3000, 'Timeout function');
});
Promise.all([text, age, timeout]).then((values) => console.log(values));

let result = fetch('https://jsonplaceholder.typicode.com/users')
  .then((response) => response.json())
  .then((data) => data);
result.then((result) => console.log(result));
// console.log(result);
