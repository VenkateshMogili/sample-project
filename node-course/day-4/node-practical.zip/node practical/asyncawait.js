function step1(value, error) {
  return new Promise((resolve, reject) => {
    if (!error) {
      resolve(value + 10);
    } else {
      reject('Promise failed at step1');
    }
  });
}
function step2(value, error) {
  return new Promise((resolve, reject) => {
    if (!error) {
      resolve(value + 10);
    } else {
      reject('Promise failed at step2');
    }
  });
}
function step3(value, error) {
  return new Promise((resolve, reject) => {
    if (!error) {
      resolve(value + 10);
    } else {
      reject('Promise failed at step3');
    }
  });
}

async function result() {
  try {
    let result1 = await step1(10, false);
    let result2 = await step2(result1, false);
    let result3 = await step3(result2, false);
    console.log(result3);
    let users = await fetch('https://jsonplaceholder.typicode.com/users').then((response) => response.json());
    console.log(users);
  } catch (error) {
    console.log(error);
  } finally {
    console.log('final output');
  }
  // return result1;
}
result();
// result().then((result) => console.log(result));
