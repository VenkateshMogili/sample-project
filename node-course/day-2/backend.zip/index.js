// const http = require('http');
// const port = process.env.PORT || 4500;
// const server = http.createServer((req, res) => {
//   res.statusCode = 200;
//   res.setHeader("content-type","text/html")
//   res.end("<h1>Hello World!</h1>")
// })
// server.listen(port, () => {
//   console.log("Server is running on port "+port)
// })

import module from 'module';
const require = module.createRequire(import.meta.url);
const output = require('./hello.cjs');
console.log(output.sample);
// const { log } = require('./log');
// log("Hello");
// log("Hello");
// const { log2 } = require('./utility');
// log2("Hi")
// log2("Hi Hello")

import printIt2 from './sample.js';
printIt2()
printIt2()
printIt2()
printIt2()