function printIt() {
  console.log("Print")
}

export default printIt;