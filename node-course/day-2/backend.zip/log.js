module.exports.log = (message) => {
  console.log(message)
}