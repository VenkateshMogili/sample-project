module.exports.log2 = (message) => {
  console.log(message)
}