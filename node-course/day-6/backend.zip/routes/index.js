const users = require('./users.route');
module.exports = {
  users,
};
