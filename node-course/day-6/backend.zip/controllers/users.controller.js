const userModel = require('../models/users.model');
const getAllUsers = (req, res) => {
  userModel.getAllUsers((data) => {
    res.send({users: data});
  });
};
const getSingleUser = (req, res) => {
  userModel.getSingleUser(req.params.id, (data) => {
    res.send({users: data});
  });
};
const createUser = (req, res) => {
  userModel.createUser(req.body, (data) => {
    res.send({users: data});
  });
};
const updateUser = (req, res) => {
  userModel.updateUser(req.params.id, req.body, (data) => {
    res.send({users: data});
  });
};
const deleteUser = (req, res) => {
  userModel.deleteUser(req.params.id, (data) => {
    res.send({users: data});
  });
};
module.exports = {
  getAllUsers,
  getSingleUser,
  createUser,
  updateUser,
  deleteUser,
};
