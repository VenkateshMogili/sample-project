const mongoose = require('mongoose');
let connection = mongoose.connect(
  'mongodb://127.0.0.1:27017/nodejsdatabase',
  {useNewUrlParser: true, useUnifiedTopology: true},
  (err) => {
    if (!err) console.log('connection success');
    else console.log('connection failed');
  },
);
// async function insertUser(client) {
//   const result = await client
//     .db('nodejsdatabase')
//     .collection('users')
//     .insertOne({username: 'vivek', password: 'vivek'});
//   console.log(`New listing created with the following id: ${result.insertedId}`);
// }
// insertUser(connection);
module.exports = connection;
