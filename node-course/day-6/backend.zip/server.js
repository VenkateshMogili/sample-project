const express = require('express');
const app = express();
const cors = require('cors');
const connection = require('./db/mongoconnection');

app.use(cors());
app.use(express.json());
app.use(express.urlencoded({limit: '50mb', extended: false}));

// routes
const routes = require('./routes');
app.use((req, res, next) => {
  req.connection = connection;
  next();
});

app.use('/', routes.users);
app.listen(3000, () => {
  console.log('Server is running on 3000');
});
