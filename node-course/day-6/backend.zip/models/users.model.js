const UserModel = require('../models/user.model');
const getAllUsers = (callback) => {
  UserModel.find()
    .then((users) => {
      callback(users);
    })
    .catch((error) => {
      callback(error);
    });
};
const getSingleUser = (id, callback) => {
  UserModel.findById(id)
    .then((users) => {
      callback(users);
    })
    .catch((error) => {
      callback(error);
    });
};
const createUser = (body, callback) => {
  UserModel.insertMany(body)
    .then((users) => {
      callback(users);
    })
    .catch((error) => {
      callback(error);
    });
};
const updateUser = (id, body, callback) => {
  UserModel.update({_id: id}, {$set: body})
    .then((users) => {
      callback(users);
    })
    .catch((error) => {
      callback(error);
    });
  // UserModel.findByIdAndUpdate(id, body)
  //   .then((users) => {
  //     callback(users);
  //   })
  //   .catch((error) => {
  //     callback(error);
  //   });
};
const deleteUser = (id, callback) => {
  // UserModel.remove({_id: id})
  //   .then((users) => {
  //     callback(users);
  //   })
  //   .catch((error) => {
  //     callback(error);
  //   });
  UserModel.deleteOne({_id: id})
    .then((users) => {
      callback(users);
    })
    .catch((error) => {
      callback(error);
    });
};
module.exports = {
  getAllUsers,
  getSingleUser,
  createUser,
  updateUser,
  deleteUser,
};
