require('dotenv').config();
const nodemailer = require('nodemailer');
const sendgridTransport = require('nodemailer-sendgrid-transport');

const transporter = nodemailer.createTransport(
  sendgridTransport({
    auth: {
      api_key: process.env.API_KEY,
    },
  }),
);

transporter.sendMail({
  to: 'mogiliv3@gmail.com',
  from: 'rishindra768@gmail.com',
  subject: 'Sample subject',
  text: 'Sample description',
  html: `
          <p>This is sample html content</p>
		Thanks and Regards,
		Venkatesh Mogili.
		`,
});
