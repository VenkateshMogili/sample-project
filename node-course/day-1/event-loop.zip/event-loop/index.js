console.log("Hi");
setTimeout(() => {
  console.log("cb1")
}, 5000);
console.log("Bye")