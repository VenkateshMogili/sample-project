// const http = require('http');
// const port = process.env.PORT || 4500;
// const server = http.createServer((req, res) => {
//   req.statusCode = 200;
//   res.setHeader("content-type","text/html")
//   res.end("<h1>Hello World!</h1>")
// })
// server.listen(port, () => {
//   console.log("Server is running on port "+port)
// })

const express = require('express');
const app = express();
const router = express.Router();
const bodyParser = require('body-parser');
const cors = require('cors');

app.use(bodyParser.json());
app.use(cors({ origin: "*" }));

router.get("/getUser", (req, res) => {
  res.sendFile("<h1>Response from get user</h1>");
})
app.use(router);
app.get("/", (req,res) => {
  res.send("<h1>Hello World!</h1>")
})
app.listen(4500, () => {
  console.log("Server is running on port 4500")
})
