const mongoose = require('mongoose');
const User = require("../models/user.model");
const jwt = require("jsonwebtoken");
const UserModel = mongoose.model('User');
const loginUser = (req, res) => {
	UserModel.findOne({ email: req.body.email, password: req.body.password }, (err, rows) => {
		if (!err) {
			jwt.sign({ user: rows[0] }, "secretKey", { expiresIn: "1hr" }, (err, token) => {
				if (err) {
					res.send({ success: false, data: null, message: err ? err : "Something went wrong" });
				} else {
					res.send({ success: true, data: rows, message: "Logged In Successfully!", token });
				}
			});
		} else {
			res.send({ success: false, data: null, message: err ? err : "Something went wrong" });
		}
	});
};
const createUser = (req, res) => {
	const Users = new UserModel();
	Users.name = req.body.name;
	Users.age = req.body.age;
	Users.email = req.body.email;
	Users.password = req.body.password;
	Users.save((err,doc) => {
		if (!err) {
			res.send({ success: true, data: doc, message: "User Created Successfully!" });
		} else {
			res.send({ success: false, data: null, message: err ? err : "Something went wrong" });
		}
	});
};
const getAllUsers = (req, res) => {
	UserModel.find((err, rows) => {
		if (!err) {
			// res.render("homepage", {
			// 	user: rows[0],
			// });
			res.send({ success: true, data: rows, message: "Users data retrieved Successfully!" });
		} else {
			res.send({ success: false, data: null, message: err ? err : "Something went wrong" });
		}
	});
};
const getAllUsersLimit = (req, res) => {
	UserModel.find((err, rows) => {
		if (!err) {
			// res.render("homepage", {
			// 	user: rows[0],
			// });
			res.send({ success: true, data: rows, message: "Users data retrieved Successfully!" });
		} else {
			res.send({ success: false, data: null, message: err ? err : "Something went wrong" });
		}
	}).limit(parseInt(req.params.id)).sort('_id')
};
const getUserById = (req, res) => {
	UserModel.findById(req.params.id, (err, rows) => {
		if (!err) {
			res.send({ success: true, data: rows, message: "Users data retrieved Successfully!" });
		} else {
			res.send({ success: false, data: null, message: err ? err : "Something went wrong" });
		}
	});
};
const updateUser = (req, res) => {
	UserModel.findByIdAndUpdate(req.params.id, req.body, (err) => {
		if (!err) {
			res.send({ success: true, data: null, message: "User Updated Successfully!" });
		} else {
			res.send({ success: false, data: null, message: err ? err : "Something went wrong" });
		}
	});
};
const deleteUser = (req, res) => {
	// UserModel.remove({ _id: req.params.id }, (err) => {
	// 	if (!err) {
	// 		res.send({ success: true, data: null, message: "User Deleted Successfully!" });
	// 	} else {
	// 		res.send({ success: false, data: null, message: err ? err : "Something went wrong" });
	// 	}
	// });
	UserModel.findByIdAndRemove(req.params.id, (err) => {
		if (!err) {
			res.send({ success: true, data: null, message: "User Deleted Successfully!" });
		} else {
			res.send({ success: false, data: null, message: err ? err : "Something went wrong" });
		}
	});
};
module.exports = {
	createUser,
	getAllUsers,
	getUserById,
	updateUser,
	deleteUser,
	loginUser,
	getAllUsersLimit
};
