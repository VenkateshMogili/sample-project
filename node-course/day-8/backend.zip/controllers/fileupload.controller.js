const Contacts = require('../models/contacts.model');
const storeSingleFile = (req, res) => {
  res.send({
    success: true,
    message: 'File Uploaded Successfully!',
    url: 'http://localhost:3000/uploads/' + req.file.filename,
  });
};
const storeMultipleFiles = (req, res) => {
  let urls = req.files.map((file) => 'http://localhost:3000/uploads/' + file.filename);
  res.send({
    success: true,
    message: 'File Uploaded Successfully!',
    urls,
  });
};
module.exports = {
  storeSingleFile,
  storeMultipleFiles,
};
