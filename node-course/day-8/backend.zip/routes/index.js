// const user = require('./user.route');
// const topics = require('./topics.route');
const contacts = require('./contacts.route');
// const fileHandle = require('./filehandle.route');
// const fileUpload = require('./fileupload.route');
// const payment = require('./payment.route');
module.exports = {
  // user,
  // topics,
  contacts,
  // fileHandle,
  // fileUpload,
  // payment,
};
