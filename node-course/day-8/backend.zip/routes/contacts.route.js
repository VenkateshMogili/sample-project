const express = require("express");
const router = express.Router();
const contactsController = require("../controllers/contacts.controller");

router.post("/createContact", contactsController.createUser);
router.get("/getAllContacts", contactsController.getAllUsers);
router.get("/getContactById/:id", contactsController.getUserById);
router.put("/updateContact/:id", contactsController.updateUser);
router.delete("/deleteContact/:id", contactsController.deleteUser);
module.exports = router;
