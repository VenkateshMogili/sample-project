// Functional Programming
// let subject = function() {
// 	return 'Higher Order Function';
// };
// let username = () => 'Chinni';
// function a(b) {
// 	b();
// 	return function(name) {
// 		console.log('output from A🔥' + name);
// 	};
// }
// function b() {
// 	console.log('output from B🔥');
// }
// const c = a(b);
// c('Venkatesh');
// console.log(username());
// console.log(subject());
// First Class Functions
// let add = (num) => num + 1;
// function numbers(fn, x) {
// 	return fn(x);
// }
// let result = numbers(add, 5);
// console.log(result);

// How Functions are objects?
// let user = { name: 'Venkatesh' };
// user.profession = 'Youtuber';
// console.log(user);
// function sayHello() {
// 	console.log('Hello');
// }
// sayHello();
// sayHello.age = '10';
// console.log(sayHello.age);

// Higher Order Functions
// let numbers = [ 1, 2, 3 ];

// map()
// let result = numbers.map((element) => {
// 	element = element + 1;
// 	element = element + 2;
// 	return element;
// }); //Higher Order Function
// console.log('modified', result);
// console.log('original', numbers);
// map()
// Example: #1
const arr1 = [ 1, 2, 3 ];
// Without HOF
// const arr2 = [];
// for (let i = 0; i < arr1.length; i++) {
// 	arr2.push(arr1[i] * 2);
// }
// // prints [ 2, 4, 6 ]
// console.log(arr2);

// With HOF
// const arr2 = arr1.map((element) => element * 2);
// console.log(arr2);

// Example: #2
// const users = [ { name: 'Venkatesh' }, { name: 'Chinni' }, { name: 'Saqib' } ];
// // Create a new array of users by adding profession
// // Without HOF
// const output = [];
// for (let i = 0; i < users.length; i++) {
// 	users[i].profession = 'Full Stack Developer';
// 	output.push(users[i]);
// }
// console.log(output);
// With HOF
// const output = users.map((user) => {
// 	user.profession = 'Full Stack Developer';
// 	return user;
// });
// console.log(output);

// forEach()
// let numbers = [ 1, 2, 3 ];
// const result = [];
// numbers.forEach((element, index, array) => {
// 	element = element + 1;
// 	result.push(element);
// });
// console.log(result);
// console.log(numbers);

// filter()
// const users = [ { name: 'Venkatesh' }, { name: 'Chinni' }, { name: 'Manjunath' } ];
// let filteredUser = users.filter((user) => user.name === 'Venkatesh');
// console.log('filtered', filteredUser);
// console.log('original', users);

// filter and find
// let numbers = [ 2, 3, 1 ];
// let result = numbers.filter((number) => number === 1);
// console.log(result);
// let find = numbers.find((number) => number === 1);
// console.log(find);
// let findIndex = numbers.findIndex((number) => number === 1);
// console.log(findIndex);

// reduce()
const arr = [ 1, 2, 3, 4, 5 ];
const sum = arr.reduce(function(accumulator, currentValue, currentIndex, sourceArray) {
	return accumulator + currentValue;
}, 10);
// prints 15
console.log(sum);
