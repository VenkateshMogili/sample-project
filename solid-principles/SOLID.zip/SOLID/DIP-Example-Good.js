import { useState, useEffect }  from "react";
import axios from 'axios';

const TodosList = () => {
  const [term, setTerm] = useState("");
  const todos = useTodos(term);

  const renderTodos = () => {
      return todos.map(todo => {
          return (
              <li>
                  {`ID: ${todo.id}, Title: ${todo.title}`}
              </li>
          )
      });
  };

  return(
    <div>
    <input value={term} onChange={(e) => setTerm(e.target.value)} />
      <ul>
        {renderTodos()}
      </ul>
    </div>
  );
};

// function useTodos(term){
//     const [todos, setTodos] = useState([]);

//     useEffect(() => {
//       async function getTodos() {
//           const { data } = await axios.get("https://jsonplaceholder.typicode.com/todos/");
//           const filtered = data.filter(todo => todo.completed === false);
//           const pattern = new RegExp(term, "g");
//           const searched = filtered.filter(todo => pattern.test(todo.title));
//           setTodos(searched);
//       };
//       getTodos();
//     }, [term]);

//     return todos;
// };

// 1.
function useTodos(term){
  const [todos, setTodos] = useState([]);

  useEffect(() => {
    async function getTodos() {
        const { data } = await axios.get("https://jsonplaceholder.typicode.com/todos/");
        const filteredAndMatchedTodos = filterAndMatchTodos(data, term);
        setTodos(filteredAndMatchedTodos);
    };
    getTodos();
  }, [term]);

  return todos;
};

// function filterAndMatchTodos(todoList, searchTerm){
//   const completedTodos = todoList.filter(todo => todo.completed === false);
//   const pattern = new RegExp(searchTerm, "g");
//   const matchingTodos = filtered.filter(todo => pattern.test(todo.title));
//   return matchingTodos;
// }

// 2.
function filterAndMatchTodos(todoList, searchTerm){
  const completedTodos = filterTodoList(todoList);
  const matchingTodos = matchFilteredTodos(completedTodos, searchTerm);
  return matchingTodos;
}

function filterTodoList(todoList){
  return todoList.filter(todo => todo.completed === false);
};

function matchFilteredTodos(compeltedTodos, searchTerm){
    const pattern = new RegExp(searchTerm, "g");
    const matchingTodos = compeltedTodos.filter(todo => pattern.test(todo.title));
    return matchingTodos;
};