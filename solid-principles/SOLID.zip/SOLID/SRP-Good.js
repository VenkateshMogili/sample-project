import { useState, useEffect }  from "react";

// 1. Fetching data from API.
const useTodos = () => {
  const [todos, setTodos] = useState([]);

  useEffect(() => {
      async function getTodos() {
          const apiResponse = await fetch("https://jsonplaceholder.typicode.com/todos/");
          const data = await apiResponse.json();
          const firstTen = data.slice(0, 10);
          setTodos(firstTen);
      };
      getTodos();
  }, []);

  return todos
}

// 2. Pass the todos to the TodosList component.
export const TodosPage = () => {
  const todos = useTodos();

  return (
      <div>
          <h1>My Todos:</h1>
          <TodosList todos={todos}/>
      </div>
  )
};

// 3. Converting todo array into list of React elements.
const TodosList = ({todos}) => {

  const renderTodos = () => {
      return todos.map(todo => {
          return <TodoItem id={todo.id} title={todo.title} />
      });
  };

  return <ul>{renderTodos()}</ul>;
}

// 4. Structuring and displaying the todos.
const TodoItem = ({id, title}) => {
  return <li>{`ID: ${id}, Title: ${title}`}</li>
}
