const DisplayUser = (props) => {
  return (
    <div>
      <h1>Hello, {props.user.name}! </h1>
    </div>
  )
};

const App = () => {
  // const user = {
  //   name: "josh",
  //   age: 23,
  //   hairColor: "blonde",
  //   heightInCm: 175
  // };
  const user = {
    personalInfo: {
      name: "josh",
      age: 23
    },
    physicalFeatures: {
      hairColor: "blone",
      heightInC: 175
    }
  }
  return (
    <div>
      <DisplayUser user={user} />
    </div>
  )
};

