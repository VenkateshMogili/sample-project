import { useState, useEffect }  from "react";
import axios from 'axios';

const useTodos = () => {
  const [todos, setTodos] = useState([]);

  useEffect(() => {
      async function getTodos() {
          const data = await axios.get("https://jsonplaceholder.typicode.com/todos/");
          const firstTen = data.slice(0, 10);
          setTodos(firstTen);
      };
      getTodos();
  }, []);

  return todos
}

const TodosPage = () => {
  const todos = useTodos();

  const renderTodos = () => {
      return todos.map(todo => {
          return <TodoItem id={todo.id} title={todo.title} />
      });
  };

  return (
      <div>
          <h1>My Todos:</h1>
          <ul>
              {renderTodos()}
          </ul>
      </div>
  )
};

const TodoItem = ({id, title}) => {
  return <li>{`ID: ${id}, Title: ${title}`}</li>
}
