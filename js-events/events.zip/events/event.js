// Event Handling
let event1 = document.getElementById("event1");
event1.addEventListener("click", () => {
  console.log("Event 1 clicked");
});

// Event Bubbling
let event2 = document.getElementById("event2");
event2.addEventListener("click", () => {
  console.log("Event 2 clicked");
});
let child = document.getElementById("child");
child.addEventListener(
  "click",
  () => {
    console.log("Child clicked");
  },
  true,
);
let parent = document.getElementById("parent");
parent.addEventListener(
  "click",
  () => {
    console.log("Parent clicked");
  },
  true,
);

// Event Capturing

// Event Delegation
let tasks = document.getElementById("tasks");
tasks.addEventListener("click", (event) => {
  event.target.classList.toggle("completed");
});
