import axios from 'axios';
import React, { Component } from 'react';

export class UploadFile extends Component {
	constructor(props) {
		super(props);

		this.state = {
			selectedFiles: null,
			progress: '',
			urls: [],
			uploaded: false,
		};
	}

	fileHandler = (event) => {
		console.log(event.target.files);
		this.setState({ selectedFiles: event.target.files });
	};
	fileUpload = () => {
		let files = [];
		for (let i = 0; i < this.state.selectedFiles.length; i++) {
			let formData = new FormData();
			formData.append('file', this.state.selectedFiles[i]);
			formData.append('upload_preset', 'upload_present_unsigned');//upload_preset_unsigned is available under upload tab. create it if it's not available.
			//cloudinary_username will be available under top right corner.
axios
				.post('https://api.cloudinary.com/v1_1/cloudinary_username/image/upload', formData, {
					onUploadProgress: (progressEvent) => {
						this.setState({ progress: Math.round(progressEvent.loaded / progressEvent.total * 100) + '%' });
					},
				})
				.then((response) => {
					files.push(response.data.url);
					let urls = [ ...this.state.urls ];
					urls.push(response.data.url);
					this.setState({ urls });
					if (files.length === this.state.selectedFiles.length) {
						this.setState({ uploaded: true });
						this.fileInput.value = '';
						setTimeout(() => {
							this.setState({ uploaded: false, progress: '' });
						}, 3000);
					}
				});
		}
	};
	render() {
		return (
			<div>
				<form className='fileupload'>
					<input
						type='file'
						ref={(ref) => (this.fileInput = ref)}
						multiple
						className='inputfile'
						onChange={this.fileHandler}
					/>
					<input
						type='button'
						onClick={this.fileUpload}
						className='submit'
						value={this.state.progress ? 'Uploading..' + this.state.progress : 'Upload'}
					/>
				</form>
				{this.state.uploaded && <h1 style={{ textAlign: 'center', color: 'white' }}>Uploaded Successfully</h1>}
				<div style={{ textAlign: 'center' }}>
					{this.state.urls.length > 0 &&
						this.state.urls.map((url) => <img src={url} key={url} alt='Cloudinary pic' />)}
				</div>
			</div>
		);
	}
}

export default UploadFile;
