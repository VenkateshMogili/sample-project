import React, { useState } from 'react'
import Box from '@mui/material/Box';
import Typography from '@mui/material/Typography';
import TextField from '@mui/material/TextField';
import Checkbox from '@mui/material/Checkbox';
import Button from '@mui/material/Button';
const label = { inputProps: { 'aria-label': 'Checkbox demo' } };

export default function Register() {
  const [userData, setUserData] = useState({
    name: "",
    email: "",
    password: "",
    confirmpassword: ""
  })
  const handleChange = ({ target: { name, value } }) => {
    let updatedData = { ...userData }
    updatedData[name] = value;
    setUserData(updatedData)
  }
  const handleSubmit = (e) => {
    e.preventDefault();
    if (userData.password === userData.confirmpassword) {
      alert("Registered Successfully!");
    } else {
      alert("Passwords must match!");
    }
  }
  return (
    <form onSubmit={handleSubmit}>
      <Box sx={{ width: '100%', maxWidth: 500, background: "white", padding: 10, borderRadius: 10 }}>
        <Typography variant="h1" color="primary" gutterBottom>
          Register
        </Typography>
        <TextField
          required
          id="outlined-required"
          label="Name"
          defaultValue=""
          fullWidth
          sx={{ margin: 1 }}
          name="name"
          onChange={handleChange}
        />
        <TextField
          required
          id="outlined-required"
          label="Email"
          defaultValue=""
          type="email"
          fullWidth
          sx={{ margin: 1 }}
          name="email"
          onChange={handleChange}
        />
        <TextField
          required
          id="outlined-required"
          label="Password"
          defaultValue=""
          type="password"
          fullWidth
          sx={{ margin: 1 }}
          name="password"
          onChange={handleChange}
        />
        <TextField
          required
          id="outlined-required"
          label="Confirm Password"
          defaultValue=""
          type="password"
          fullWidth
          sx={{ margin: 1 }}
          name="confirmpassword"
          onChange={handleChange}
        />
        <Box sx={{ textAlign: "left", margin: 1 }}>
          <Checkbox {...label} defaultChecked />
          <Typography variant="caption" color="black" gutterBottom>
            Accept Terms and Conditions
          </Typography>
        </Box>
        <Button variant="contained" type="submit" sx={{ margin: 1 }} fullWidth>Register</Button>
      </Box>
    </form>
  )
}
