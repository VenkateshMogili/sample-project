import { Route, Routes } from 'react-router-dom';
import Navbar from './Navbar';
import Dashboard from './Dashboard';
import Orders from './Orders';

function App() {
  return (
    <>
    <Navbar/>
    <Routes>
      <Route path="dashboard" element={<Dashboard/>}/>
      <Route path="orders" element={<Orders/>}/>
    </Routes>

    </>
  )
}

export default App
