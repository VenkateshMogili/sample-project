import { Route, Routes, useLocation, useNavigate } from 'react-router-dom';
import Navbar from './Navbar';
import Dashboard from './Dashboard';
import Orders from './Orders';
import Login from './Login';
import Register from './Register';
import { useEffect } from 'react';

function App() {
  const {pathname}=useLocation();
  const navigate=useNavigate();
  const isLoggedIn=localStorage.getItem("token")!==null;
  const authRoutes=['/login','/register'];

  useEffect(()=>{
    if(!isLoggedIn && !authRoutes.includes(pathname)){
      navigate("/login");
    }
  },[isLoggedIn])
  return (
    <>
    {isLoggedIn && <Navbar/>}

    <Routes>
      <Route path="dashboard" element={<Dashboard/>}/>
      <Route path="orders" element={<Orders/>}/>
      <Route path="login" element={<Login/>}/>
      <Route path="register" element={<Register/>}/>
    </Routes>

    </>
  )
}

export default App
