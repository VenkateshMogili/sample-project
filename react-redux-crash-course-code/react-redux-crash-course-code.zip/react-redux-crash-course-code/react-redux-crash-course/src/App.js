// import logo from './logo.svg';
import './App.css';
import Shop from './components/Shop';
import VShop from './components/VShop';

function App() {
  return (
    <div className="App">
      <Shop/>
      <VShop/>
    </div>
  );
}

export default App;
