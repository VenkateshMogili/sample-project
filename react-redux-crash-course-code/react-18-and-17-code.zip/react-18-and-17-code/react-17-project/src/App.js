import React, { useState, useEffect } from 'react';
//import logo from './logo.svg';
import './App.css';

function App() {
  const [count, setCount] = useState(0);
  const [flag, setFlag] = useState(false);
  const handleClick = () => {
    setCount(c => c + 1);
    setFlag(f => !f);
  }
  useEffect(() => {
    console.log("Re-Rendering");
    //setTimeout(() => {
    //  setCount(c => c + 1);
    //  setFlag(f => !f);
    //}, 1000);
  }, [count, flag])
  return (
    <div className="App App2">
      <header className="App-header" style={{ fontSize: 200 }}>
        <button onClick={handleClick}>Click here</button>
      </header>
    </div>
  );
}

export default App;
