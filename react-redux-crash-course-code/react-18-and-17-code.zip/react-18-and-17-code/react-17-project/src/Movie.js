import React from 'react';
import logo from './logo.svg';
import image1 from './images/movie1.png';
import image2 from './images/movie2.png';
import image3 from './images/movie3.png';
import image4 from './images/movie4.png';
import './App.css';

function Movie() {
  return (
    <div className="App App2">
      <header className="App-header">
        <h1>Movie World!</h1>
        <div>
        <img src={image1} className="image-style"/>
        <img src={image2} className="image-style"/>
        <img src={image3} className="image-style"/>
        <img src={image4}  className="image-style"/>
        </div>
        <div className="mt5">
        <img src={image4} className="image-style"/>
        <img src={image3} className="image-style"/>
        <img src={image2} className="image-style"/>
        <img src={image1}  className="image-style"/>
        </div>
      </header>
    </div>
  );
}

export default Movie;
