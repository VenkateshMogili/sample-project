import React, { useEffect } from 'react'

export default function LoadingComponent() {
  useEffect(() => {
    setTimeout(() => {
      fetch("https://jsonplaceholder.typicode.com/photos")
        .then(res => res.json())
        .then(response => {
          console.log(response)
        })
    }, 5000);
  }, [])
  return (
    <div>LoadingComponent</div>
  )
}
