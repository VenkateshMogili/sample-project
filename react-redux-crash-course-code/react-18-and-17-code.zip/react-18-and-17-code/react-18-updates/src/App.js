import React, { Suspense, useDeferredValue, useEffect, useId, useInsertionEffect, useLayoutEffect, useState, useTransition } from 'react'
import { flushSync } from 'react-dom';
import LoadingComponent from './LoadingComponent';

export default function App(props) {
  const [isPending, startTransition] = useTransition();
  const [count, setCount] = useState(0);
  const [count2, setCount2] = useState(0);
  const [flag, setFlag] = useState(false);
  const id = useId();
  const id2 = useId();
  const finalData = useDeferredValue(props.products)
  //const handleClick = () => {
  //  flushSync(() => {
  //    setCount(c => c + 1);
  //  })
  //  flushSync(() => {
  //    setFlag(f => !f)
  //  })
  //  //setCount(c => c + 1);
  //  //setFlag(f => !f)
  //  //console.log("Re-rendered");
  //}
  const handleClick = () => {
    startTransition(() => {
      setCount(c => c + 1);
    })
  }
  const handleClick2 = () => {
    setCount2(c => c + 1);
  }
  useEffect(() => {
    console.log("Re-rendering")
    //setTimeout(() => {
    //  setCount(c => c + 1);
    //  setFlag(f => !f)
    //}, 1000)
  }, [count, flag])
  useLayoutEffect(() => {
    console.log("layout")
  }, [])
  useInsertionEffect(() => {
    console.log("rendered")
  }, [])
  return (
    <div>
      <h1 id={id}>Hello World! {id2}</h1>
      {isPending && <h1>Loading....</h1>}
      <button onClick={handleClick}>Click here {count}</button>
      <button onClick={handleClick2}>Click here {count2}</button>
      {finalData.toString()}
      <Suspense fallback={<h1>Loading...!</h1>}>
        <LoadingComponent />
      </Suspense>
    </div>
  )
}
