import { useEffect, useState } from "react";

export default function Todos() {
  const [todos,setTodos]=useState([]);

  const fetchTodos=async()=>{
    const res=await fetch("https://jsonplaceholder.typicode.com/todos");
    const todos=await res.json();
    setTodos(todos);
  };

  useEffect(()=>{
    fetchTodos();
  },[]);

  return (
    <div>
      <h1>2.Todos</h1>
      {todos.map((todo,index)=>(
        <p key={index}>{todo.title}</p>
      ))}
    </div>
  )
}
