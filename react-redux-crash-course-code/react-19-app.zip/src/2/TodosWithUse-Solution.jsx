import { use, useState,Suspense } from "react";

const fetchTodos=async()=>{
  const res=await fetch("https://jsonplaceholder.typicode.com/todos");
  const todos=await res.json();
  return todos;
};

const Todos=({todosPromise})=>{
  const todos=use(todosPromise);

  return (
    <>
    {todos.map((todo,index)=>(
        <p key={index}>{todo.title}</p>
      ))}
    </>
  )
}

export default function TodosWithUse() {
  const [todosPromise]=useState(fetchTodos());

  return (
    <div>
      <h1>Todos</h1>
      <Suspense fallback={<h2>Loading...</h2>}>
        <Todos todosPromise={todosPromise}/>
      </Suspense>
    </div>
  )
}
