import { use, useState,Suspense } from "react";

const fetchPosts=async()=>{
  const res=await fetch("https://jsonplaceholder.typicode.com/posts");
  const posts=await res.json();
  return posts;
};

const Posts=({postsPromise})=>{
  const posts=use(postsPromise);

  return (
    <>
    {posts.map((todo,index)=>(
        <p key={index}>{todo.title}</p>
      ))}
    </>
  )
}

export default function PostsWithUse() {
  const [postsPromise]=useState(fetchPosts());

  return (
    <div>
      <h1>Posts</h1>
      <Suspense fallback={<h2>Loading...</h2>}>
        <Posts postsPromise={postsPromise}/>
      </Suspense>
    </div>
  )
}
