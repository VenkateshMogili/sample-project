import { useMemo, useCallback, memo } from 'react';

function ReactCompiler() {
  const sum = useMemo(() => {
    for (let i = 0; i < 100000000; i++) {
      // do something!
    }
    return 5;
  }, []);

  const sumFun = useCallback((a, b) => {
    for (let i = 0; i < 100000000; i++) {
      // do something!
    }
    return a + b;
  }, [])

  return (
    <div>
      <h1>1.React Compiler</h1>
      <title>React Compiler</title>
      <meta name="author" value="Venkatesh"/>
      <small>useMemo - {sum}</small>
      <small>useCallback - {sumFun(1, 2)}</small>
      <small>memo</small>
    </div>
  )
}

export default memo(ReactCompiler);