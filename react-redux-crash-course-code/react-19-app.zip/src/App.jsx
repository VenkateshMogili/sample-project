import Todos from './2/Todos';
import TodosWithUse from './2/TodosWithUse';
import PostsWithUse from './2/PostsWithUse';
import './App.css';
import UserProfile from './3/UserProfile';
import UserProfileAction from './3/UserProfileAction';
import Messages from './3/Messages';
import MessagesAction from './3/MessagesAction';
import RefAsProp from './4/RefAsProp';
import ThemeComponent from './5/ThemeComponent';
import ReactCompiler from './1/ReactCompiler';

function App() {

  return (
    <>
      <h1>✨React 19 Features✨</h1>
      {/* 1 - React Compiler */}
      {/* <ReactCompiler/> */}
      {/* 2 - use hook*/}
      {/* <TodosWithUse/> */}
      {/* <PostsWithUse/> */}
      {/* 3 - Actions*/}
      {/* <UserProfileAction/> */}
      {/* <Messages/> */}
      {/* <MessagesAction/> */}
      {/* 4 - ref as prop */}
      {/* <RefAsProp/> */}
      {/* 5 - Context as Provider */}
      {/* <ThemeComponent>
        <Messages/>
      </ThemeComponent> */}
      {/* 6 - Metadata */}
      <Messages/>
    </>
  )
}

export default App;
