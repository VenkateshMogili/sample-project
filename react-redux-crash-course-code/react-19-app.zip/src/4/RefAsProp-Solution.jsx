import { useRef } from 'react'

export default function RefAsProp() {
  const inputRef=useRef(null);

  return (
    <div>
      <h1>Ref As Prop</h1>
      <Input ref={inputRef}/>
      <button onClick={()=>inputRef.current.focus()}>Focus</button>
    </div>
  )
}

const Input=({ref})=>{
  return (
    <input type="text" ref={ref}/>
  )
}