import { use, useState } from 'react'
import { ThemeContext } from '../5/ThemeComponent';

export default function Messages() {
  const value=use(ThemeContext);
  console.log(value)
  const [messages, setMessages] = useState([]);

  async function sendMessage(formData) {
    await new Promise(resolve => setTimeout(resolve, 1000));
    const sentMessage = formData.get('message');

    try {
      if (sentMessage === "Hi") {
        throw new Error("New Error");
      } else {
        setMessages((messages) => [...messages, { text: sentMessage }]);
      }
    } catch (error) {
      return "Error";
    }
  };


  const formAction = async (formData) => {
    await sendMessage(formData);
  };

  return (
    <div>
      <h1>Messages</h1>
      <title>Messages</title>
      <meta name="author" value="Venkatesh"/>

      <form action={formAction}>
      <input
          type='text'
          name='message'
          placeholder='Hello!'
        />
        <button type='submit'>Send</button>
      </form>
      {messages.map((message, index) => (
        <div key={index}>
          <span>{message.text}</span>
        </div>
      ))}
    </div>
  )
}