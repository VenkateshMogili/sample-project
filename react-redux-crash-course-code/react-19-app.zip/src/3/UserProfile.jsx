import { useState } from "react"

export default function UserProfile() {
  const [name,setName]=useState('');
  const [age,setAge]=useState('');

  const handleSubmit=(e)=>{
    e.preventDefault();
    console.log(name,age);
  }

  return (
    <form onSubmit={handleSubmit}>
      <h1>User Form</h1>
      <div>
      <input type="text" placeholder='Enter name' value={name} onChange={(e)=>setName(e.target.value)} />
      </div>
      <div>
      <input type="text" placeholder='Enter age' value={age} onChange={(e)=>setAge(e.target.value)}  />
      </div>
      <button>Submit</button>
    </form>
  )
}
