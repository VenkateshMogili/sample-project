import { useOptimistic, useState } from 'react'

export default function MessagesAction() {
  const [messages, setMessages] = useState([]);
  const [optimisticMessages, addOptimisticMessage] = useOptimistic(messages,
    (state,newMessage)=>[...state,{text:newMessage,sending:true}]
  );

  async function sendMessage(formData) {
    await new Promise(resolve => setTimeout(resolve, 1000));
    const sentMessage = formData.get('message');

    try {
      if (sentMessage === "Hi") {
        throw new Error("New Error");
      } else {
        setMessages((messages) => [...messages, { text: sentMessage }]);
      }
    } catch (error) {
      return "Error";
    }
  };


  const formAction = async (formData) => {
    addOptimisticMessage(formData.get("message"));

    await sendMessage(formData);
  };

  return (
    <div>
      <h1>Messages</h1>
      <title>Messages</title>
      <meta name="author" content="Venkatesh" />

      <form action={formAction}>
      <input
          type='text'
          name='message'
          placeholder='Hello!'
        />
        <button type='submit'>Send</button>
      </form>
      {optimisticMessages.map((message, index) => (
        <div key={index}>
          <span>{message.text}</span>
          {message.sending && <small>Sending...</small>}
        </div>
      ))}
    </div>
  )
}