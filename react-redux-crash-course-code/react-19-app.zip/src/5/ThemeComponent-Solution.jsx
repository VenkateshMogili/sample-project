import { createContext } from "react";

export const ThemeContext = createContext('');

export default function ThemeComponent({children}) {
  return (
    <ThemeContext value="dark">
      {children}
    </ThemeContext>
  );
}