const express = require('express');
const {storeSingleFile, storeMultipleFiles} = require('../controllers/fileupload.controller');
const upload = require('../middleware/fileupload');
const router = express.Router();
router.post('/upload-single', upload.single('file'), storeSingleFile);
router.post('/upload-multiple', upload.array('files', 10), storeMultipleFiles);
module.exports = router;
