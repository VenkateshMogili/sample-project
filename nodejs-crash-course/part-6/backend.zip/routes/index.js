const user = require("./user.route");
const topics = require("./topics.route");
module.exports = {
	user,
	topics,
};
