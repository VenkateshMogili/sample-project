function log(msg) {
	console.log(msg);
}
export default log;

function hello() {
	console.log("Hello");
}
export { hello };
