import module from "module";
const require = module.createRequire(import.meta.url);
const http = require("http");
const hostname = "localhost";
const port = 3000;
const server = http.createServer((req, res) => {
	res.statusCode = 200;
	res.setHeader("Content-Type", "text/html");
	res.end("<h1>Hello World!</h1>");
});
server.listen(port, hostname, () => {
	console.log(`Server is running on localhost:${port}`);
});

const hello = require("./hello.cjs");
console.log(hello);
const output = require("./sample.cjs");
console.log(output.sample);
const output2 = require("./log");
output2.log("Hello, this is venkatesh");
const output3 = require("./utility");
output3.log("Utility");
import * as logger from "./es6.js";
logger.default("Hello Hi");
logger.hello();
