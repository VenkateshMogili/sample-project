module.exports.log = function(msg) {
	console.log(msg);
};
