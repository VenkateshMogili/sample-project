// module.exports.sample = "Hello World!";
exports.sample = "Hello World!";
