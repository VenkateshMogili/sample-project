const express = require('express');
const {createOrder, successOrder} = require('../controllers/payment.controller');
const router = express.Router();
router.get('/createOrder/:amount', createOrder);
router.get('/successOrder', successOrder);
module.exports = router;
