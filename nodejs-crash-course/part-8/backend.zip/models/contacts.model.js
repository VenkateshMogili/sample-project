let query = "";
const create = (connection, data, callback) => {
	query = "INSERT INTO contacts SET ?";
	connection.query(query, [ data ], callback);
};
const getAll = (connection, callback) => {
	query = "SELECT * FROM contacts";
	connection.query(query, callback);
};
const getOne = (connection, id, callback) => {
	query = "SELECT * FROM contacts WHERE ?";
	connection.query(query, [ { id } ], callback);
};
const update = (connection, id, data, callback) => {
	query = "UPDATE contacts SET ? WHERE ?";
	connection.query(query, [ data, { id } ], callback);
};
const remove = (connection, id, callback) => {
	query = "DELETE FROM contacts WHERE ?";
	connection.query(query, [ { id } ], callback);
};
module.exports = {
	create,
	getAll,
	getOne,
	update,
	remove,
};
