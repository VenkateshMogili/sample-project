const user = require("./user.route");
const topics = require("./topics.route");
const contacts = require("./contacts.route");
module.exports = {
	user,
	topics,
	contacts,
};
