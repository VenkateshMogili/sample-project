import React from 'react'
import { Text, View, StyleSheet, ImageBackground, Image, ScrollView } from 'react-native'

export default function UsersList() {
  const users = [
    {
      name: "Venkatesh Mogili"
    },
    {
      name: "Chinni"
    },
    {
      name: "Chinna"
    },
    {
      name: "Satish"
    },
    {
      name: "Rishi"
    },
    {
      name: "Saqib"
    },
    {
      name: "Laxmi"
    },
    {
      name: "Parvathi"
    },
    {
      name: "Parvathi"
    },
    {
      name: "Parvathi"
    },
    {
      name: "Parvathi"
    }
  ]
  const SingleItem = ({ name, index }) => {
    return (
      <View style={styles.row} key={index}>
        <View>
          <Image source={require("../assets/logo.png")} style={styles.logo} />
        </View>
        <View>
          <View style={styles.name}>
            <Text style={styles.username}>{name}</Text>
            <Text>4 mins ago</Text>
          </View>
          <Text style={styles.details}>This is simple text.</Text>
        </View>
      </View>
    )
  }
  return (
    <ScrollView>
      <ImageBackground source={require("../assets/bg.png")} style={styles.bgImg}>
        <Text style={styles.heading}>Users List</Text>
        {users.map((user, index) => (
          <View>
            <SingleItem {...user} index={index} />
            <View style={styles.bar} />
          </View>
        ))}
      </ImageBackground>
    </ScrollView>
  )
}
const styles = StyleSheet.create({
  bgImg: {
    width: "100%",
    height: "100%"
  },
  logo: {
    width: 60,
    height: 60,
    borderRadius: 100,
    margin: 5,
  },
  name: {
    flexDirection: "row",
    justifyContent: "space-between",
    width: "70%",
    alignItems: "center"
  },
  row: {
    flexDirection: "row",
    alignItems: "center",
    marginVertical: 10
  },
  username: {
    fontWeight: "bold",
    color: "black",
    margin: 5,
    width: "95%"
  },
  details: {
    margin: 5
  },
  heading: {
    color: "white",
    fontSize: 30,
    textAlign: "center"
  },
  bar: {
    borderWidth: 0.5,
    borderColor: "white"
  }
})