import React, { useState } from "react";
import { Image, ScrollView, StyleSheet, Text, TextInput, View } from "react-native";

export default function App() {
  const [biodata, setBiodata] = useState("");
  return (
    <ScrollView>
      <View style={styles.container}>
        <Image source={require("./assets/profile.jpg")} fadeDuration={2000} style={styles.imgStyle} />
        {/*<Image source={{ uri: "https://www.espncricinfo.com/db/PICTURES/CMS/322600/322614.square.png" }} blurRadius={0} fadeDuration={3000} style={styles.imgStyle} />*/}
        <Text style={styles.textStyle}>Venkatesh Mogili</Text>
        <Text style={styles.biodata}>{biodata.length > 0 ? biodata : "Please enter your biodata..."}</Text>
        <TextInput placeholder="Enter your biodata" style={styles.inputStyle} onChangeText={(text) => setBiodata(text)} onFocus={() => console.log("Focused")} onSubmitEditing={() => console.log("Edited")} multiline editable={true} keyboardType="numeric" />
      </View>
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: "tomato",
    borderColor: "skyblue",
    borderWidth: 30,
    borderRadius: 10,
    borderStyle: "solid",
    elevation: 5,
    margin: 10,
    //opacity: 0.8,
    backfaceVisibility: "visible",
  },
  imgStyle: {
    width: '100%',
    height: 400,
    resizeMode: "cover",
    backgroundColor: "black",
    //tintColor: "orange",
    //opacity: 0.5,
    borderWidth: 0.1,
    borderColor: "black",
    //borderRadius: 5,
  },
  textStyle: {
    color: "white",
    fontSize: 30,
    //fontStyle: "italic",
    //fontWeight: "bold",
    //fontVariant: ["small-caps"],
    letterSpacing: 10,
    lineHeight: 40,
    textAlign: "center",
    textTransform: "capitalize",
    fontFamily: "PoppinsBold",
  },
  inputStyle: {
    borderWidth: 1,
    borderColor: "white",
    margin: 10,
    borderRadius: 10,
    padding: 10,
  },
  biodata: {
    fontSize: 20,
    margin: 10,
    padding: 10,
    color: 'black',
    textAlign: "justify",
  }
});
