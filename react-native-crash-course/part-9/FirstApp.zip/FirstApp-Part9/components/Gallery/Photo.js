import React, { useEffect, useState } from 'react';
import { Button, FlatList, Image, StyleSheet, Text, View } from 'react-native';

export default function Photo({ id, url, title, selectedPhoto, deletePhoto }) {
  return (
    <View style={styles.message}>
      <Image source={{ uri: url }} style={styles.image} />
      <Text style={styles.heading}>{title}</Text>
      <Button title="Edit" onPress={() => selectedPhoto({ id, title })} />
      <Button title="Delete" color="tomato" onPress={() => deletePhoto(id)} />
    </View>
  )
}

const styles = StyleSheet.create({
  heading: {
    fontSize: 20,
    padding: 5,
  },
  body: {
    fontSize: 14,
    padding: 5,
  },
  message: {
    padding: 10,
    margin: 10
  },
  image: {
    height: 200
  }
})
