import React, { useEffect, useState } from 'react';
import { Button, FlatList, StyleSheet, Text, TextInput, TouchableOpacity, useWindowDimensions, View } from 'react-native';
import Photo from './Photo';
import axios from 'axios';

export default function Photos() {
  const [photos, setPhotos] = useState([]);
  const [title, setTitle] = useState("");
  const [selectedId, setSelectedId] = useState(null);

  const fetchPhotos = () => {
    //GET Method
    axios.get("https://jsonplaceholder.typicode.com/photos?_limit=10")
      .then(response => setPhotos(response.data))
  }
  const addPhoto = () => {
    //POST Method
    const requestBody = {
      title
    }
    axios.post("https://jsonplaceholder.typicode.com/photos", {
      body: JSON.stringify(requestBody)
    })
      .then(response => {
        if (response) {
          requestBody.id = photos.length + 1;
          requestBody.url = "https://source.unsplash.com/random/200x200"
          let updatedMessages = [...photos, requestBody]
          setPhotos(updatedMessages);
        }
      })
  }
  const updatePhoto = () => {
    //PUT Method
    const requestBody = {
      title
    }
    axios.put("https://jsonplaceholder.typicode.com/photos/" + selectedId, {
      body: JSON.stringify(requestBody)
    })
      .then(response => {
        if (response) {
          let updatedMessages = [...photos];
          let index = updatedMessages.findIndex((message) => message.id === selectedId);
          updatedMessages[index] = { ...updatedMessages[index], ...requestBody }
          setPhotos(updatedMessages);
          setSelectedId(null);
          setTitle("");
        }
      })
  }
  const deletePhoto = (id) => {
    //DELETE Method
    axios.delete("https://jsonplaceholder.typicode.com/photos/" + id)
      .then(response => {
        if (response) {
          let updatedMessages = [...photos];
          let index = updatedMessages.findIndex((message) => message.id === id);
          updatedMessages.splice(index, 1);
          setPhotos(updatedMessages);
        }
      })
  }
  const selectedPhoto = (requestBody) => {
    setTitle(requestBody.title);
    setSelectedId(requestBody.id)
  }
  useEffect(() => {
    fetchPhotos();
  }, [])
  return (
    <View>
      <Text style={styles.heading}>Gallery</Text>
      <View style={styles.form}>
        <TextInput
          placeholder='Title'
          style={styles.input}
          value={title}
          onChangeText={(text) => setTitle(text)}
          testID="title"
        />
        <TouchableOpacity testID='add' style={styles.button} onPress={selectedId === null ? addPhoto : updatePhoto}>
          <Text style={styles.add}>{selectedId === null ? "Add" : "Update"}</Text>
        </TouchableOpacity>
      </View>
      <View style={styles.list}>
        <FlatList
          data={photos}
          renderItem={({ item }) =>
            <Photo
              {...item}
              selectedPhoto={selectedPhoto}
              deletePhoto={deletePhoto}
            />}
          ItemSeparatorComponent={() => (<View style={styles.border} />)}
        />
      </View>
    </View>
  )
}

const styles = StyleSheet.create({
  heading: {
    fontSize: 30,
    textAlign: "center",
    color: "white",
    backgroundColor: "purple",
    padding: 5
  },
  border: {
    borderWidth: 0.5,
    borderColor: "lightgray",
  },
  input: {
    borderWidth: 1,
    padding: 5
  },
  button: {
    backgroundColor: "black",
    padding: 5
  },
  add: {
    color: "white",
    textAlign: "center",
    fontSize: 16
  },
  form: {
    padding: 10,
    margin: 10
  },
  list: {
    height: 500
  }
})
