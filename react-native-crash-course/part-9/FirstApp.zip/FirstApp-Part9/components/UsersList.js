import React, { useState, useEffect } from 'react'
import { Text, View, StyleSheet, ImageBackground, Image, ScrollView, TextInput, Button } from 'react-native'
import { firebase } from '@react-native-firebase/database';
export default function UsersList() {
  const [username, setUsername] = useState("");
  const [description, setDescription] = useState("");
  const [users, setUsers] = useState({})
  const [isEdit, setEdit] = useState("")
  const addUser = () => {
    let response = firebase.app().database("https://rnfirebase-416da-default-rtdb.asia-southeast1.firebasedatabase.app/").ref("/users").push(
      {
        username,
        description
      }
    )
  }
  const editUser = () => {
    firebase.app().database("https://rnfirebase-416da-default-rtdb.asia-southeast1.firebasedatabase.app/").ref(`/users/${isEdit}`).update(
      {
        username,
        description
      }
    );
  }
  const deleteUser = (key) => {
    firebase.app().database("https://rnfirebase-416da-default-rtdb.asia-southeast1.firebasedatabase.app/").ref(`/users/${key}`).remove();
  }
  const getUsers = () => {
    firebase.app().database("https://rnfirebase-416da-default-rtdb.asia-southeast1.firebasedatabase.app/").ref("/users").on('value', snapshot => {
      setUsers(snapshot.val())
    });
  }
  const editUserData = (username, description, key) => {
    setUsername(username);
    setDescription(description);
    setEdit(key)
  }
  useEffect(() => {
    getUsers();
  }, [])
  const SingleItem = ({ username: name, description, index }) => {
    return (
      <View style={styles.row} key={index}>
        <View>
          <Image source={require("../assets/logo.png")} style={styles.logo} />
        </View>
        <View>
          <View style={styles.name}>
            <Text style={styles.username}>{name}</Text>
            <Text>4 mins ago</Text>
          </View>
          <Text style={styles.details}>{description}</Text>
          <View style={styles.row}>
            <Button title="Edit" onPress={() => editUserData(name, description, index)} />
            <Button title="Delete" color="tomato" onPress={() => deleteUser(index)} />
          </View>
        </View>
      </View>
    )
  }
  return (
    <ScrollView>
      <ImageBackground source={require("../assets/bg.png")} style={styles.bgImg}>
        <Text style={styles.heading}>Users List</Text>
        <View>
          <TextInput placeholder="Username" placeholderTextColor="white" style={styles.input} value={username} onChangeText={(text) => setUsername(text)} />
          <TextInput placeholder="Description" placeholderTextColor="white" style={styles.input} value={description} onChangeText={(text) => setDescription(text)} />
          <View style={styles.details}>
            {isEdit.length > 0 ? <Button title="Edit User" color="tomato" onPress={() => editUser()} /> : <Button title="Add User" color="tomato" onPress={() => addUser()} />}
          </View>
        </View>
        {Object.keys(users).map((key) => (
          <View>
            <SingleItem {...users[key]} index={key} />
            <View style={styles.bar} />
          </View>
        ))}
      </ImageBackground>
    </ScrollView>
  )
}
const styles = StyleSheet.create({
  bgImg: {
    width: "100%",
    height: "100%"
  },
  logo: {
    width: 60,
    height: 60,
    borderRadius: 100,
    margin: 5,
  },
  name: {
    flexDirection: "row",
    justifyContent: "space-between",
    width: "70%",
    alignItems: "center"
  },
  row: {
    flexDirection: "row",
    alignItems: "center",
    marginVertical: 10
  },
  username: {
    fontWeight: "bold",
    color: "black",
    margin: 5,
    width: "95%"
  },
  details: {
    margin: 5
  },
  heading: {
    color: "white",
    fontSize: 30,
    textAlign: "center"
  },
  bar: {
    borderWidth: 0.5,
    borderColor: "white"
  },
  input: {
    elevation: 1,
    borderRadius: 100,
    padding: 10,
    margin: 10,
    //width: 350,
    textAlign: "center",
    fontSize: 20,
    backgroundColor: "skyblue",
    color: "white"
  },
})