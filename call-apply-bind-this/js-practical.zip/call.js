// Box Object containing height and width
function Box(height, width) {
  this.height = height;
  this.width = width;
}
// Widget Object containing height,width and color
function Widget(height, width, color) {
  Box.call(this, height, width);
  this.color = color;
}

// create an instance for Widget.
let widget = new Widget(100, 200, "red");
console.log(widget);

let person = {
  name: "Venkatesh",
};
function sample(a, b, c) {
  console.log("Sample", a, b, c, this.name);
}

sample.call(person, 1, 2, 3);
