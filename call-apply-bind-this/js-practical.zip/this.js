// this always refers to an object
let person = {
  firstName: "Venkatesh",
  getName: function() {
    console.log(this);
  },
};
let result = person.getName();

// this refers window object in global context

console.log(this);

// this refers to an object where we call it.
const counter = {
  count: 0,
  increment: function() {
    console.log(this);
    this.count++;
    console.log(this.count);
  },
};

document.querySelector(".btn").addEventListener("click", counter.increment);
