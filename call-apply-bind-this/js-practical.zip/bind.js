// submit function
function submit(name) {
  console.log("Submitted", name);
}
// UserComponent
const UserComponent = {
  render: function() {
    this.submit();
  },
};
// UserComponent.render();

// result
let result = submit.bind(UserComponent, "Venkatesh");
result();
