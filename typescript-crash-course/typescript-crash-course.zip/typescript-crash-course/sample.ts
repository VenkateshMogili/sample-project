console.log("Hello World!");
let message = "Hello World!";
let hello = 5;
hello = 10;
let age: number;
age = 10;
age = 20;
//age = "asdf";
