import React from 'react'
import Button from './reusable/Button'
import Item from './reusable/Item'
import './main.css'
export default function Main() {
  let data = [
    {
      date: "June 26, 2017 5:59 PM",
      toAddress: "To Address",
      money: "-0.1 EEUR",
      convert: "25 USD"
    },
    {
      date: "June 25, 2017 5:59 PM",
      toAddress: "To Address",
      money: "-0.1 EEUR",
      convert: "25 USD"
    },
    {
      date: "June 29, 2017 5:59 PM",
      toAddress: "To Address",
      money: "-0.1 EEUR",
      convert: "25 USD"
    },
    {
      date: "June 26, 2017 5:59 PM",
      toAddress: "To Address",
      money: "-0.1 EEUR",
      convert: "25 USD"
    },
    {
      date: "June 25, 2017 5:59 PM",
      toAddress: "To Address",
      money: "-0.1 EEUR",
      convert: "25 USD"
    },
    {
      date: "June 29, 2017 5:59 PM",
      toAddress: "To Address",
      money: "-0.1 EEUR",
      convert: "25 USD"
    },
    {
      date: "June 26, 2017 5:59 PM",
      toAddress: "To Address",
      money: "-0.1 EEUR",
      convert: "25 USD"
    },
    {
      date: "June 25, 2017 5:59 PM",
      toAddress: "To Address",
      money: "-0.1 EEUR",
      convert: "25 USD"
    },
    {
      date: "June 29, 2017 5:59 PM",
      toAddress: "To Address",
      money: "-0.1 EEUR",
      convert: "25 USD"
    }
  ]
  return (
    <div>
      <h1>Hello</h1>
      <div className="d-flex row">
      <Button title="Send EEUR" />
      <Button title="Sell EEUR" />
      <Button title="Buy EEUR" />
      </div>
      {data !== undefined && data.length > 0 && data.map((item, index) => (
        <Item {...item} index={index}/>
      ))}

      <Button title="All Transactions" />
    </div>
  )
}
