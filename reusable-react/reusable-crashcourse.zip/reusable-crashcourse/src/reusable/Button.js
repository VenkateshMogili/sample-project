import React from 'react'
import './button-style.css'

export default function Button({ title }) {
  return (
    <button>{title}</button>
  )
}
