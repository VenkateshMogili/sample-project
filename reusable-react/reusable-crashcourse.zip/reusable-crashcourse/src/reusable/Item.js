import React from 'react'
import './item-style.css'
export default function Item({ date, toAddress, money, convert,index }) {
  return (
    <li key={index}>
      <span>{date}</span>
      <span>{toAddress}</span>
      <span className="money">{money}<br />
        <small>{convert}</small></span>
    </li>
  )
}
