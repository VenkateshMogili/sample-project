import React, { useRef } from 'react'
import { Button, DrawerLayoutAndroid, Text, View } from 'react-native'

export default function DrawerExample() {
  const drawer = useRef(null);
  const menuView = () => (
    <View>
      <Text>This is menu</Text>
      <Button title="Close drawer" onPress={() => drawer.current.closeDrawer()} />
    </View>
  )
  return (
    <DrawerLayoutAndroid
      ref={drawer}
      drawerWidth={300}
      drawerPosition="left"
      renderNavigationView={menuView}
    >
      <View>
        <Text>Drawer Example</Text>
        <Button title="Open Drawer" onPress={() => drawer.current.openDrawer()} />
      </View>
    </DrawerLayoutAndroid>
  )
}
