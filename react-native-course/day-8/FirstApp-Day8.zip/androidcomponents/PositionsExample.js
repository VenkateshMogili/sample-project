import React from 'react'
import { View } from 'react-native'

export default function PositionsExample() {
  return (
    <View style={{ flex: 1, flexDirection: "row", flexWrap: "wrap", justifyContent: "center" }}>
      <View style={{ backgroundColor: "black", height: 100, width: 300, flexShrink: 1 }}>

      </View>
      <View style={{ backgroundColor: "red", height: 100, width: 100, position: "relative", right: 10, bottom: 20 }}>

      </View>
      <View style={{ backgroundColor: "green", height: 100, width: 100, position: "absolute", bottom: 50, right: 30, }}>

      </View>
      <View style={{ backgroundColor: "black", height: 100, width: 300, flexShrink: 1 }}>

      </View>
      <View style={{ backgroundColor: "red", height: 100, width: 100, position: "relative", right: 10, bottom: 20 }}>

      </View>
      <View style={{ backgroundColor: "magenta", height: 100, width: 100 }}>

      </View>
      <View style={{ backgroundColor: "black", height: 100, width: 300, flexShrink: 1 }}>

      </View>
      <View style={{ backgroundColor: "red", height: 100, width: 100, position: "relative", right: 10, bottom: 20 }}>

      </View>
      <View style={{ backgroundColor: "magenta", height: 100, width: 100 }}>

      </View>
    </View>
  )
}
