import React from 'react'
import { View } from 'react-native'
import BackhandlerExample from './BackhandlerExample'
import DrawerExample from './DrawerExample'
import OrientationExample from './OrientationExample'
import PermissionsExample from './PermissionsExample'
import PlatformExample from './PlatformExample'
import ToastExample from './ToastExample'
import TouchableExample from './TouchableExample'

export default function AndroidComponents() {
  return (
    <View style={{ flex: 1 }}>
      {/*<BackhandlerExample />*/}
      {/*<DrawerExample />*/}
      {/*<PermissionsExample />*/}
      {/*<ToastExample />*/}
      {/*<TouchableExample />*/}
      {/*<PlatformExample />*/}
      <OrientationExample />
    </View>
  )
}
