import React from 'react'
import { Button, PermissionsAndroid, Text, View } from 'react-native'

export default function PermissionsExample() {
  const openCamera = async () => {
    try {
      //let granted = await PermissionsAndroid.check("android.permission.CAMERA");
      //let granted = await PermissionsAndroid.request(
      //  PermissionsAndroid.PERMISSIONS.CAMERA,
      //  {
      //    title: "Allow Camera",
      //    message: "Please allow camera",
      //    buttonPositive: "Ok",
      //    buttonNegative: "Cancel",
      //    buttonNeutral: "Ask Me Later"
      //  }
      //);
      let granted = await PermissionsAndroid.requestMultiple([
        PermissionsAndroid.PERMISSIONS.CAMERA,
        PermissionsAndroid.PERMISSIONS.READ_CONTACTS
      ]
      );
      if (granted === PermissionsAndroid.RESULTS.GRANTED) {
        console.log("Permission granted")
      } else {
        console.log("Permission denied")
      }
      console.log(granted);
    } catch (err) {
      console.log(err)
    }
  }
  return (
    <View>
      <Text>Permissions</Text>
      <Button title="Open Camera" onPress={openCamera} />
    </View>
  )
}
