import { StyleSheet } from 'react-native';

export const styles = StyleSheet.create({
  imgStyle: {
    width: "100%",
    height: 400
  },
  margin10: {
    margin: 10
  },
  headingStyle: {
    fontSize: 30,
    fontFamily: "PoppinsBold",
    textAlign: "center"
  },
  fs20: {
    fontSize: 20
  },
  inputStyles: {
    margin: 10,
    borderWidth: 1,
    borderColor: "gray",
    borderRadius: 10,
    padding: 10
  }
})