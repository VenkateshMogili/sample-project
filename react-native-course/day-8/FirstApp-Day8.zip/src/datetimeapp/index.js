import moment from 'moment';
import React, { useEffect, useState } from 'react'
import { Text, View, Button } from 'react-native'
import SplashScreen from 'react-native-splash-screen';
import DateTimePicker from '@react-native-community/datetimepicker';

export default function DateTimeApp() {
  const [date, setDate] = useState(new Date());
  const [mode, setMode] = useState('date');
  const [show, setShow] = useState(false);

  const onChange = (event, selectedDate) => {
    const currentDate = selectedDate || date;
    setShow(Platform.OS === 'ios');
    setDate(currentDate);
  };

  const showMode = (currentMode) => {
    setShow(true);
    setMode(currentMode);
  };

  const showDatepicker = () => {
    showMode('date');
  };

  const showTimepicker = () => {
    showMode('time');
  };
  useEffect(() => {
    setTimeout(() => {
      SplashScreen.hide();
    }, 1000);
  }, []);
  return (
    <View>
      <Text style={{ fontSize: 30, textAlign: "center", fontFamily: "PoppinsBold" }}>Date Time Picker</Text>
      <Text style={{ fontSize: 20, textAlign: "center", fontFamily: "PoppinsBold" }}>Date: {moment(date).format("DD-MM-YYYY")}</Text>
      <Text style={{ fontSize: 20, textAlign: "center", fontFamily: "PoppinsBold" }}>Time: {moment(date).format("hh:MM:SS A")}</Text>
      <View style={{ margin: 5 }}>
        <Button onPress={showDatepicker} title="Show date picker!" />
      </View>
      <View style={{ margin: 5 }}>
        <Button onPress={showTimepicker} title="Show time picker!" />
      </View>
      {show && (
        <DateTimePicker
          testID="dateTimePicker"
          value={date}
          mode={mode}
          is24Hour={false}
          display="default"
          onChange={onChange}
        />
      )}
    </View>
  )
}
