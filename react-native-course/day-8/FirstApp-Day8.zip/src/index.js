import React, { useState, useEffect } from 'react'
import { Image, ImageBackground, ScrollView, StyleSheet, Text, TextInput, View } from 'react-native'
import SplashScreen from 'react-native-splash-screen';
export default function CourseApp() {
  const [isVisible, setVisible] = useState(false);
  useEffect(() => {
    setTimeout(() => {
      SplashScreen.hide();
    }, 1000);
  }, [])
  return (
    <ImageBackground source={{ uri: "https://png.pngtree.com/thumb_back/fh260/background/20200714/pngtree-modern-double-color-futuristic-neon-background-image_351866.jpg" }} style={styles.container}>
      <ScrollView contentContainerStyle={styles.container}>
        <View style={styles.profile}>
          <Image source={require("../assets/profile.jpg")} style={styles.imageStyle} />
          <Text style={styles.heading}>Welcome To VM Training</Text>
          {!isVisible && <View style={styles.inputs}>
            <TextInput placeholder="Username" placeholderTextColor="white" style={styles.inputStyle} />
            <TextInput placeholder="Password" placeholderTextColor="white" style={styles.inputStyle} />
          </View>}

          {isVisible &&
            <>
              <View style={styles.courses}>
                <Text style={[styles.course, styles.course1]}>ReactJS Course</Text>
                <Text style={[styles.course, styles.course2]}>NodeJS   Course</Text>
                <Text style={[styles.course, styles.course3]}>JavaScript Course</Text>
                <Text style={[styles.course, styles.course4]}>Full Stack Course</Text>
              </View>
              <View>
                <Text style={styles.close} onPress={() => setVisible(false)}>X</Text>
              </View>
            </>}
        </View>
        <View>
          <View>
            <Text style={styles.textStyle} onPress={() => setVisible(true)}>Login</Text>
          </View>
          <View>
            <Text style={[styles.textStyle, styles.register]}>Register</Text>
          </View>
        </View>
      </ScrollView>
    </ImageBackground>
  )
}
const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: "space-between",
  },
  profile: {
    alignItems: "center"
  },
  inputs: {
    alignSelf: "stretch"
  },
  imageStyle: {
    width: 200,
    height: 200,
    borderRadius: 100
  },
  heading: {
    fontSize: 20,
    fontFamily: "PoppinsBold",
    color: "white"
  },
  inputStyle: {
    borderWidth: 1,
    borderColor: "white",
    padding: 10,
    margin: 5,
    color: "yellow"
  },
  textStyle: {
    fontSize: 20,
    textAlign: "center",
    backgroundColor: "dodgerblue",
    padding: 10,
    color: "white",
    fontFamily: "PoppinsBold",
  },
  register: {
    backgroundColor: "tomato"
  },
  courses: {
    flex: 1,
    flexDirection: "row",
    flexWrap: "wrap",
    justifyContent: "space-between",
    alignItems: "center"
  },
  course: {
    padding: 10,
    width: 180,
    height: 100,
    fontSize: 20,
    fontFamily: "PoppinsBold",
    textAlign: "center",
    color: "white",
    margin: 5,
    borderRadius: 10,
    lineHeight: 40
  },
  course1: {
    backgroundColor: "dodgerblue"
  },
  course2: {
    backgroundColor: "tomato"
  },
  course3: {
    backgroundColor: "orange"
  },
  course4: {
    backgroundColor: "skyblue"
  },
  close: {
    color: "white",
    fontSize: 30,
    backgroundColor: "dodgerblue",
    width: 50,
    height: 50,
    borderRadius: 100,
    textAlign: "center",
    lineHeight: 45,
    position: "relative",
    top: 250
  }
})