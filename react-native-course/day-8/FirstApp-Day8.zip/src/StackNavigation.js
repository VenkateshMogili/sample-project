import React, { useEffect } from 'react';
import { createStackNavigator } from '@react-navigation/stack';
import Home from './components/Home';
import Notifications from './components/Notifications';
import Profile from './components/Profile';
import Settings from './components/Settings';
import { NavigationContainer } from '@react-navigation/native';
import SplashScreen from 'react-native-splash-screen';
import MyTabs from './BottomTabNavigation';
import MyDrawer from './DrawerNavigation';
import MyTabsMaterialBottom from './MaterialBottomNavigation';
import MyTabsMaterialTop from './MaterialTopNavigation';
import Registration from './fitnessapp/Registration';
import Login from './fitnessapp/Login';
import ForgotPassword from './fitnessapp/ForgotPassword';
import HomeScreen from './fitnessapp/HomeScreen';
import ExerciseDetails from './fitnessapp/ExerciseDetails';
import MyMenu from './ecommerceapp/MyMenu';
import { Provider } from 'react-redux';
import { store } from './ecommerceapp/redux/store';
const Stack = createStackNavigator();

export default function MyStack() {
  useEffect(() => {
    setTimeout(() => {
      SplashScreen.hide();
    }, 1000);
  }, []);
  return (
    <Provider store={store}>
      <NavigationContainer>
        <Stack.Navigator initialRouteName="Home">
          <Stack.Screen name="Home" component={MyMenu} options={{
            headerStyle: {
              backgroundColor: "tomato",
            },
            headerTintColor: "white",
            headerShown: false
          }} />
          <Stack.Screen name="Login" component={Login} options={{
            headerShown: false
          }} />
          <Stack.Screen name="Register" component={Registration} options={{
            headerShown: false
          }} />
          <Stack.Screen name="ForgotPassword" component={ForgotPassword} options={{
            headerShown: false
          }} />
          <Stack.Screen name="ExerciseDetails" component={ExerciseDetails} options={{
            headerShown: false
          }} />
          <Stack.Screen name="Notifications" component={MyDrawer} options={{
            headerShown: false
          }} />
          <Stack.Screen name="Profile" component={MyTabsMaterialBottom} options={{
            headerShown: false
          }} />
          <Stack.Screen name="Settings" component={MyTabsMaterialTop} options={{
            headerShown: false
          }} />
        </Stack.Navigator>
      </NavigationContainer>
    </Provider>
  );
}