import { StyleSheet } from "react-native";

export const styles = StyleSheet.create({
  container: {
    backgroundColor: "navy",
    flex: 1,
  },
  heading: {
    textAlign: "center",
    fontSize: 30,
    color: "white",
    fontFamily: "PoppinsBold"
  },
  inputContainer: {
    backgroundColor: "white",
    margin: 5,
    marginBottom: 0,
    padding: 10,
    borderTopLeftRadius: 10,
    borderTopRightRadius: 10
  },
  todolist: {
    borderWidth: 1,
    borderColor: "white",
    margin: 5,
    marginTop: 0,
    padding: 10,
    height: 550,
    borderBottomLeftRadius: 10,
    borderBottomRightRadius: 10
  },
  todo: {
    flexDirection: "row",
    justifyContent: "space-between"
  },
  icons: {
    flexDirection: "row"
  },
  title: {
    color: "white",
    fontSize: 18,
    fontFamily: "PoppinsBold"
  }
})