import React, { useEffect, useState } from 'react'
import { View, StyleSheet, Text, Image, } from 'react-native'
import AppIntroSlider from 'react-native-app-intro-slider';
import SplashScreen from 'react-native-splash-screen';
import TodoApp from '../todoapp';
const slides = [
  {
    key: 1,
    title: 'React Native',
    text: 'You can build mobile apps with React',
    image: require('../../assets/slider1.png'),
    backgroundColor: '#59b2ab',
  },
  {
    key: 2,
    title: 'Documentation',
    text: 'Simple Documentation',
    image: require('../../assets/slider2.png'),
    backgroundColor: '#febe29',
  },
  {
    key: 3,
    title: 'Easy to Learn',
    text: 'Many Turoaisl available.',
    image: require('../../assets/slider3.png'),
    backgroundColor: '#22bcb5',
  }
];
export default function SliderApp() {
  const [show, setShow] = useState(false)
  useEffect(() => {
    setTimeout(() => {
      SplashScreen.hide();
    }, 1000);
  }, []);
  const _renderItem = ({ item }) => {
    return (
      <View style={[styles.slide, { backgroundColor: item.backgroundColor }]}>
        <Text style={styles.title}>{item.title}</Text>
        <Image source={item.image} style={styles.imgStyle} />
        <Text style={styles.text}>{item.text}</Text>
      </View>
    );
  }
  const onDone = () => {
    setShow(true);
  }
  return (
    <View style={styles.container}>
      {show ? <TodoApp /> :
        <AppIntroSlider showSkipButton renderItem={_renderItem} data={slides}
          onDone={onDone} />}
    </View>

  )
}

const styles = StyleSheet.create({
  container: {
    flex: 1
  },
  slide: {
    flex: 1,
    alignItems: "center",
    flexDirection: "column",
    justifyContent: "space-evenly"
  },
  imgStyle: {
    width: "90%",
    height: 200,
    margin: 10,
    padding: 10,
    borderRadius: 10
  },
  title: {
    fontSize: 30,
    fontFamily: "PoppinsBold",
    color: "white"
  },
  text: {
    fontSize: 14,
    fontFamily: "PoppinsBold",
    color: "white"
  }
})