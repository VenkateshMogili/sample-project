import React from 'react'
import { TextInput, View, StyleSheet } from 'react-native';
import Icon from 'react-native-vector-icons/FontAwesome5'

export default function InputForm(props) {
  return (
    <View style={styles.container}>
      <Icon name={props.icon} size={20} style={styles.iconStyle} />
      <TextInput placeholder={props.placeholder} secureTextEntry={props.type === "password" ? true : false} style={styles.inputSTyle} />
    </View>
  )
}
const styles = StyleSheet.create({
  container: {
    flexDirection: "row",
    alignItems: "center",
    borderWidth: 1,
    borderColor: "lightgray",
    margin: 10,
    paddingHorizontal: 10
  },
  iconStyle: {
    borderRightWidth: 1,
    borderRightColor: "lightgray",
    padding: 10
  },
  inputSTyle: {
    padding: 10,
    fontFamily: "PoppinsBold",
    width: "100%"
  }
})