export const images = {
  exercise1: require("../../../assets/images/Exercise1.png"),
  exercise2: require("../../../assets/images/Exercise2.png"),
  exercise3: require("../../../assets/images/Exercise3.png"),
  exercise4: require("../../../assets/images/Exercise4.png"),
  bgOrange: require("../../../assets/images/BgOrange.png"),
  bgPurple: require("../../../assets/images/BgPurple.png"),
}