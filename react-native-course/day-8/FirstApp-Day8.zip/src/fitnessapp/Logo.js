import React from 'react'
import { View, Image, Text, StyleSheet } from 'react-native'

export default function Logo(props) {
  return (
    <View>
      <Image source={require("../../assets/images/logo.png")} style={styles.imgStyle} />
      <Text style={styles.text}>{props.title}</Text>
    </View>
  )
}

const styles = StyleSheet.create({
  imgStyle: {
    width: 150,
    height: 150,
    borderRadius: 100,
    margin: 10,
    alignSelf: "center"
  },
  text: {
    fontSize: 20,
    fontFamily: "PoppinsBold",
    textAlign: "center",
    color: "navy"
  }
})