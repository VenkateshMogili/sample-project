import React from 'react'
import { Text, TextInput, View, StyleSheet, ImageBackground } from 'react-native';
import Icon from 'react-native-vector-icons/FontAwesome'
import Card from './Card';
import { images } from './utils/images';

export default function HomeScreen({ navigation }) {
  const exercises = [
    {
      image: images.exercise1,
      title: "Diet Plan",
      course: "10-15 MIN Course",
      description: "Live happier and heathier by learning the fundamentals of diet plan and mindfulness.",
    },
    {
      image: images.exercise2,
      title: "Exercises",
      course: "20-30 MIN Course",
      description: "Live happier and heathier by learning the fundamentals of Exercises and mindfulness.",
    },
    {
      image: images.exercise3,
      title: "Meditation",
      course: "3-10 MIN Course",
      description: "Live happier and heathier by learning the fundamentals of meditation and mindfulness.",
    },
    {
      image: images.exercise4,
      title: "Yoga",
      course: "30-40 MIN Course",
      description: "Live happier and heathier by learning the fundamentals of Yoga and mindfulness.",
    }
  ]
  return (
    <View>
      <ImageBackground source={images.bgOrange} resizeMode="contain" style={styles.bgStyle}>
        <Text style={styles.textStyle}>Fitness App</Text>
        <View style={styles.inputStyle}>
          <Icon name="search" size={20} color="black" style={styles.iconStyle} />
          <TextInput placeholder="Search" style={styles.inputBox} />
        </View>
        <View style={styles.listcontainer}>
          {exercises.map((exercise, index) => (
            <Card {...exercise} item={exercise} index={index} navigation={navigation} />
          ))}
        </View>
      </ImageBackground>
    </View>

  )
}
const styles = StyleSheet.create({
  listcontainer: {
    flexDirection: "row",
    flexWrap: "wrap",
    justifyContent: "center"
  },
  inputStyle: {
    flexDirection: "row",
    alignItems: "center",
    backgroundColor: "white",
    elevation: 5,
    borderRadius: 100,
    margin: 10,
    marginBottom: 100
  },
  iconStyle: {
    margin: 10,
    marginLeft: 20
  },
  inputBox: {
    padding: 10,
  },
  textStyle: {
    fontSize: 30,
    fontFamily: "PoppinsBold",
    margin: 10,
    marginBottom: 20,
    marginTop: 50,
    color: "black"
  },
  bgStyle: {
    height: 300,
  }
})
