import React from 'react'
import { Image, Text, View } from 'react-native'
import ButtonComponent from './ButtonComponent'
import InputForm from './InputForm'
import LinkComponent from './LinkComponent'
import Logo from './Logo'

export default function Registration({ navigation }) {
  return (
    <View>
      <Logo title="Create an account" />
      <InputForm icon="user" placeholder="Email" type="email" />
      <InputForm icon="lock" placeholder="Password" type="password" />
      <InputForm icon="lock" placeholder="Confirm Password" type="password" />
      <ButtonComponent title="Sign Up" navigation={navigation} navigateTo="Login" />
      <Text style={{ margin: 10, textAlign: "center", fontSize: 16 }}>By registering, you confirm that you accept our Terms of service and Privacy Policy</Text>
      <LinkComponent title="Have an account? Sign in" navigation={navigation} navigateTo="Login" />
    </View>
  )
}
