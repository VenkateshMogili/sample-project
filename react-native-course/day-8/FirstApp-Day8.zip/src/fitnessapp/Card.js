import React from 'react'
import { Image, StyleSheet, Text, TouchableOpacity, View } from 'react-native'
import { images } from './utils/images'

export default function Card({ image, title, course, description, item, index, navigation }) {
  return (
    <TouchableOpacity style={styles.container} key={index} onPress={() => navigation.navigate("ExerciseDetails", { item })}>
      <Image source={image} style={styles.imageStyle} />
      <Text style={styles.textStyle}>{title}</Text>
    </TouchableOpacity>
  )
}
const styles = StyleSheet.create({
  container: {
    width: 170,
    alignItems: "center",
    backgroundColor: "white",
    elevation: 5,
    margin: 10,
    padding: 5,
    borderRadius: 10
  },
  imageStyle: {
    width: 150,
    height: 150
  },
  textStyle: {
    textAlign: "center",
    fontSize: 20,
    fontFamily: "PoppinsBold"
  }
})