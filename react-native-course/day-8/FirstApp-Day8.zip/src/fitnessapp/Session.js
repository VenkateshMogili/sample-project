import React from 'react'
import { Image, StyleSheet, Text, TouchableOpacity, View } from 'react-native'
import { images } from './utils/images';
import Icon from 'react-native-vector-icons/FontAwesome';

export default function Session({ active, title, index }) {
  return (
    <TouchableOpacity style={styles.container} key={index}>
      {/*<Image source={image} style={styles.imageStyle} />*/}
      <Icon name="play" size={20} color={active ? "white" : "navy"} style={[styles.iconStyle, active ? styles.bgActive : {}]} />
      <Text style={styles.textStyle}>{title}</Text>
    </TouchableOpacity>
  )
}
const styles = StyleSheet.create({
  container: {
    width: 170,
    alignItems: "center",
    backgroundColor: "white",
    elevation: 5,
    margin: 10,
    padding: 5,
    borderRadius: 10,
    flexDirection: "row"
  },
  imageStyle: {
    width: 150,
    height: 150
  },
  textStyle: {
    textAlign: "center",
    fontSize: 16,
    fontFamily: "PoppinsBold"
  },
  iconStyle: {
    borderWidth: 1,
    borderColor: "navy",
    width: 40,
    height: 40,
    borderRadius: 100,
    padding: 10,
    margin: 10,
    textAlign: "center"
  },
  bgActive: {
    backgroundColor: "navy"
  }
})