import React from 'react'
import { Image, StyleSheet, Text, TouchableOpacity, View } from 'react-native'
import { images } from './utils/images'

export default function ProductCard({ image, price, discount, title, index, addToCart, product }) {
  return (
    <View style={styles.card} key={index}>
      <Image source={image} style={styles.image} resizeMode="contain" />
      <View style={styles.priceContainer}>
        <Text style={styles.price}>
          Rs.{price}
        </Text>
        <Text style={styles.discount}>
          {discount}% OFF
        </Text>
      </View>
      <Text style={styles.heading}>{title}</Text>
      <TouchableOpacity onPress={() => addToCart(product)}>
        <Text style={styles.addToCart}>Add To Cart</Text>
      </TouchableOpacity>
    </View>
  )
}

const styles = StyleSheet.create({
  card: {
    backgroundColor: "white",
    borderRadius: 10,
    padding: 5,
    margin: 10,
    width: 170
  },
  image: {
    width: 150,
    height: 150,
  },
  priceContainer: {
    flexDirection: "row",
    justifyContent: "space-around",
    alignItems: "center"
  },
  heading: {
    textAlign: "center",
    fontFamily: "PoppinsBold",
    color: "black",
    fontSize: 20
  },
  addToCart: {
    backgroundColor: "orange",
    color: "white",
    padding: 10,
    margin: 5,
    borderRadius: 10,
    textAlign: "center",
    fontSize: 16,
    fontFamily: "PoppinsBold"
  },
  price: {
    fontFamily: "PoppinsBold",
    fontSize: 20,
    color: "black"
  },
  discount: {
    fontFamily: "PoppinsBold",
    color: "tomato"
  }
})
