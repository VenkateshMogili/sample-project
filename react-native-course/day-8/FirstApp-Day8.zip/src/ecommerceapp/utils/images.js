export const images = {
  tshirt: require("../../../assets/images/tshirt.jpg"),
  saree: require("../../../assets/images/saree.jpg"),
  laptop: require("../../../assets/images/laptop.jpg"),
  mobile: require("../../../assets/images/mobile.jpg"),
  userprofile: require("../../../assets/profile.jpg"),
}