import React, { useState } from 'react'
import { ScrollView, StyleSheet, TextInput, View, TouchableOpacity, Text, Modal } from 'react-native'
import ProductCard2 from './ProductCard2'
import { images } from './utils/images'
import { removeFromCart, clearCart, incrementQty, decrementQty, updateQty } from './redux/actions';
import { connect } from 'react-redux';
import Icon from 'react-native-vector-icons/MaterialCommunityIcons';

function Cart({ navigation, cart, removeFromCart, clearCart, incrementQty, decrementQty, updateQty }) {
  const [show, setShow] = useState(false);
  //const cart = [
  //  {
  //    image: images.tshirt,
  //    price: 100,
  //    discount: 50,
  //    title: "T-Shirt"
  //  },
  //  {
  //    image: images.saree,
  //    price: 200,
  //    discount: 40,
  //    title: "Saree"
  //  },
  //  {
  //    image: images.laptop,
  //    price: 300,
  //    discount: 60,
  //    title: "Laptop"
  //  },
  //  {
  //    image: images.mobile,
  //    price: 400,
  //    discount: 20,
  //    title: "Mobile"
  //  }
  //]
  const proceedToCheckout = () => {
    setShow(true);
    clearCart();
    setTimeout(() => {
      setShow(false);
      navigation.navigate("Home");
    }, 3000);
  }
  return (
    <View>
      <ScrollView contentContainerStyle={styles.productslist}>
        {cart.map((product, index) => (
          <ProductCard2 {...product} index={index} removeFromCart={(id) => removeFromCart(id)} incrementQty={(id) => incrementQty(id)} decrementQty={(id) => decrementQty(id)}
            updateQty={(id, qty) => updateQty(id, qty)} />
        ))}
        {cart.length > 0 ? <TouchableOpacity onPress={proceedToCheckout}>
          <Text style={styles.addToCart}>Proceed to Checkout</Text>
        </TouchableOpacity> :
          <View style={{ justifyContent: "center", alignItems: "center", marginTop: 200 }}>
            <Icon name="cart" size={50} color="orange" />
            <Text style={{ fontSize: 20, fontFamily: "PoppinsBold" }}>Your Cart Is Empty</Text>
          </View>}
      </ScrollView>
      <Modal visible={show}>
        <View style={styles.success}>
          <Text style={styles.message}>Your Orders Placed Successfully!</Text>
        </View>
      </Modal>
    </View>
  )
}
const styles = StyleSheet.create({
  productslist: {
    flexDirection: "row",
    flexWrap: "wrap",
    justifyContent: "center",
    paddingBottom: 100
  },
  inputSTyle: {
    borderWidth: 1,
    borderColor: "orange",
    margin: 10,
    borderRadius: 10,
    padding: 10
  },
  addToCart: {
    backgroundColor: "black",
    color: "white",
    padding: 5,
    margin: 5,
    borderRadius: 10,
    textAlign: "center",
    fontSize: 14,
    fontFamily: "PoppinsBold",
    paddingVertical: 10,
    width: 350
  },
  success: {
    backgroundColor: "black",
    flex: 1,
    justifyContent: "center"
  },
  message: {
    fontSize: 50,
    fontFamily: "PoppinsBold",
    color: "orange",
    textAlign: "center"
  }
})

const mapStateToProps = (state) => {
  return {
    cart: state.app.cart,
  }
}
const mapDispatchToProps = (dispatch) => {
  return {
    removeFromCart: (id) => dispatch(removeFromCart(id)),
    clearCart: () => dispatch(clearCart()),
    incrementQty: (id) => dispatch(incrementQty(id)),
    decrementQty: (id) => dispatch(decrementQty(id)),
    updateQty: (id, qty) => dispatch(updateQty(id, qty)),
  }
}

export default connect(mapStateToProps, mapDispatchToProps)(Cart)