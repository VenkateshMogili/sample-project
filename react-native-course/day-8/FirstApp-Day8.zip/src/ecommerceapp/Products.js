import React, { useState } from 'react'
import { ScrollView, StyleSheet, TextInput, View } from 'react-native'
import { connect } from 'react-redux'
import ProductCard from './ProductCard'
import { images } from './utils/images';
import { addToCart } from './redux/actions';

function Products({ products, cart, addToCart }) {
  const [searchKey, setSearchKey] = useState("")
  //const products = [
  //  {
  //    image: images.tshirt,
  //    price: 100,
  //    discount: 50,
  //    title: "T-Shirt"
  //  },
  //  {
  //    image: images.saree,
  //    price: 200,
  //    discount: 40,
  //    title: "Saree"
  //  },
  //  {
  //    image: images.laptop,
  //    price: 300,
  //    discount: 60,
  //    title: "Laptop"
  //  },
  //  {
  //    image: images.mobile,
  //    price: 400,
  //    discount: 20,
  //    title: "Mobile"
  //  }
  //]
  console.log(cart)
  return (
    <View>
      <TextInput placeholder="Search Product" value={searchKey} onChangeText={(text) => setSearchKey(text)} style={styles.inputSTyle} />
      <ScrollView contentContainerStyle={styles.productslist}>
        {products.filter(product => product.title.toLowerCase().indexOf(searchKey.toLowerCase()) > -1).map((product, index) => (
          <ProductCard {...product} index={index} addToCart={(product) => addToCart(product)} product={product} />
        ))}
      </ScrollView>
    </View>
  )
}
const styles = StyleSheet.create({
  productslist: {
    flexDirection: "row",
    flexWrap: "wrap",
    justifyContent: "center",
    paddingBottom: 100
  },
  inputSTyle: {
    borderWidth: 1,
    borderColor: "orange",
    margin: 10,
    borderRadius: 10,
    padding: 10
  }
})

const mapStateToProps = (state) => {
  return {
    products: state.app.products,
    cart: state.app.cart,
  }
}
const mapDispatchToProps = (dispatch) => {
  return {
    addToCart: (product) => dispatch(addToCart(product))
  }
}

export default connect(mapStateToProps, mapDispatchToProps)(Products)