import React from 'react'
import { Button, Image, Text, View } from 'react-native'
import { images } from './utils/images'

export default function Accounts() {
  return (
    <View style={{ flex: 1, justifyContent: "center", alignItems: "center" }}>
      <Image source={images.userprofile} style={{ width: 100, height: 100, borderRadius: 100 }} />
      <Text style={{ fontSize: 20, fontFamily: "PoppinsBold", textAlign: "center" }}>Venkatesh Mogili</Text>
      <Text style={{ fontSize: 16, fontFamily: "PoppinsBold", textAlign: "center" }}>mogilivenkatesh3@gmail.com</Text>
      <Text style={{ fontSize: 16, fontFamily: "PoppinsBold", textAlign: "center" }}>1234512345</Text>
      <Button title="Logout" color="tomato" />
    </View>
  )
}
