import { images } from "../utils/images";
import { ADD_TO_CART, CLEAR_CART, DECREMENT_QTY, INCREMENT_QTY, REMOVE_FROM_CART, UPDATE_QTY } from "./actionTypes";

const initialState = {
  products: [
    {
      id: 1,
      image: images.tshirt,
      price: 120,
      discount: 50,
      title: "T-Shirt"
    },
    {
      id: 2,
      image: images.saree,
      price: 200,
      discount: 40,
      title: "Saree"
    },
    {
      id: 3,
      image: images.laptop,
      price: 300,
      discount: 60,
      title: "Laptop"
    },
    {
      id: 4,
      image: images.mobile,
      price: 400,
      discount: 20,
      title: "Mobile"
    }
  ],
  cart: []
}

export const reducer = (state = initialState, action) => {
  switch (action.type) {
    case ADD_TO_CART: {
      let updateCart = [...state.cart];
      if (!state.cart.includes(action.product)) {
        updateCart = [...state.cart, { ...action.product, qty: 1 }];
      }
      return { ...state, cart: updateCart }
    }
    case REMOVE_FROM_CART: {
      let filteredCart = [...state.cart].filter(item => item.id !== action.id);
      return { ...state, cart: filteredCart }
    }
    case CLEAR_CART: {
      return { ...state, cart: [] }
    }
    case INCREMENT_QTY: {
      let index = [...state.cart].findIndex(item => item.id === action.id);
      let updatedCart = [...state.cart];
      updatedCart[index].qty += 1;
      return { ...state, cart: updatedCart }
    }
    case DECREMENT_QTY: {
      let index = [...state.cart].findIndex(item => item.id === action.id);
      let updatedCart = [...state.cart];
      updatedCart[index].qty -= 1;
      return { ...state, cart: updatedCart }
    }
    case UPDATE_QTY: {
      let index = [...state.cart].findIndex(item => item.id === action.id);
      let updatedCart = [...state.cart];
      updatedCart[index].qty = action.qty;
      return { ...state, cart: updatedCart }
    }
    default:
      return state;
  }
}