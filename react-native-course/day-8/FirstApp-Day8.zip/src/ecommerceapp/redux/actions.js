import { ADD_TO_CART, CLEAR_CART, DECREMENT_QTY, INCREMENT_QTY, REMOVE_FROM_CART, UPDATE_QTY } from "./actionTypes"

export const addToCart = (product) => {
  return {
    type: ADD_TO_CART,
    product
  }
}

export const removeFromCart = (id) => {
  return {
    type: REMOVE_FROM_CART,
    id
  }
}

export const clearCart = () => {
  return {
    type: CLEAR_CART
  }
}

export const incrementQty = (id) => {
  return {
    type: INCREMENT_QTY,
    id
  }
}

export const decrementQty = (id) => {
  return {
    type: DECREMENT_QTY,
    id
  }
}

export const updateQty = (id, qty) => {
  return {
    type: UPDATE_QTY,
    id,
    qty
  }
}