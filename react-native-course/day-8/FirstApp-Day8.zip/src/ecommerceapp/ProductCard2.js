import React from 'react'
import { Image, StyleSheet, Text, TouchableOpacity, View, Button, TextInput } from 'react-native'
import { images } from './utils/images'

export default function ProductCard({ image, price, discount, title, index, id, qty, removeFromCart, incrementQty, decrementQty, updateQty }) {
  return (
    <View style={styles.card} key={index}>
      <Image source={image} style={styles.image} resizeMode="contain" />
      <View style={styles.priceContainer}>
        <Text style={styles.price}>
          Rs.{price}
        </Text>
        <Text style={styles.discount}>
          {discount}% OFF
        </Text>
      </View>
      <Text style={styles.heading}>{title}</Text>
      <View style={styles.row}>
        <Button title="-" onPress={() => qty > 1 && decrementQty(id)} />
        <TextInput value={qty.toString()} style={styles.qty} onChangeText={(text) => updateQty(id, parseInt(text))} />
        <Button title="+" onPress={() => incrementQty(id)} />
      </View>
      <TouchableOpacity onPress={() => removeFromCart(id)}>
        <Text style={styles.addToCart}>Remove From Cart</Text>
      </TouchableOpacity>
    </View>
  )
}

const styles = StyleSheet.create({
  card: {
    backgroundColor: "white",
    borderRadius: 10,
    padding: 5,
    margin: 10,
    width: 170
  },
  image: {
    width: 150,
    height: 150,
  },
  priceContainer: {
    flexDirection: "row",
    justifyContent: "space-around",
    alignItems: "center"
  },
  heading: {
    textAlign: "center",
    fontFamily: "PoppinsBold",
    color: "black",
    fontSize: 20
  },
  addToCart: {
    backgroundColor: "tomato",
    color: "white",
    padding: 5,
    margin: 5,
    borderRadius: 10,
    textAlign: "center",
    fontSize: 14,
    fontFamily: "PoppinsBold",
    paddingVertical: 10
  },
  price: {
    fontFamily: "PoppinsBold",
    fontSize: 20,
    color: "black"
  },
  discount: {
    fontFamily: "PoppinsBold",
    color: "tomato"
  },
  row: {
    flexDirection: "row",
    justifyContent: "space-between",
    alignItems: "center",
    marginHorizontal: 10
  },
  qty: {
    textAlign: "center"
  }
})
