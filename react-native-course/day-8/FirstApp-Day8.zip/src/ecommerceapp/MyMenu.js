import React from 'react';
import { createBottomTabNavigator } from '@react-navigation/bottom-tabs';
import Home from '../components/Home';
import Settings from '../components/Settings';
import MaterialCommunityIcons from 'react-native-vector-icons/MaterialCommunityIcons';
import Icon from 'react-native-vector-icons/FontAwesome';
import Notifications from '../components/Notifications';
import { View } from 'react-native';
import Products from './Products';
import Cart from './Cart';
import Accounts from './Accounts';

const Tab = createBottomTabNavigator();

export default function MyMenu() {
  return (
    <Tab.Navigator screenOptions={{
      tabBarStyle: {
        backgroundColor: "black",
      },
      tabBarActiveTintColor: "orange",
      tabBarInactiveTintColor: "white",
      headerStyle: {
        backgroundColor: "orange"
      },
      headerTintColor: "white",
      headerTitle: "ECommerce App",
      headerRight: () => (
        <View>
          <Icon name="search" size={20} color="white" style={{ margin: 10 }} />
        </View>
      )
    }}>
      <Tab.Screen name="Home" component={Products} options={{
        tabBarLabel: 'Home',
        tabBarIcon: ({ color, size }) => (
          <MaterialCommunityIcons name="home" color={color} size={size} />
        ),
      }} />
      <Tab.Screen name="Cart" component={Cart} options={{
        tabBarLabel: 'Cart',
        tabBarIcon: ({ color, size }) => (
          <MaterialCommunityIcons name="cart" color={color} size={50} style={{ marginTop: -30, backgroundColor: "black", padding: 10, borderRadius: 100 }} />
        ),
      }} />
      <Tab.Screen name="Account" component={Accounts} options={{
        tabBarLabel: 'Account',
        tabBarIcon: ({ color, size }) => (
          <MaterialCommunityIcons name="account" color={color} size={size} />
        ),
      }} />
    </Tab.Navigator>
  );
}