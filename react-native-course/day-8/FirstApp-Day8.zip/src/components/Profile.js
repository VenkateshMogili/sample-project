import React from 'react'
import { Text, View, Button } from 'react-native'

export default function Profile({ navigation }) {
  return (
    <View>
      <Text>Profile screen</Text>

      <View style={{ margin: 10 }}>
        <Button title="Notifications" color="blue" onPress={() => navigation.navigate("Notifications", { username: "Venkatesh Mogili" })} />
      </View>

      <View style={{ margin: 10 }}>
        <Button title="Go To Home" color="tomato" onPress={() => navigation.popToTop()} />
      </View>
    </View>
  )
}
