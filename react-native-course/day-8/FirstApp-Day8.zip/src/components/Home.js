import React from 'react'
import { Button, Text, View } from 'react-native'

export default function Home({ navigation }) {
  return (
    <View>
      <Text style={{ fontSize: 20, fontFamily: "PoppinsBold", textAlign: "center", margin: 5 }}>Home screen</Text>
      <View style={{ margin: 5 }}>
        <Button title="Home" onPress={() => navigation.navigate("Home")} />
      </View>
      <View style={{ margin: 5 }}>
        <Button title="Notifications" onPress={() => navigation.navigate("Notifications")} />
      </View>
      <View style={{ margin: 5 }}>
        <Button title="Profile" onPress={() => navigation.navigate("Profile")} />
      </View>
      <View style={{ margin: 5 }}>
        <Button title="Settings" onPress={() => navigation.navigate("Settings")} />
      </View>
    </View>
  )
}
