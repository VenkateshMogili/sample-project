import React from 'react'
import { Text, View, StyleSheet, FlatList, Image, TouchableOpacity } from 'react-native'

export default function ChatList({ navigation }) {
  const userList = [
    {
      id: 1,
      image: require("../../assets/images/logo.png"),
      username: "Venkatesh Mogili",
      sentDate: "4 mins ago",
      message: "Hey there, I'm using Whatsapp."
    },
    {
      id: 2,
      image: require("../../assets/images/logo.png"),
      username: "Chinni",
      sentDate: "20 mins ago",
      message: "Hey there, I'm using Whatsapp."
    },
    {
      id: 3,
      image: require("../../assets/images/logo.png"),
      username: "Chinna",
      sentDate: "1 hour ago",
      message: "Hey there, I'm using Whatsapp."
    },
    {
      id: 4,
      image: require("../../assets/images/logo.png"),
      username: "Siva",
      sentDate: "40 mins ago",
      message: "Hey there, I'm using Whatsapp."
    }
  ];
  const ContactItem = ({ item }) => {
    return (
      <TouchableOpacity style={styles.container} onPress={() => navigation.navigate("Chat", { user: item })}>
        <Image source={item.image} style={styles.imgStyle} />
        <View style={styles.messageContainer}>
          <View style={styles.row}>
            <Text style={styles.username}>{item.username}</Text>
            <Text>{item.sentDate}</Text>
          </View>
          <Text>{item.message}</Text>
        </View>
      </TouchableOpacity>
    )
  }
  return (
    <View>
      <Text style={styles.heading}>Chat App</Text>
      <FlatList
        data={userList}
        keyExtractor={(item) => item.id}
        renderItem={ContactItem}
        ItemSeparatorComponent={() => {
          return (
            <View style={styles.borderStyle} />
          )
        }}
      />
    </View>
  )
}
const styles = StyleSheet.create({
  heading: {
    fontSize: 25,
    fontFamily: "PoppinsBold",
    textAlign: "center",
    backgroundColor: "white",
    padding: 10,
    borderBottomWidth: 5,
    borderBottomColor: "navy"
  },
  imgStyle: {
    width: 50,
    height: 50,
    borderRadius: 100,
    margin: 5
  },
  container: {
    flexDirection: "row",
    alignItems: "center",
    margin: 5
  },
  row: {
    flexDirection: "row",
    justifyContent: "space-between"
  },
  messageContainer: {
    width: "85%"
  },
  username: {
    fontSize: 14,
    fontFamily: "PoppinsBold",
  },
  borderStyle: {
    borderWidth: 0.5,
    borderColor: "lightgray"
  }
})