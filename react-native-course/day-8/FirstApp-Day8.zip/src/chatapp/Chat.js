import React, { useState, useCallback } from 'react'
import { Text, View, StyleSheet } from 'react-native'
import Icon from 'react-native-vector-icons/FontAwesome';
import { GiftedChat } from 'react-native-gifted-chat'

export default function Chat({ route, navigation }) {
  const [messages, setMessages] = useState([
    {
      _id: 1,
      text: 'Hello developer',
      createdAt: new Date(),
      user: {
        _id: 2,
        name: 'React Native',
        avatar: require("../../assets/images/logo.png"),
      },
    },
  ]);
  const onSend = useCallback((messages = []) => {
    setMessages(previousMessages => GiftedChat.append(previousMessages, messages))
  }, [])
  return (
    <View style={{ flex: 1 }}>
      <View style={styles.header}>
        <Icon name="angle-left" size={30} style={styles.icon} onPress={() => navigation.goBack()} />
        <Text style={styles.heading}>{route.params.user.username}</Text>
      </View>
      <GiftedChat
        messages={messages}
        onSend={messages => onSend(messages)}
        user={{
          _id: 1,
        }}
      />
    </View>
  )
}

const styles = StyleSheet.create({
  heading: {
    fontSize: 25,
    fontFamily: "PoppinsBold",
    textAlign: "center",
    padding: 10,
  },
  header: {
    flexDirection: "row",
    alignItems: "center",
    borderBottomWidth: 5,
    backgroundColor: "white",
    borderBottomColor: "navy"
  },
  icon: {
    margin: 10,
    marginRight: 20,
  }
})