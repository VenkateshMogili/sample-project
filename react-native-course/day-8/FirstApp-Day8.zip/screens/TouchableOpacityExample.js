import React from 'react'
import { Text, TouchableOpacity } from 'react-native'

export default function TouchableOpacityExample() {
  return (
    <TouchableOpacity onPress={() => alert("Touched")}>
      <Text style={{ backgroundColor: "blue", padding: 10, margin: 5, color: "white", borderRadius: 10 }}>Click here to dim</Text>
    </TouchableOpacity>
  )
}
