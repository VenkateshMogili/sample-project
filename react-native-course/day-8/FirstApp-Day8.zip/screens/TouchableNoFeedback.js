import React from 'react'
import { TouchableWithoutFeedback, Text } from 'react-native'

export default function TouchableNoFeedback() {
  return (
    <TouchableWithoutFeedback onPress={() => alert("Feedback")}>
      <Text style={{ backgroundColor: "tomato", padding: 10, margin: 5, color: "white", borderRadius: 10 }}>Click here to show alert</Text>
    </TouchableWithoutFeedback>
  )
}
