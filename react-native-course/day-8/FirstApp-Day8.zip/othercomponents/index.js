import React from 'react'
import { View } from 'react-native'
import ActivityIndicatorExample from './ActivityIndicatorExample'
import AlertExample from './AlertExample'
import AnimationExample from './AnimationExample'
import DimensionsExample from './DimensionsExample'
import ImageBGExample from './ImageBGExample'
import KeyboardExample from './KeyboardExample'
import LinkingExample from './LinkingExample'
import ModalExample from './ModalExample'
import PixelExample from './PixelExample'
import RefreshExample from './RefreshExample'
import ShadowExample from './ShadowExample'
import StatusExample from './StatusExample'

export default function OtherComponents() {
  return (
    <View>
      {/*<ActivityIndicatorExample />*/}
      {/*<AlertExample />*/}
      {/*<ModalExample />*/}
      {/*<DimensionsExample />*/}
      {/*<LinkingExample />*/}
      {/*<KeyboardExample />*/}
      {/*<PixelExample />*/}
      {/*<RefreshExample />*/}
      {/*<StatusExample />*/}
      {/*<ImageBGExample />*/}
      {/*<ShadowExample />*/}
      <AnimationExample />
    </View>
  )
}
