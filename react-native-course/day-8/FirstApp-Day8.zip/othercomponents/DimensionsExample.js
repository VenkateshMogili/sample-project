import React from 'react'
import { Dimensions, Text, useWindowDimensions, View } from 'react-native'

export default function DimensionsExample() {
  const { width, height, fontScale, scale } = useWindowDimensions();
  return (
    <View>
      <Text>Width: {Dimensions.get("window").width}</Text>
      <Text>Height: {Dimensions.get("window").height}</Text>
      <Text>Font Scale: {Dimensions.get("window").fontScale}</Text>
      <Text>Scale: {Dimensions.get("window").scale}</Text>
      <Text>Width: {Dimensions.get("screen").width}</Text>
      <Text>Height: {Dimensions.get("screen").height}</Text>
      <Text>Font Scale: {Dimensions.get("screen").fontScale}</Text>
      <Text>Scale: {Dimensions.get("screen").scale}</Text>
      <Text>Width: {width}</Text>
      <Text>Height: {height}</Text>
      <Text>Font Scale: {fontScale}</Text>
      <Text>Scale: {scale}</Text>
    </View>
  )
}
