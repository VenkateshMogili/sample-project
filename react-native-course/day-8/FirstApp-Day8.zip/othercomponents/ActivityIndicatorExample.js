import React from 'react'
import { ActivityIndicator } from 'react-native'

export default function ActivityIndicatorExample() {
  return (
    <ActivityIndicator size={40} color="blue" animating={false} />
  )
}
