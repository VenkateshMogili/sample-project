module.exports = {
  "assets": [
    "./fonts/"
  ]
}