import { AppRegistry } from 'react-native';
import App from './App';
import { name as appName } from './app.json';
import Messages from './components/Messages/Messages';
import Gallery from './components/Gallery/Photos';
import OnboardingScreen from './components/Onboarding';
AppRegistry.registerComponent(appName, () => Gallery);
