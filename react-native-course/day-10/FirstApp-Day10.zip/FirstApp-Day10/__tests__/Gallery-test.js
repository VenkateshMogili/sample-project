import React from 'react';
import { render, fireEvent, act } from '@testing-library/react-native';
import Gallery from '../components/Gallery/Photos'
import mockAxios from 'jest-mock-axios';


describe('Gallery Test Cases', () => {
  let GalleryComponent;
  beforeEach(() => {
    GalleryComponent = render(<Gallery />);
  })
  afterEach(() => {
    mockAxios.reset();
  })
  test("First test case", () => {
    expect(1).toBe(1)
  })
  test("Render Component", () => {
    GalleryComponent
  })

  test("Snapshot Testing", () => {
    let GalleryComponentInstance = GalleryComponent.toJSON();
    expect(GalleryComponentInstance).toMatchSnapshot();
  })
  test("Gallery Text Testing", () => {
    const { getAllByText } = GalleryComponent;
    expect(getAllByText("Gallery").length).toBe(1);
  })
  test("Add Text Testing", () => {
    const { getAllByText } = GalleryComponent;
    expect(getAllByText("Add").length).toBe(1);
  })
  test("Title placeholder Testing", () => {
    const { getByPlaceholderText } = GalleryComponent;
    getByPlaceholderText("Title");
  })
  test("Props/States Testing", () => {
    const props = GalleryComponent.toJSON();
    const galleryStyles = props.children[0].props.style;
    expect(galleryStyles).toEqual({
      fontSize: 30,
      textAlign: "center",
      color: "white",
      backgroundColor: "purple",
      padding: 5
    })
  })

  test("Functions Testing", () => {
    const { getByTestId } = GalleryComponent;
    fireEvent.changeText(getByTestId("title"), "New Photo");
    const props = GalleryComponent.toJSON();
    const titleInput = props.children[1].children[0].props.value;
    expect(titleInput).toBe("New Photo")
    act(() => {
      fireEvent.press(getByTestId("add"))
    })
  })
  test("API Calls Testing", async () => {
    const { getByTestId } = GalleryComponent;
    fireEvent.changeText(getByTestId("title"), "New Photo");
    fireEvent.press(getByTestId("add"))
    let requestBody = JSON.stringify({ title: "New Photo" });
    await expect(mockAxios.post).toHaveBeenCalledWith("https://jsonplaceholder.typicode.com/photos", { body: requestBody })
  })
});
