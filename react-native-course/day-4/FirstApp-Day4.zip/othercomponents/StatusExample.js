import React from 'react'
import { View, Text, StatusBar } from 'react-native'

export default function StatusExample() {
  return (
    <View>
      <StatusBar backgroundColor="transparent" barStyle="default" animated translucent />
      <Text>Hello World!</Text>
    </View>
  )
}
