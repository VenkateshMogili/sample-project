import React from 'react'
import { Button, Linking, View } from 'react-native'

export default function LinkingExample() {
  const openLink = () => {
    //Linking.openURL("https://vmtraining.netlify.app")
    Linking.openSettings();
  }
  return (
    <View>
      <Button title="Open VM training" onPress={() => openLink()} />
    </View>
  )
}
