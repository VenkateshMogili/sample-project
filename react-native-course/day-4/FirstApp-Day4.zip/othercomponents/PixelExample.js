import React from 'react'
import { PixelRatio, Text, View } from 'react-native'

export default function PixelExample() {
  return (
    <View>
      <Text>Current Pixel: {PixelRatio.get()}</Text>
      <Text>Current font scale: {PixelRatio.getFontScale()}</Text>
      <Text>Current pixel for dp: {PixelRatio.getPixelSizeForLayoutSize(50)}</Text>
      <Text>Current nearest pixel: {PixelRatio.roundToNearestPixel(50)}</Text>
    </View>
  )
}
