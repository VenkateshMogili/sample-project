import React from 'react'
import { Alert, Button, View } from 'react-native'

export default function AlertExample() {
  const onClick = () => {
    Alert.alert("Notification", "This is simple notification",
      [
        {
          text: "Ask Me Later",
          onPress: () => console.log("Ask Me Later"),
        },
        {
          text: "Cancel",
          onPress: () => console.log("Cancelled"),
          style: "cancel"
        },
        {
          text: "Ok",
          onPress: () => console.log("Ok"),
          style: "default"
        },
      ], { cancelable: true, onDismiss: () => console.log("Dismissed") })
    //Alert.prompt("Enter your name");
  }
  return (
    <View>
      <Button title="Click here" onPress={() => onClick()} />
    </View>
  )
}
