import React, { useState } from 'react'
import { Switch } from 'react-native'

export default function SwitchExample() {
  const [isEnabled, setEnabled] = useState(false)
  return (
    <Switch
      value={isEnabled}
      onValueChange={() => setEnabled(!isEnabled)}
      trackColor={{ false: "blue", true: "red" }}
      thumbColor={isEnabled ? "red" : "blue"}
    //disabled
    />
  )
}
