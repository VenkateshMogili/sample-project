import React from 'react'
import { View } from 'react-native'
import ButtonExample from './ButtonExample'
import FlatListExample from './FlatListExample'
import PressableExample from './PressableExample'
import SectionListExample from './SectionListExample'
import SwitchExample from './SwitchExample'
import TouchableHighlightExample from './TouchableHighlightExample'
import TouchableNoFeedback from './TouchableNoFeedback'
import TouchableOpacityExample from './TouchableOpacityExample'
import VirtualizedListExample from './VirtualizedListExample'

export default function Home() {
  return (
    <View>
      <TouchableOpacityExample />
      <TouchableHighlightExample />
      <TouchableNoFeedback />
      <ButtonExample />
      <PressableExample />
      <SwitchExample />
      {/*<FlatListExample />*/}
      {/*<SectionListExample />*/}
      <VirtualizedListExample />
    </View>
  )
}
