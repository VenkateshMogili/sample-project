import React, { useState } from 'react';
import { View, Text, Image, TextInput, ScrollView, StyleSheet } from 'react-native';
import { styles } from './styles';
export default function App() {
  const [biodata, setBiodata] = useState("")
  return (
    <ScrollView keyboardShouldPersistTaps="handled">
      <View>
        <Image source={require("./assets/profile.jpg")} style={styles.imgStyle} />
        {/*<Image source={{ uri: "https://pbs.twimg.com/profile_images/976485239852683266/qcp9z3_2.jpg" }} style={{ width: "100%", height: 400, backgroundColor: "orange", opacity: 0.5, borderRadius: 100, borderWidth: 10, borderColor: "orange" }} blurRadius={3} fadeDuration={3000} />*/}
        {/*<View style={{ borderWidth: 10, borderColor: "blue", height: 100, margin: 10, backgroundColor: "orange", borderRadius: 10, elevation: 10, borderStyle: "solid", opacity: 0.9, }} onTouchStart={() => alert("touched")}>
        <Text numberOfLines={3} style={{ color: "white", fontSize: 20, fontStyle: "italic", fontWeight: "bold", letterSpacing: 10, lineHeight: 30, textAlign: "left", textTransform: "capitalize", fontFamily: "PoppinsBold" }}>Venkatesh Mogili</Text>
      </View>*/}
        <View style={styles.margin10}>
          <Text style={styles.headingStyle}>Venkatesh Mogili</Text>
        </View>
        <View style={styles.margin10}>
          <Text style={styles.fs20} numberOfLines={2}>{biodata.length > 0 ? biodata : "Please enter your biodata."}</Text>
        </View>
        <TextInput onChangeText={(text) => setBiodata(text)} placeholder="Enter your biodata" onFocus={() => console.log("focused")} onSubmitEditing={() => console.log("Edited")} multiline editable={true} keyboardType="email-address" style={styles.inputStyles} />
      </View>
    </ScrollView>
  )
}

//const styles = StyleSheet.create({
//  imgStyle: {
//    width: "100%",
//    height: 400
//  },
//  margin10: {
//    margin: 10
//  },
//  headingStyle: {
//    fontSize: 30,
//    fontFamily: "PoppinsBold",
//    textAlign: "center"
//  },
//  fs20: {
//    fontSize: 20
//  },
//  inputStyles: {
//    margin: 10,
//    borderWidth: 1,
//    borderColor: "gray",
//    borderRadius: 10,
//    padding: 10
//  }
//})