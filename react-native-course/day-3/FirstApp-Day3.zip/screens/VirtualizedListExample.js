import React, { useState } from 'react'
import { View, Text, VirtualizedList } from 'react-native'
import SwitchExample from './SwitchExample'

export default function VirtualizedListExample() {
  const [courses] = useState([]);
  return (
    <View>
      <Text style={{ fontSize: 30, textAlign: "center" }}>Virtual Users List</Text>
      <VirtualizedList
        data={courses}
        keyExtractor={(item) => item.key}
        getItem={(data, index) => ({
          title: `User ${index},`,
          name: "Venakatesh"
        }
        )}
        getItemCount={() => 10}
        renderItem={({ item }) => (
          <View style={{ flexDirection: "row", justifyContent: "space-between", borderWidth: 1, borderRadius: 10, margin: 5, padding: 5, alignItems: "center" }}>
            <Text>{item.title} {item.name}</Text>
            <SwitchExample />
          </View>
        )}
        ListHeaderComponent={() => (
          <Text style={{ fontSize: 30, color: "tomato", margin: 5 }}>Users</Text>
        )}
      />
    </View>
  )
}
