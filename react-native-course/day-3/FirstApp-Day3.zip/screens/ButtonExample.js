import React from 'react'
import { Button, View } from 'react-native';

export default function ButtonExample() {
  return (
    <View style={{ padding: 10, margin: 5 }}>
      <Button title="Press Me" color="red" onPress={() => alert("Pressed")} disabled touchSoundDisabled />
    </View>
  )
}
