import React, { useEffect } from 'react'
import { BackHandler, Text, View } from 'react-native'

export default function BackhandlerExample() {
  useEffect(() => {
    let backHandler = BackHandler.addEventListener("hardwareBackPress", () => {
      //BackHandler.exitApp();
      return false;
    })
    return () => {
      backHandler.remove();
    }
  }, [])
  return (
    <View>
      <Text>Hello</Text>
    </View>
  )
}
