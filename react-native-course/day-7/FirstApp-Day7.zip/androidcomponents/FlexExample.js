import React from 'react'
import { View } from 'react-native'

export default function FlexExample() {
  return (
    <View
      style={{
        borderWidth: 1,
        margin: 10, flex: 1,
        flexDirection: "row",
        justifyContent: "space-evenly",
        alignItems: "center",
        //flexWrap: "wrap",
        alignContent: "center"
      }}>
      {/*<View style={{ backgroundColor: "red", height: 100, alignSelf: "baseline", width: 100 }}>

      </View>
      <View style={{ backgroundColor: "blue", height: 50, alignSelf: "center", width: 100 }}>

      </View>
      <View style={{ backgroundColor: "orange", height: 200, width: 100 }}>

      </View>*/}
      {/*<View style={{ backgroundColor: "red", height: 100, flexBasis: 100, flexGrow: 1 }}>

      </View>
      <View style={{ backgroundColor: "blue", height: 100, width: 100, flexGrow: 1 }}>

      </View>
      <View style={{ backgroundColor: "orange", height: 100, width: 100 }}>

      </View>
      <View style={{ backgroundColor: "black", height: 100, width: 100 }}>

      </View>
      <View style={{ backgroundColor: "red", height: 100, width: 100 }}>

      </View>
      <View style={{ backgroundColor: "magenta", height: 100, width: 100 }}>

      </View>*/}
      <View style={{ backgroundColor: "black", height: 100, width: 300, flexShrink: 1 }}>

      </View>
      <View style={{ backgroundColor: "red", height: 100, width: 100 }}>

      </View>
      <View style={{ backgroundColor: "magenta", height: 100, width: 100 }}>

      </View>
    </View>
  )
}
