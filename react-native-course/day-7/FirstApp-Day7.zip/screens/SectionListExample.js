import React, { useState } from 'react'
import { View, Text, ActivityIndicator, SectionList } from 'react-native'
import SwitchExample from './SwitchExample'

export default function SectionListExample() {
  const [courses] = useState([
    {
      id: 1,
      title: "ReactJS",
      data: ["Venkatesh", "Chinni"]
    },
    {
      id: 2,
      title: "NodeJS",
      data: ["Venkatesh", "Chinni"]
    },
  ]);
  return (
    <View>
      <Text style={{ fontSize: 30, textAlign: "center" }}>Enrolled Users List</Text>
      <SectionList
        sections={courses}
        keyExtractor={(item, index) => item + index}
        renderItem={({ item }) => (
          <View style={{ flexDirection: "row", justifyContent: "space-between", borderWidth: 1, borderRadius: 10, margin: 5, padding: 5, alignItems: "center" }}>
            <Text>{item}</Text>
            <SwitchExample />
          </View>
        )}
        renderSectionHeader={({ section: { title } }) => (
          <Text style={{ fontSize: 20, margin: 5, padding: 5, color: "blue" }}>{title}</Text>
        )}
      />
    </View>
  )
}
