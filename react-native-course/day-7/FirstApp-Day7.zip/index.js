import 'react-native-gesture-handler'
/**
 * @format
 */

import { AppRegistry } from 'react-native';
import AndroidComponents from './androidcomponents';
import FlexExample from './androidcomponents/FlexExample';
import PositionsExample from './androidcomponents/PositionsExample';
import App from './App';
import { name as appName } from './app.json';
import OtherComponents from './othercomponents';
import Home from './screens';
import CourseApp from './src';
import DateTimeApp from './src/datetimeapp';
import SliderApp from './src/sliderapp';
import TodoApp from './src/todoapp';
import MyStack from './src/StackNavigation';

AppRegistry.registerComponent(appName, () => MyStack);
