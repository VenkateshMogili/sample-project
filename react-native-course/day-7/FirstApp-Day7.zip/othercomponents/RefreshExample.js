import React, { useState } from 'react'
import { RefreshControl, ScrollView, Text, View } from 'react-native'

export default function RefreshExample() {
  const [refreshing, setRefresh] = useState(false);
  return (
    <ScrollView refreshControl={
      <RefreshControl refreshing={refreshing} onRefresh={() => {
        setRefresh(true);
        setTimeout(() => {
          setRefresh(false)
        }, 3000);
      }} colors={["red", "blue", "green"]} size="default" />
    }>
      <View style={{ height: 600 }}>
        <Text>Hello World!</Text>
      </View>
    </ScrollView>
  )
}
