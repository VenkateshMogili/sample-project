import React from 'react';
import { createDrawerNavigator } from '@react-navigation/drawer';
import Home from './components/Home';
import Notifications from './components/Notifications';
import Profile from './components/Profile';
import { Image, Text, TouchableOpacity, View } from 'react-native';
import Icon from 'react-native-vector-icons/FontAwesome'

const Drawer = createDrawerNavigator();

export default function MyDrawer({ navigation }) {
  const ProfileView = () => {
    return (
      <View style={{ alignItems: "center" }}>
        <Image source={require("../assets/profile.jpg")} style={{ width: 100, height: 100, borderRadius: 100, margin: 10 }} />
        <Text style={{ fontSize: 20, textAlign: "center", fontFamily: "PoppinsBold" }}>Venkatesh Mogili</Text>
        <View style={{ flexDirection: "row", alignSelf: "stretch", justifyContent: "space-around" }}>
          <TouchableOpacity>
            <Text style={{ padding: 10, backgroundColor: "blue", borderRadius: 10, color: "white", width: 100, textAlign: "center", fontFamily: "PoppinsBold" }}>Edit</Text>
          </TouchableOpacity>
          <TouchableOpacity>
            <Text style={{ padding: 10, backgroundColor: "tomato", borderRadius: 10, color: "white", width: 100, textAlign: "center", fontFamily: "PoppinsBold" }}>Logout</Text>
          </TouchableOpacity>
        </View>
        <View style={{ alignSelf: "stretch" }}>
          <TouchableOpacity onPress={() => navigation.navigate("Home")} style={{ flexDirection: "row", padding: 10, margin: 10, borderBottomWidth: 1, borderBottomColor: "lightgray" }}>
            <Icon name="home" size={20} style={{ width: 40 }} />
            <Text style={{ fontFamily: "PoppinsBold" }}>Home</Text>
          </TouchableOpacity>
          <TouchableOpacity onPress={() => navigation.navigate("Profile")} style={{ flexDirection: "row", padding: 10, margin: 10, borderBottomWidth: 1, borderBottomColor: "lightgray" }}>
            <Icon name="user" size={20} style={{ width: 40 }} />
            <Text style={{ fontFamily: "PoppinsBold" }}>Profile</Text>
          </TouchableOpacity>
          <TouchableOpacity onPress={() => navigation.navigate("Notifications")} style={{ flexDirection: "row", padding: 10, margin: 10, borderBottomWidth: 1, borderBottomColor: "lightgray" }}>
            <Icon name="bell" size={20} style={{ width: 40 }} />
            <Text style={{ fontFamily: "PoppinsBold" }}>Notifications</Text>
          </TouchableOpacity>
        </View>

      </View>
    )
  }
  return (
    <Drawer.Navigator drawerContent={ProfileView} screenOptions={{
      drawerType: "back",
      //drawerStyle: { width: "50%" },
      overlayColor: "transparent"
    }}>
      <Drawer.Screen name="Feed" component={Home} />
      <Drawer.Screen name="Article" component={Profile} />
    </Drawer.Navigator>
  );
}