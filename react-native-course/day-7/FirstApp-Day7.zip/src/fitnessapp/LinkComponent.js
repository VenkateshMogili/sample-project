import React from 'react'
import { Text } from 'react-native'

export default function LinkComponent(props) {
  return (
    <Text style={{ color: "blue", fontSize: 20, textAlign: "center", margin: 10 }} onPress={() => props.navigation.navigate(props.navigateTo)}>{props.title}</Text>
  )
}
