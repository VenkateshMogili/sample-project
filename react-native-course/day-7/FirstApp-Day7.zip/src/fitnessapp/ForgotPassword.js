import React from 'react'
import { Image, Text, View } from 'react-native'
import ButtonComponent from './ButtonComponent'
import InputForm from './InputForm'
import LinkComponent from './LinkComponent'
import Logo from './Logo'

export default function ForgotPassword({ navigation }) {
  return (
    <View>
      <Logo title="Forgot Password" />
      <InputForm icon="user" placeholder="Email" type="email" />
      <ButtonComponent title="Submit" navigation={navigation} navigateTo="Login" />
    </View>
  )
}
