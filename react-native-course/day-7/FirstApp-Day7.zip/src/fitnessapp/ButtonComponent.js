import React from 'react'
import { Text, View, StyleSheet } from 'react-native'

export default function ButtonComponent(props) {
  return (
    <View>
      <Text style={styles.button} onPress={() => props.navigation.navigate(props.navigateTo)}>{props.title}</Text>
    </View>
  )
}
const styles = StyleSheet.create({
  button: {
    backgroundColor: "blue",
    padding: 15,
    margin: 10,
    textAlign: "center",
    color: "white",
    fontFamily: "PoppinsBold",
    fontSize: 20,
    borderRadius: 5
  }
})