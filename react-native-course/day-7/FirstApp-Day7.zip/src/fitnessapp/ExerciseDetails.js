import React from 'react'
import { Text, View, TextInput, StyleSheet, Image, ImageBackground } from 'react-native';
import Icon from 'react-native-vector-icons/FontAwesome'
import Session from './Session';
import { images } from './utils/images';

export default function ExerciseDetails({ route }) {
  const sessions = [
    {
      active: true,
      title: "Session 01"
    },
    {
      active: false,
      title: "Session 02"
    },
    {
      active: false,
      title: "Session 03"
    },
    {
      active: false,
      title: "Session 04"
    },
    {
      active: false,
      title: "Session 05"
    },
    {
      active: false,
      title: "Session 06"
    },
  ]
  return (
    <View>
      <ImageBackground source={images.bgPurple} resizeMode="contain" style={styles.bgStyle}>
        <Text style={styles.heading}>{route.params.item.title}</Text>
        <Text style={styles.text1}>{route.params.item.course}</Text>
        <Text style={[styles.text1, { color: "black", fontSize: 14, width: "80%" }]}>{route.params.item.description}</Text>
        <Image source={route.params.item.image} style={styles.itemStyle} />
        <View style={styles.inputStyle}>
          <Icon name="search" size={20} color="black" style={styles.iconStyle} />
          <TextInput placeholder="Search" style={styles.inputBox} />
        </View>
        <View style={styles.sessionContainer}>
          {sessions.map((session, index) => (
            <Session {...session} index={index} />
          ))}
        </View>
        <Text style={styles.meditation}>{route.params.item.title}</Text>
        <View style={styles.row}>
          <Image source={route.params.item.image} style={styles.exerciseImg} />
          <View>
            <Text style={styles.textStyle}>Tip</Text>
            <Text style={styles.textStyle}>Start slowly to get effective results.</Text>
          </View>
        </View>
      </ImageBackground>
    </View>
  )
}

const styles = StyleSheet.create({
  inputStyle: {
    flexDirection: "row",
    alignItems: "center",
    backgroundColor: "white",
    elevation: 5,
    borderRadius: 100,
    margin: 10,
    marginBottom: 20,
    width: "60%"
  },
  iconStyle: {
    margin: 10,
    marginLeft: 20
  },
  inputBox: {
    padding: 10,
  },
  sessionContainer: {
    flexDirection: "row",
    flexWrap: "wrap",
    justifyContent: "center"
  },
  exerciseImg: {
    width: 100,
    height: 100,
  },
  row: {
    flexDirection: "row",
    alignItems: "center",
  },
  textStyle: {
    fontFamily: "PoppinsBold",
  },
  meditation: {
    fontFamily: "PoppinsBold",
    margin: 15,
    fontSize: 20
  },
  heading: {
    fontFamily: "PoppinsBold",
    margin: 15,
    fontSize: 30,
    marginVertical: 5,
    color: "black"
  },
  text1: {
    fontFamily: "PoppinsBold",
    margin: 15,
    fontSize: 18,
    marginVertical: 5
  },
  bgStyle: {
    height: 300
  },
  itemStyle: {
    width: 350,
    height: 350,
    position: "absolute",
    top: -100,
    right: -130
  }
})
