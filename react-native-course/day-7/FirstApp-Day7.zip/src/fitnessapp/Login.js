import React from 'react'
import { Image, Text, View } from 'react-native'
import ButtonComponent from './ButtonComponent'
import InputForm from './InputForm'
import LinkComponent from './LinkComponent'
import Logo from './Logo'

export default function Login({ navigation }) {
  return (
    <View>
      <Logo title="Fitness App" />
      <InputForm icon="user" placeholder="Email" type="email" />
      <InputForm icon="lock" placeholder="Password" type="password" />
      <ButtonComponent title="Sign In" navigation={navigation} navigateTo="Home" />
      <LinkComponent title="Forgot Password?" navigation={navigation} navigateTo="ForgotPassword" />
      <View style={{ margin: 40 }}>

      </View>
      <LinkComponent title="Don't Have An Account? Create here" navigation={navigation} navigateTo="Register" />
    </View>
  )
}
