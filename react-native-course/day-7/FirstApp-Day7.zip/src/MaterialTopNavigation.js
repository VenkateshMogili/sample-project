import React from 'react';
import { createMaterialTopTabNavigator } from '@react-navigation/material-top-tabs';
import Home from './components/Home';
import Settings from './components/Settings';
import TodoApp from './todoapp';
import DateTimeApp from './datetimeapp';
const Tab = createMaterialTopTabNavigator();

export default function MyTabsMaterialTop() {
  return (
    <Tab.Navigator screenOptions={{
      tabBarStyle: { backgroundColor: "navy" },
      tabBarLabelStyle: { color: "white" }
    }}>
      <Tab.Screen name="Todo App" component={TodoApp} />
      <Tab.Screen name="DateTime App" component={DateTimeApp} />
    </Tab.Navigator>
  );
}