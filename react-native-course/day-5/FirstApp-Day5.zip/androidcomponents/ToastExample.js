import React from 'react'
import { Button, ToastAndroid, View } from 'react-native'

export default function ToastExample() {
  const toast1 = () => {
    ToastAndroid.show("New Message", 500);
  }
  const toast2 = () => {
    //ToastAndroid.show("New Message", ToastAndroid.SHORT);
    ToastAndroid.show("New Message", ToastAndroid.LONG);
  }
  const toast3 = () => {
    //ToastAndroid.show("New Message", ToastAndroid.SHORT);
    //ToastAndroid.showWithGravity("New Message", ToastAndroid.SHORT, ToastAndroid.TOP);
    //ToastAndroid.showWithGravity("New Message", ToastAndroid.SHORT, ToastAndroid.BOTTOM);
    ToastAndroid.showWithGravity("New Message", ToastAndroid.SHORT, ToastAndroid.CENTER);
  }
  const toast4 = () => {
    ToastAndroid.showWithGravityAndOffset("New Message", ToastAndroid.SHORT, ToastAndroid.CENTER, 50, 50);
  }
  return (
    <View>
      <Button title="Toast 1" onPress={toast1} />
      <Button title="Toast 2" onPress={toast2} />
      <Button title="Toast 3" onPress={toast3} />
      <Button title="Toast 4" onPress={toast4} />
    </View>
  )
}
