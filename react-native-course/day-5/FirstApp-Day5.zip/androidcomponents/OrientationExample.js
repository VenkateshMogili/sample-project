import React from 'react'
import { Text, useWindowDimensions, View } from 'react-native'

export default function OrientationExample() {
  const { width, height } = useWindowDimensions();
  return (
    <View>
      <Text>Orientation: {width <= height ? "Portrait" : "Landscape"}</Text>
    </View>
  )
}
