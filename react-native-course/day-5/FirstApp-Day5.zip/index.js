/**
 * @format
 */

import { AppRegistry } from 'react-native';
import AndroidComponents from './androidcomponents';
import FlexExample from './androidcomponents/FlexExample';
import PositionsExample from './androidcomponents/PositionsExample';
import App from './App';
import { name as appName } from './app.json';
import OtherComponents from './othercomponents';
import Home from './screens';
import CourseApp from './src';

AppRegistry.registerComponent(appName, () => CourseApp);
