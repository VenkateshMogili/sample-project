import React from 'react'
import { TouchableHighlight, Text } from 'react-native'

export default function TouchableHighlightExample() {
  return (
    <TouchableHighlight onPress={() => alert("Highlight")}>
      <Text style={{ backgroundColor: "orange", padding: 10, margin: 5, color: "white", borderRadius: 10 }}>Click here to highlight</Text>
    </TouchableHighlight>
  )
}
