import React, { useState } from 'react'
import { FlatList, View, Text, ActivityIndicator } from 'react-native'
import SwitchExample from './SwitchExample'

export default function FlatListExample() {
  const [users, setUsers] = useState([
    {
      id: 1,
      name: "Venkatesh Mogili",
    },
    {
      id: 2,
      name: "Venkatesh Mogili",
    },
    {
      id: 3,
      name: "Venkatesh Mogili",
    },
    {
      id: 4,
      name: "Venkatesh Mogili",
    },
    {
      id: 5,
      name: "Venkatesh Mogili",
    }
  ]);
  const onScrollEnd = () => {
    let newId = users[users.length - 1].id + 1;
    let newObj = { id: newId, name: "Venkatesh Mogili" };
    let oldUsers = [...users, newObj];
    setUsers(oldUsers);
  }
  return (
    <View>
      <Text style={{ fontSize: 30, textAlign: "center" }}>Users List</Text>
      <FlatList
        data={users}
        keyExtractor={(item) => item.id}
        renderItem={({ item }) => (
          <View style={{ flexDirection: "row", justifyContent: "space-between", borderWidth: 1, borderRadius: 10, margin: 5, padding: 5, alignItems: "center" }}>
            <Text>{item.name}</Text>
            <SwitchExample />
          </View>
        )}
        ItemSeparatorComponent={() => (
          <View style={{ borderWidth: 0.5, margin: 5, }} />
        )}
        onEndReached={onScrollEnd}
        refreshing={false}
        onRefresh={() => (
          <ActivityIndicator />
        )}
      />
    </View>
  )
}
