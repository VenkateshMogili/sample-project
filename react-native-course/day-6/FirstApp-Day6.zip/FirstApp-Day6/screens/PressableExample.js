import React from 'react'
import { Pressable, Text } from 'react-native'

export default function PressableExample() {
  return (
    <Pressable onPress={() => alert("Pressable")} onLongPress={() => alert("Long Pressed")}>
      <Text style={{ backgroundColor: "navy", padding: 10, margin: 5, color: "white", borderRadius: 10 }}>Click here to show alert</Text>
    </Pressable>
  )
}
