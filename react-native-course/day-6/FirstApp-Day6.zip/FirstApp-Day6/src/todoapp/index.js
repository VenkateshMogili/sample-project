import React, { useEffect, useState } from 'react'
import { Button, FlatList, StatusBar, Text, TextInput, View } from 'react-native'
import SplashScreen from 'react-native-splash-screen';
import Icon from 'react-native-vector-icons/MaterialIcons';
import { styles } from './styles';
export default function TodoApp() {
  const [todos, setTodos] = useState([
    {
      id: 1,
      title: "Todo 1",
      completed: true
    },
    {
      id: 2,
      title: "Todo 2",
      completed: false
    }
  ]);
  const [todo, setTodo] = useState("")
  const [id, setId] = useState(null)
  useEffect(() => {
    setTimeout(() => {
      SplashScreen.hide();
    }, 1000);
  }, []);
  const TodoItem = ({ item }) => {
    return (
      <View style={styles.todo}>
        <Text style={[styles.title, { textDecorationLine: item.completed === true ? "line-through" : "none" }]} onPress={() => updateStatus(item.id)}>{item.title}</Text>
        <View style={styles.icons}>
          <Icon name="edit" size={25} color="white" onPress={() => {
            setId(item.id);
            setTodo(item.title);
          }} />
          <Icon name="delete" size={25} color="tomato" onPress={() => deleteTodo(item.id)} />
        </View>
      </View>
    )
  }
  const deleteTodo = (id) => {
    let updatedTodos = [...todos];
    updatedTodos = updatedTodos.filter(todo => todo.id != id);
    setTodos(updatedTodos);
  }
  const updateStatus = (id) => {
    let index = todos.findIndex(todo => todo.id === id);
    let updatedTodos = [...todos];
    updatedTodos[index].completed = !updatedTodos[index].completed;
    setTodos(updatedTodos);
  }
  const addTodo = () => {
    if (todo.trim().length > 0) {
      if (id === null) {
        let newId = todos.length > 0 ? todos[todos.length - 1].id + 1 : 1;
        let newTodo = { id: newId, title: todo, completed: false };
        let updatedTodos = [...todos, newTodo];
        setTodos(updatedTodos);
        setTodo("");
      } else {
        let index = todos.findIndex(todo => todo.id === id);
        let updatedTodos = [...todos];
        updatedTodos[index].title = todo;
        setTodos(updatedTodos);
        setId(null);
        setTodo("");
      }
    } else {
      alert("Please fill input!");
    }
  }
  return (
    <View style={styles.container}>
      <StatusBar backgroundColor="navy" />
      <Text style={styles.heading}>Todo App</Text>
      <View style={styles.inputContainer}>
        <TextInput placeholder="Enter your todo" value={todo} onChangeText={(text) => setTodo(text)} />
        <Button title={id === null ? "Add" : "Edit"} onPress={addTodo} />
      </View>
      <View style={styles.todolist}>
        <FlatList
          data={todos}
          keyExtractor={(item) => item.id}
          renderItem={TodoItem}
        />
      </View>
    </View>
  )
}
