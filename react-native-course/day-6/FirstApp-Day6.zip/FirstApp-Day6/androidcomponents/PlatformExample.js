import React from 'react'
import { Platform, Text, View } from 'react-native'

export default function PlatformExample() {
  return (
    <View>
      <Text>Platform</Text>
      <Text>OS: {Platform.OS}</Text>
      <Text style={{ color: Platform.OS === "ios" ? "red" : "blue" }}>Venkatesh Mogili</Text>
    </View>
  )
}
