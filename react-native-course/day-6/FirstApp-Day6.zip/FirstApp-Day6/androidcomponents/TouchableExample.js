import React from 'react'
import { Image, Text, TouchableNativeFeedback, View } from 'react-native'

export default function TouchableExample() {
  return (
    <TouchableNativeFeedback useForeground={false} background={TouchableNativeFeedback.Ripple("blue", false)}>
      <View style={{ height: 300, margin: 10, borderWidth: 1, padding: 10 }}>
        <Text>Hello World!</Text>
        <Image source={require("../assets/profile.jpg")} style={{ width: 100, height: 100 }} />
      </View>
    </TouchableNativeFeedback>
  )
}
