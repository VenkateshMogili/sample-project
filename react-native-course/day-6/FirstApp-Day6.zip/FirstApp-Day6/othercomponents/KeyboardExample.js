import React from 'react'
import { KeyboardAvoidingView, ScrollView, StyleSheet, Text, TextInput, View } from 'react-native'

export default function KeyboardExample() {
  return (
    <KeyboardAvoidingView behavior="position" enabled style={{ height: "100%" }}>
      <ScrollView>
        <View>
          <TextInput placeholder="Enter your name" style={styles.inputStyle} />
          <TextInput placeholder="Enter your name" style={styles.inputStyle} />
          <TextInput placeholder="Enter your name" style={styles.inputStyle} />
          <TextInput placeholder="Enter your name" style={styles.inputStyle} />
          <TextInput placeholder="Enter your name" style={styles.inputStyle} />
          <TextInput placeholder="Enter your name" style={styles.inputStyle} />
          <TextInput placeholder="Enter your name" style={styles.inputStyle} />
          <TextInput placeholder="Enter your name" style={styles.inputStyle} />
          <TextInput placeholder="Enter your name" style={styles.inputStyle} />
        </View>
      </ScrollView>
    </KeyboardAvoidingView>
  )
}

const styles = StyleSheet.create({
  inputStyle: {
    borderWidth: 1,
    borderColor: "black",
    padding: 20,
    margin: 10
  }
})