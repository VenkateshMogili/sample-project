import React, { useState } from 'react'
import { Button, Modal, Text, View } from 'react-native'

export default function ModalExample() {
  const [isVisible, setVisible] = useState(false);
  return (
    <View>
      <Button title="Open Modal" onPress={() => setVisible(!isVisible)} />
      <Modal visible={isVisible} animationType="none" transparent>
        <View style={{ flex: 1, elevation: 5, margin: 10, padding: 10, backgroundColor: "white", borderRadius: 10, justifyContent: "center", alignItems: "center" }}>
          <Text style={{ fontSize: 30 }}>Venkatesh Mogili</Text>
          <Button title="Close Modal" onPress={() => setVisible(!isVisible)} />
        </View>
      </Modal>
    </View>
  )
}
