import React, { useRef } from 'react'
import { Animated, Button, Text, View } from 'react-native'

export default function AnimationExample() {
  const fadAnimation = useRef(new Animated.Value(0)).current;
  const fadeIn = () => {
    Animated.timing(fadAnimation, {
      toValue: 1,
      duration: 1000,
      useNativeDriver: true
    }).start();
  }
  const fadeOut = () => {
    Animated.timing(fadAnimation, {
      toValue: 0,
      duration: 1000,
      useNativeDriver: true
    }).start();
  }
  return (
    <View>
      <Animated.View style={{
        backgroundColor: "black", height: 300, justifyContent: "center",
        opacity: fadAnimation
      }}>
        <Text style={{ fontSize: 30, color: "white", textAlign: "center" }}>Venkatesh Mogili</Text>
      </Animated.View>
      <Button title="Fade In" onPress={fadeIn} />
      <View style={{ margin: 10 }} />
      <Button title="Fade Out" onPress={fadeOut} />
    </View>
  )
}
