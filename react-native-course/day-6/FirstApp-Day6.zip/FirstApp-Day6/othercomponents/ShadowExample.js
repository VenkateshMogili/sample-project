import React from 'react'
import { View } from 'react-native'

export default function ShadowExample() {
  return (
    <View style={{ height: 300, margin: 10, padding: 20, backgroundColor: "white", elevation: 120 }}>
    </View>
  )
}
