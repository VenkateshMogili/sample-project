import React from 'react'
import "./App.css"
import RefactoringExample from './tips/RefactoringExample'

export default function App() {
  return (
    <div className='App'>
      <h1>React Developer Tips!</h1>
      <RefactoringExample />
    </div>
  )
}