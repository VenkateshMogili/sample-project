import React from 'react'
import "./App.css"
import PropPlowing from './tips/PropPlowing'

export default function App() {
  return (
    <div className='App'>
      <h1>React Developer Tips!</h1>
      <PropPlowing />
    </div>
  )
}