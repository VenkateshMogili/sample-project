import React from "react";
export function ButtonComponent({
  setShow,
  show
}) {
  return <button className='btn btn-primary' onClick={() => setShow(!show)}>Show Details</button>;
}
