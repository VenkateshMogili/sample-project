
export function UserDetails({
  firstName = "",
  lastName = "",
  handleChange
}) {
  return <div>
    <h1>User Details:</h1>
    <p>FirstName: {firstName}</p>
    <p>LastName: {lastName}</p>
    <input type="text" value={firstName} onChange={handleChange("personalInfo")} name="firstName" />
    <br />
    <input type="text" value={lastName} onChange={handleChange("personalInfo")} name="lastName" />
  </div>;
}
