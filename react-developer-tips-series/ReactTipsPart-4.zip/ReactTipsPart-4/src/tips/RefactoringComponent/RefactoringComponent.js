import { ButtonComponent } from './ButtonComponent';
import { useUserData } from './useUserData';
import { UserDetails } from './UserDetails';
import React, { useState } from 'react'
import "./style.css";

export default function RefactoringComponent() {
  const { userDetails, handleChange, show, setShow } = useUserData();
  return (
    <>
      {show &&
        <UserDetails
          {...userDetails.personalInfo}
          handleChange={handleChange}
        />}
      <ButtonComponent setShow={setShow} show={show} />
    </>
  )
}



