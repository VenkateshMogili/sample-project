import React, { useState } from 'react'
export function useUserData() {
  const [show, setShow] = useState(false);
  const [userDetails, setUserDetails] = useState({
    personalInfo: {
      firstName: "Venkatesh",
      lastName: "Mogili"
    },
    jobInfo: {
      experience: 1,
      profession: "React"
    }
  });

  const handleChange = key => {
    return event => {
      let updatedData = {
        ...userDetails
      };
      updatedData[key][event.target.name] = event.target.value;
      setUserDetails(updatedData);
    };
  };

  return {
    userDetails,
    handleChange,
    show,
    setShow
  };
}
