import React, { useState } from 'react'

export default function SmartComponent() {
  const { firstName, lastName, setFirstName, setLastName } = useUserData();
  return (
    <div>
      <h1>User Details:</h1>
      <p>FirstName: {firstName}</p>
      <p>LastName: {lastName}</p>
      <button onClick={() => setFirstName("Vivek")} className="btn btn-primary">Update First Name</button>
      <button onClick={() => setLastName("M")} className="btn btn-primary">Update Last Name</button>
    </div>
  )
}
function useUserData() {
  const [firstName, setFirstName] = useState("Venkatesh");
  const [lastName, setLastName] = useState("Mogili");
  return { firstName, lastName, setFirstName, setLastName }
}
