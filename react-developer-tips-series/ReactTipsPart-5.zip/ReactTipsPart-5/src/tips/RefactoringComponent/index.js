import RefactoringComponent from "./RefactoringComponent";
export default RefactoringComponent;