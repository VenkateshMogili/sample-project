import React from 'react'
import "./App.css"
import NestedComponent from './tips/NestedComponents'

export default function App() {
  return (
    <div className='App'>
      <h1>React Developer Tips!</h1>
      <NestedComponent />
    </div>
  )
}