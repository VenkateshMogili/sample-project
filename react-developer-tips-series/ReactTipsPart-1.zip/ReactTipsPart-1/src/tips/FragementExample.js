import React from 'react'

export default function FragementExample() {
  return (
    <table style={{ width: "100%", border: "1px solid red" }}>
      <thead>
        <tr>
          <Columns />
        </tr>
      </thead>
      <tbody>
        <tr>
          <td>1</td>
          <td>Venkatesh</td>
        </tr>
      </tbody>
    </table>
  )
}

function Columns() {
  return (
    <>
      <th>S.No</th>
      <th>Name</th>
    </>
  )
}