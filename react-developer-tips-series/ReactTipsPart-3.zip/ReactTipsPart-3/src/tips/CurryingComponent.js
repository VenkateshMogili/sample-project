import React, { useState } from 'react'

export default function CurryingComponent() {
  const { userDetails, handleChange } = useUserData();
  return (
    <div>
      <h1>User Details:</h1>
      <p>FirstName: {userDetails.personalInfo.firstName}</p>
      <p>LastName: {userDetails.personalInfo.lastName}</p>
      {/*<input type="text" value={userDetails.personalInfo.firstName} onChange={(e) => handleChange(e, "personalInfo")} name="firstName" />
      <br />
      <input type="text" value={userDetails.personalInfo.lastName} onChange={(e) => handleChange(e, "personalInfo")} name="lastName" />*/}
      <input
        type="text"
        value={userDetails.personalInfo.firstName}
        onChange={handleChange("personalInfo")}
        name="firstName" />
      <br />
      <input
        type="text"
        value={userDetails.personalInfo.lastName}
        onChange={handleChange("personalInfo")}
        name="lastName" />
    </div>
  )
}
function useUserData() {
  const [userDetails, setUserDetails] = useState(
    {
      personalInfo: {
        firstName: "Venkatesh",
        lastName: "Mogili"
      },
      jobInfo: {
        experience: 1,
        profession: "React"
      }
    }
  );
  //const handleChange = (event, key) => {
  //  let updatedData = { ...userDetails };
  //  updatedData[key][event.target.name] = event.target.value;
  //  setUserDetails(updatedData)
  //}
  const handleChange = (key) => {
    return (event) => {
      let updatedData = { ...userDetails };
      updatedData[key][event.target.name] = event.target.value;
      setUserDetails(updatedData)
    }
  }
  return { userDetails, handleChange }
}
