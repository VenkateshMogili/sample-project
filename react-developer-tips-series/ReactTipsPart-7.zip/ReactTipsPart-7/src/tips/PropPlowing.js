import React, { useState } from 'react'

export default function PropPlowing() {
  const { userDetails, handleChange } = useUserData();
  return (
    <UserDetails
      {...userDetails.personalInfo}
      handleChange={handleChange}
    />
  )
}
function UserDetails({ firstName = "", lastName = "", handleChange }) {
  return (
    <div>
      <h1>User Details:</h1>
      <p>FirstName: {firstName}</p>
      <p>LastName: {lastName}</p>
      <input
        type="text"
        value={firstName}
        onChange={handleChange("personalInfo")}
        name="firstName" />
      <br />
      <input
        type="text"
        value={lastName}
        onChange={handleChange("personalInfo")}
        name="lastName" />
    </div>
  )
}
function useUserData() {
  const [userDetails, setUserDetails] = useState(
    {
      personalInfo: {
        firstName: "Venkatesh",
        lastName: "Mogili"
      },
      jobInfo: {
        experience: 1,
        profession: "React"
      }
    }
  );
  const handleChange = (key) => {
    return (event) => {
      let updatedData = { ...userDetails };
      updatedData[key][event.target.name] = event.target.value;
      setUserDetails(updatedData)
    }
  }
  return { userDetails, handleChange }
}
