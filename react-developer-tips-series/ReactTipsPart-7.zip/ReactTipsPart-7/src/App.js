import React from 'react'
import "./App.css"
import CurryingComponent from './tips/CurryingComponent'
import FragementExample from './tips/FragementExample'
import NestedComponent from './tips/NestedComponents'
import PropPlowing from './tips/PropPlowing'
import RefactoringComponent from './tips/RefactoringComponent'
import SmartComponent from './tips/SmartComponent'

export default function App() {
  return (
    <div className='App'>
      <h1>React Developer Tips!</h1>
      {/*<FragementExample />
      <SmartComponent />
      <CurryingComponent />
      <PropPlowing />*/}
      {/*<NestedComponent />*/}
      <RefactoringComponent />
    </div>
  )
}