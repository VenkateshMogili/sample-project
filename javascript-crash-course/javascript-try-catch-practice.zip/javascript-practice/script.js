// Example-1: No Errors
// try{
//   console.log("Try Block!");
// } catch{
//   console.log("Catch Block!");
// }

// Example-2: Catching Errors
// try{
//   const a=10;
//   a=20;
// } catch(error){
//   console.log(error);
// }


// Example-3: Validate JSON
// const text = "Sample";
// // JSON.parse(text);

// function isValidJSON(text){
//   try{
//     JSON.parse(text);
//     return true;
//   }catch{
//     return false;
//   }
// }

// const result = isValidJSON(text)?JSON.parse(text):"Invalid JSON Format";

// console.log(result);



// Example-4: Real-time API Calls Handling
// API Endpoint: https://jsonplaceholder.typicode.com/todos

async function fetchTodos(){
  document.getElementById("loading").style.display="block";
  try{
  const response = await fetch("https://jsonplaceholder.typicode.com/todos");
  const data = await response.json();
  return data;
  } catch(error){
    console.log(error);
  } finally{
    document.getElementById("loading").style.display="none";
  }
}

fetchTodos().then(data=>console.log(data));
