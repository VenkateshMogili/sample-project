<?php
// Validations
$fill_all_fields="Please fill all the field!";
$registration_success="Registered Successfully!";
$registration_failed="Registration Failed!";
$already_registered="Already registered with this email!";
$wrong_credentials="Wrong Email/Password";
$reset_success="Reset Password Successfully!";
$reset_failed="Reset Password Failed!";
$wrong_email="Wrong Email!";
$passwords_not_matching="Passwords not matching!";

// Redirect
$go_back="window.history.back()";
$dashboard="Location: dashboard.php";
$login="Location: login.php";
$signup="Location: index.php";
$reset="Location: reset.php";
?>