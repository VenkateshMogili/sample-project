<?php
session_start();
error_reporting(0);
require_once "db_connection.php";
?>