import {useState} from 'react';
import {Redirect, Route, Switch} from 'react-router-dom';
import './App.css';
import ClassComponent2, {Sample2, Button, Container} from './ClassComponent';
import Albums from './components/Albums/Albums';
import Header from './components/Header/Header';
import Heading from './components/Heading';
import PlayMusic from './components/PlayMusic/PlayMusic';
import PrivateRoute from './components/PrivateRoute';
import SingleComponent from './components/SingleComponent';
import Lifecycle from './Lifecycle';
import LifecycleFunction from './LifecycleFunction';
import Sample from './Sample';
import {ClassComponent} from './Sample';
function App(props) {
  const [song, setSong] = useState('');
  const [show, setShow] = useState(false);
  return (
    <div className="App">
      <header className="App-header">
        {/* Music App */}
        {/* <Header showPlayer={() => setShow(true)} />
        {show && <Albums setSong={(song) => setSong(song)} />}
        {show && <PlayMusic song={song} />} */}
        {/* {show && <Lifecycle name="venkatesh" />}
        <button onClick={() => setShow(!show)}>Add/Remove</button> */}
        {/* {show && <LifecycleFunction />} */}

        <Switch>
          <Redirect from="/v1" to="/home" />
          <Route path="/" exact>
            <h1>Hello</h1>
          </Route>
          <Route path="/home" exact>
            <h1>Home</h1>
          </Route>
          {/* <Route path="/home/products/:id/:title" component={SingleComponent} /> */}
          <Route path="/home/products/search" component={SingleComponent} />
          <Route path="/home/products" />
          <Route path="/albums" sensitive exact strict component={Albums} />
          <Route path="/notfound" render={() => <h1>404 Not Found!</h1>} />
          <PrivateRoute path="/dashboard">
            <h1>Dashboard</h1>
          </PrivateRoute>
          <Route path="/login">
            <Header showPlayer={() => setShow(true)} />
          </Route>
          <PrivateRoute path="/music">
            <Heading />
            <Header showPlayer={() => setShow(true)} />
            {show && <Albums setSong={(song) => setSong(song)} />}
            {show && <PlayMusic song={song} />}
          </PrivateRoute>
          <Route path="*" render={() => <h1>404 Not Found!</h1>} />
        </Switch>
      </header>
    </div>
  );
}

export default App;
