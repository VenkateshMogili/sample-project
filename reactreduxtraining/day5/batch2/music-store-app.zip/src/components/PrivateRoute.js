import React, {useState} from 'react';
import {Redirect, Switch, Route} from 'react-router-dom';

export default function PrivateRoute(props) {
  const [isLoggedIn, setLoggedIn] = useState(
    localStorage.getItem('isLogin') !== null ? localStorage.getItem('isLogin') : 0,
  );
  return (
    <div>
      {isLoggedIn == 0 && <Redirect to="/login" />}
      <Switch>
        <Route {...props}>{props.children}</Route>
      </Switch>
    </div>
  );
}
