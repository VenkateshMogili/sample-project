import {Component} from 'react';
export class ClassComponent4 extends Component {
  render() {
    return <h1>Class 4</h1>;
  }
}
function Sample(props) {
  return <div>{props.children}</div>;
}
export function Button() {
  return <h1>Another</h1>;
}
export default Sample;
