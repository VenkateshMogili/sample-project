const {createStore, combineReducers, applyMiddleware} = require('redux');
const logger = require('redux-logger').default;
const thunk = require('redux-thunk').default;
const {mobileReducer} = require('./reducers/mobile');
const {laptopReducer} = require('./actions/laptop');
const {usersReducer} = require('./async');

const rootReducer = combineReducers({mobileReducer, laptopReducer, usersReducer});

const store = createStore(rootReducer, applyMiddleware(logger, thunk));

module.exports = store;
