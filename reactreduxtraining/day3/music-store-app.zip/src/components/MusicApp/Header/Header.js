export default function Header() {
	return (
		<div>
			{/* App Name */}
			<h1>Music Store Application</h1>
		</div>
	);
}
