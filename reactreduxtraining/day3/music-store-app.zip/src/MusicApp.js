import { useState } from "react";
import Albums from "./components/MusicApp/Albums/Albums";
import Header from "./components/MusicApp/Header/Header";
import PlayerMusic from "./components/MusicApp/PlayMusic/PlayMusic";
import "./css/style.css";
function MusicApp(props) {
	const [ song, setSong ] = useState("song1.mp3");
	// initial song
	return (
		<div>
			{/* Header */}
			<Header />
			{/* Albums */}
			<Albums setSong={(song) => setSong(song)} />
			{/* Player */}
			<PlayerMusic song={song} />
		</div>
	);
}

export default MusicApp;
