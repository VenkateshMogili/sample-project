import React from 'react'

export default function Button(props) {
  console.log(props.title)
  return (
    <button>{props.title}</button>
  )
}
