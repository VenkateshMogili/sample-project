import './App.css';
import React from 'react';
import Header from './Header';
import HeaderClass from './HeaderClass';
import Button from './Button';
import Button1 from './Button1';
import { useState } from 'react';

export default function App() {
  const [childData, setChildData] = useState("Submit Text");
  return (
    <div>
      <Button1 title={childData} subtitle="Reset Text" onChange={(data) => setChildData(data)} />
      {/*<Button
        title="Click here"
        name="Venkatesh"
        users={[1, 2, 3, 4]}
        userInfo={{ profession: "Training" }}
      />
      <Button
        title="Submit"
        name="Venkatesh"
        users={[1, 2, 3, 4]}
        userInfo={{ profession: "Training" }}
      />
      <Button
        title="Reset"
        name="Venkatesh"
        users={[1, 2, 3, 4]}
        userInfo={{ profession: "Training" }}
      />*/}
      {/*<Header />
      <Header />
      <Header />
      <Header />
      <Header />
      <HeaderClass />
      <HeaderClass />
      <HeaderClass />
      <HeaderClass />*/}
      <HeaderClass />
      {/*<h1>Hello World!</h1>*/}
    </div>
  )
}
