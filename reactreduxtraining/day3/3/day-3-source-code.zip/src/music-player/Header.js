import React from 'react'

export default function Header() {
  return (
    <h1>Music Store Application</h1>
  )
}
