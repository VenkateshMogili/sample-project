import { Grid, Container, Card } from '@material-ui/core'
import React from 'react'
import Item from './Item'
//import ClassComponent from '../Lifecyles/ClassComponent'

export default function Albums(props) {
  return (
    <div className='container'>
      <Container maxWidth="sm">
        <Grid container spacing={2}>
          <Grid item xs={12}>
            <Card variant="outlined">
              <Item src="assets/images/main-poster.jpg" song="song1.mp3" updateSong={(song) => props.updateSong(song)} />
            </Card>
          </Grid>
          <Grid item xs={6}>
            <Card variant="outlined">
              <Item src="assets/images/album1.jpg" song="song2.mp3" updateSong={(song) => props.updateSong(song)} />
            </Card>
          </Grid>
          <Grid item xs={6}>
            <Card variant="outlined">
              <Item src="assets/images/album2.jpg" song="song3.mp3" updateSong={(song) => props.updateSong(song)} />
            </Card>
          </Grid>
          <Grid item xs={3}>
            <Card variant="outlined">
              <Item src="assets/images/album3.jpg" song="song4.mp3" updateSong={(song) => props.updateSong(song)} />
            </Card>
          </Grid>
          <Grid item xs={3}>
            <Card variant="outlined">
              <Item src="assets/images/album4.jpg" song="song5.mp3" updateSong={(song) => props.updateSong(song)} />
            </Card>
          </Grid>
          <Grid item xs={3}>
            <Card variant="outlined">
              <Item src="assets/images/album5.jpg" song="song6.mp3" updateSong={(song) => props.updateSong(song)} />
            </Card>
          </Grid>
          <Grid item xs={3}>
            <Card variant="outlined">
              <Item src="assets/images/album6.jpg" song="song7.mp3" updateSong={(song) => props.updateSong(song)} />
            </Card>
          </Grid>
        </Grid>
      </Container>
    </div>
  )
}
