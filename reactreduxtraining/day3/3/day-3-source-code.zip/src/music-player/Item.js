import React from 'react'
import "./style.css"
import PlayCircleFilled from '@material-ui/icons/PlayCircleFilled';

export default function Item(props) {
  return (
    <div className='m-1 p-1'>
      <img src={props.src} alt="main poster" className='poster' />
      <div onClick={() => props.updateSong(props.song)}>
        <PlayCircleFilled color="primary" />
      </div>
    </div>
  )
}
