import React from 'react'

export default function Button2(props) {
  return (
    <button>{props.subtitle}</button>
  )
}
