import React, { Component } from 'react';
export default function Header() {
  return (
    <h1>Header</h1>
  )
}

//export const Header = () => {
//  return <h1>Header</h1>
//}