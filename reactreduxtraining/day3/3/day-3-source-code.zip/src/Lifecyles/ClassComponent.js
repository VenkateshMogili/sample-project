import React, { Component } from 'react'

export class ClassComponent extends Component {
  constructor() {
    super();
    console.log("constructor");
  }
  static getDerivedStateFromProps() {
    console.log("derived")
    return null;
  }
  componentDidMount() {
    console.log("did mount")
  }
  componentWillUnmount() {
    console.log("killed")
  }
  render() {
    console.log("render");
    return (
      <div>ClassComponent</div>
    )
  }
}

export default ClassComponent