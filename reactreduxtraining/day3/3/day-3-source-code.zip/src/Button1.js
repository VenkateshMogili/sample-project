import React from 'react'
import Button2 from './Button2'

export default function Button1(props) {
  return (
    <div>
      <button onClick={() => props.onChange("This is from child")}>{props.title}</button>
      <Button2 subtitle={props.subtitle} />
    </div>
  )
}
