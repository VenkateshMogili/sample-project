import React, { useState } from 'react'
import { useEffect } from 'react';
import "./App.css";
import ClassComponent from './Lifecyles/ClassComponent';
import Albums from './music-player/Albums';
import Header from './music-player/Header';
import Player from './music-player/Player'
import "./music-player/style.css";

export default function App() {
  const [song, setSong] = useState("song1.mp3");
  useEffect(() => {
    console.log("mounting/updating");
    return () => {
      console.log("unmounting")
    }
  }, [song])

  const handleSubmit = (e) => {
    e.preventDefault();
    console.log("Form submitted");
  }
  return (
    <div className='App'>
      <form onSubmit={handleSubmit}>
        <input type="text" value={song} onChange={(e) => setSong(e.target.value)} />
        <input type="submit" value="Submit" />
      </form>
      {/*<ClassComponent />*/}
      <Header />
      <Albums updateSong={(updatedSong) => setSong(updatedSong)} />
      <Player song={song} />
    </div>
  )
}
