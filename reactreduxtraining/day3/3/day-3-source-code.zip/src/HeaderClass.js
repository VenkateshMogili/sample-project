import React from 'react';
import Header from './Header';
class HeaderClass extends React.Component {
  constructor() {
    super();
    this.state = {
      count: 10
    }
  }
  render() {
    return (
      <div>
        <Header />
        <h1>Header from Class {this.state.count} {this.state.childData}</h1>
        <button onClick={() => this.setState({ count: this.state.count + 10 })}>Update count</button>
      </div>
    )
  }
}
export default HeaderClass;