import './WeatherApp.css';
import React from 'react';
import cloud1 from './images/cloud1.png';

export default function WeatherApp() {
  let weathers = [
    {
      day: "Monday",
      time: "July 3rd, 7 PM",
      image: cloud1,
      temperature: "35",
      name: "Clear Sky"
    },
    {
      day: "Tuesday",
      time: "July 3rd, 7 PM",
      image: cloud1,
      temperature: "35",
      name: "Clear Sky"
    },
    {
      day: "Wednessday",
      time: "July 3rd, 7 PM",
      image: cloud1,
      temperature: "35",
      name: "Clear Sky"
    },
    {
      day: "Thursday",
      time: "July 3rd, 7 PM",
      image: cloud1,
      temperature: "35",
      name: "Clear Sky"
    },
    {
      day: "Friday",
      time: "July 3rd, 7 PM",
      image: cloud1,
      temperature: "35",
      name: "Clear Sky"
    }
  ]
  return (
    <div className='container'>
      <div className='bg-secondary text-white m-3 p-3 rounded text-center'>
        <h1>5-Day Forecast</h1>
      </div>
      <p className='text-center'>Andhra Pradesh, India</p>
      <div className='d-flex justify-content-between'>
        {weathers.length > 0 && weathers.map((weather, index) => (
          <div className='border text-center p-3 m-3 rounded col-md-2' key={index}>
            <p><b>{weather.day}</b></p>
            <p className='small'>{weather.time}</p>
            <img src={weather.image} alt="weather name" className='weather-img' />
            <h3>{weather.temperature} <sup>o</sup>F</h3>
            <small>{weather.name}</small>
          </div>
        ))}
      </div>
    </div>
  )
}
