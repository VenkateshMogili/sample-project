import './App.css';
import React from 'react';
import movie1 from './images/movie1.png';
import movie2 from './images/movie2.png';
import movie3 from './images/movie3.png';
import movie4 from './images/movie4.png';
import Netflix from './Netflix';

export default function App() {
  //let button = <button>Click here</button>;//jsx
  //let button2 = React.createElement('button', null, 'Hello World!');//babel

  return (
    <div className="App">
      <header className="App-header">
        {/*<h1 style={{ color: "white", fontSize: 100 }}>Hello World!</h1>
        {button}
        {button2}*/}

        <h1>Movie World!</h1>
        <div className='movies1'>
          <img src={movie1} alt="movie 1" />
          <img src={movie2} alt="movie 2" />
          <img src={movie3} alt="movie 3" />
          <img src={movie4} alt="movie 4" />
        </div>
        <div className='movies1 mt'>
          <img src={movie4} alt="movie 4" />
          <img src={movie3} alt="movie 3" />
          <img src={movie2} alt="movie 2" />
          <img src={movie1} alt="movie 1" />
        </div>
        <Netflix />
      </header>
    </div>
  )
}
