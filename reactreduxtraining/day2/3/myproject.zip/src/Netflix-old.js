import './Netflix.css';
import React from 'react';
//import { useState } from 'react';

export default function Netflix() {
  //const [count, setCount] = useState(0);
  let company = "amazon";
  let user = "user";
  let movies = [
    { id: 1, name: 'Movie 1' },
    { id: 2, name: 'Movie 2' },
    { id: 3, name: 'Movie 3' }
  ];
  //useEffect(() => {
  //  let x = setInterval(() => {
  //    setCount(count => count + 1);
  //    if (count > 10) {
  //      clearInterval(x)
  //    }
  //  }, 1000);

  //}, [])
  return (
    <div className="BgImg">
      <div className='navbar'>
        <h1 className='logo'>
          {/*{company === "netflix" && "NETFLIX"}
          {company === "amazon" && "AMAZON PRIME"}*/}
          {company === "netflix" ? "NETFLIX" : (company === "amazon" ? "AMAZON PRIME" : "No Company")}
          {/*{count}*/}
        </h1>
        <button className='btn btn-primary'>
          {user === "admin" ? "Sign in as admin" : "Sign In"}</button>
      </div>
      <div className='content'>
        <h1>Unlimited Movies, TV <br /> Shows and more.</h1>
        <h2>Watch anywhere. Cancel anytime.</h2>
        <p>Ready to watch? Enter your email.</p>
        <input type="email" placeholder='Email Address' />
        <button className='getStarted'>Get Started &gt;</button>
        <div className='movies'>
          {movies.length > 0 && movies.map((movie, index) => (
            <p key={movie.id}>{movie ? movie.name : ""}</p>
          ))}
        </div>
      </div>
    </div>
  )
}
