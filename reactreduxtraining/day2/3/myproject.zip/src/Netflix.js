import './Netflix.css';
import React from 'react';
import tv1 from './images/tv1.png';
import tv2 from './images/tv2.png';
import tv3 from './images/tv3.png';
import tv4 from './images/tv4.png';

export default function Netflix() {
  return (
    <div className='bg-dark'>
      <div className="BgImg">
        <div className='navbar'>
          <h1 className='logo'>
            NETFLIX
          </h1>
          <button className='btn btn-primary'>
            Sign In</button>
        </div>
        <div className='content'>
          <h1>Unlimited Movies, TV <br /> Shows and more.</h1>
          <h2>Watch anywhere. Cancel anytime.</h2>
          <p>Ready to watch? Enter your email.</p>
          <input type="email" placeholder='Email Address' />
          <button className='getStarted'>Get Started &gt;</button>
        </div>
      </div>
      <div className='d-flex justify-content-center align-items-center mt-3 mb-3 bg-dark2'>
        <div className='col-md-4 text-white'>
          <h1>Enjoy on your TV.</h1>
          <h3>Watch on smart TVs, PlayStation, Xbox, Chromecast, Apple TV, Blu-ray players and more.</h3>
        </div>
        <div className='col-md-4'>
          <img src={tv1} alt="TV1" className='tv-img' />
        </div>
      </div>
      <div className='d-flex justify-content-center align-items-center mt-3 mb-3 bg-dark2'>
        <div className='col-md-4'>
          <img src={tv2} alt="TV2" className='tv-img' />
        </div>
        <div className='col-md-4 text-white'>
          <h1>Download your shows to watch offline.</h1>
          <h3>Save your favourites easily and always have something to watch.</h3>
        </div>
      </div>

      <div className='d-flex justify-content-center align-items-center mt-3 mb-3 bg-dark2'>
        <div className='col-md-4 text-white'>
          <h1>Watch everywhere.</h1>
          <h3>Stream unlimited movies and TV shows on your phone, tablet, laptop, and TV</h3>
        </div>
        <div className='col-md-4'>
          <img src={tv3} alt="TV3" className='tv-img' />
        </div>
      </div>

      <div className='d-flex justify-content-center align-items-center mt-3 mb-3 bg-dark2'>
        <div className='col-md-4'>
          <img src={tv4} alt="TV4" className='tv-img' />
        </div>
        <div className='col-md-4 text-white'>
          <h1>Create profiles for children.</h1>
          <h3>Send children on adventures with their favourite characters in a space made just for them—free with your membership.</h3>
        </div>
      </div>
    </div>
  )
}
