import "./App.css";
import Typography from "@material-ui/core/Typography";
import brokenClouds from "./images/broken-clouds.png";
import clearSky from "./images/clear-sky.png";
import lightRain from "./images/light-rain.png";
import thunderStorm from "./images/thunder-storm.png";

function App() {
	const weatherList = [
		{
			day: "Monday",
			time: "April 5th, 1:00 pm",
			icon: clearSky,
			temperature: "35",
			status: "clear sky",
		},
		{
			day: "Tuesday",
			time: "April 6th, 1:00 pm",
			icon: lightRain,
			temperature: "36",
			status: "light rain",
		},
		{
			day: "Wednessday",
			time: "April 7th, 1:00 pm",
			icon: brokenClouds,
			temperature: "36",
			status: "broken clouds",
		},
		{
			day: "Thursday",
			time: "April 8th, 1:00 pm",
			icon: clearSky,
			temperature: "34",
			status: "clear sky",
		},
		{
			day: "Friday",
			time: "April 9th, 1:00 pm",
			icon: thunderStorm,
			temperature: "26",
			status: "thunder storm",
		},
	];
	// let user = { name: "Venkatesh" };
	// let a = false;
	return (
		<div className="App">
			<div className="header">
				<Typography variant="h1" component="h2" color="primary">
					5-Day Forecast
				</Typography>
			</div>
			<p>New Delhi, India</p>
			<div className="items">
				{weatherList.length > 0 &&
					weatherList.map((item, index) => (
						<div key={index} className="item">
							<h2>{item.day}</h2>
							<p>{item.time}</p>
							<img src={item.icon} alt="Weather" className="img-style" />
							<h2>
								{item.temperature} <sup>o</sup>F
							</h2>
							<p>{item.status}</p>
						</div>
					))}
			</div>
		</div>
	);
}

export default App;
