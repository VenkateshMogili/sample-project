module.exports={
setupFilesAfterEnv:["./src/setupTests.js"], 
moduleNameMapper: { "\\.(css|less|scss)$": "identity-obj-proxy", }
};