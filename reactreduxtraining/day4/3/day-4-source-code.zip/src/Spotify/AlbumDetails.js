import React from 'react'
import { useParams } from 'react-router-dom';

export default function AlbumDetails() {
  const { id } = useParams();
  const albums = [
    {
      id: 1,
      name: "Movie 1",
      song: "song1.mp3",

    },
    {
      id: 2,
      name: "Movie 2",
      song: "song1.mp3",
    }
  ]
  return (
    <div>AlbumDetails {id} and {albums.filter(item => item.id == id).length > 0 && albums.filter(item => item.id == id)[0].name}</div>
  )
}
