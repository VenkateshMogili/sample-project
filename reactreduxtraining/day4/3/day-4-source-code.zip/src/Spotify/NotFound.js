import React from 'react'

export default function NotFound() {
  return (
    <div className='vh-100'>
      <h1 className='text-danger text-center mt-5 pt-5'>404 Not Found!</h1>
    </div>
  )
}
