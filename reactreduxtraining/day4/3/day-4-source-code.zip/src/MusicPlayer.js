import React, { useState } from 'react'
import { useEffect } from 'react';
import "./App.css";
import Albums from './music-player/Albums';
import Header from './music-player/Header';
import Player from './music-player/Player'
import "./music-player/style.css";
import { Navigate } from 'react-router-dom';
import { useSearchParams, Outlet, Link } from "react-router-dom";

export default function MusicPlayer() {
  const [song, setSong] = useState("song1.mp3");
  let [searchParams, setSearchParams] = useSearchParams();
  console.log(searchParams.get("name"))
  console.log(searchParams.get("profession"))
  useEffect(() => {
    console.log("mounting/updating");
    return () => {
      console.log("unmounting")
    }
  }, [song])

  const handleSubmit = (e) => {
    e.preventDefault();
    console.log("Form submitted");
  }
  return (
    <div className='App'>
      <Link to="/albums/movie1" className='text-white m-2'>Movie 1</Link>
      <Link to="/albums/movie2" className='text-white m-2'>Movie 2</Link>
      <Outlet />
      <Header />
      <Albums updateSong={(updatedSong) => setSong(updatedSong)} />
      <Player song={song} />
      {/*<Navigate to="/about" replace={false} />*/}
    </div>
  )
}
