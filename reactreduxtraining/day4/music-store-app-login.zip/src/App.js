import {useState} from 'react';
import './App.css';
import ClassComponent2, {Sample2, Button, Container} from './ClassComponent';
import Albums from './components/Albums/Albums';
import Header from './components/Header/Header';
import PlayMusic from './components/PlayMusic/PlayMusic';
import Lifecycle from './Lifecycle';
import LifecycleFunction from './LifecycleFunction';
import Heading, {ClassComponent} from './Sample';
function App(props) {
  const [song, setSong] = useState('');
  const [show, setShow] = useState(false);
  return (
    <div className="App">
      <header className="App-header">
        {/* Music App */}
        <Header showPlayer={() => setShow(true)} />
        {show && <Albums setSong={(song) => setSong(song)} />}
        {show && <PlayMusic song={song} />}
        {/* {show && <Lifecycle name="venkatesh" />}
        <button onClick={() => setShow(!show)}>Add/Remove</button> */}
        {/* {show && <LifecycleFunction />} */}
      </header>
    </div>
  );
}

export default App;
