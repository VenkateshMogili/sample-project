import React, {Component, useState} from 'react';
export default class ClassComponent2 extends Component {
  constructor(props) {
    super(props);
    this.state = {
      color: 'green',
      age: 20,
    };
  }

  render() {
    return (
      <div>
        <h1>Class Component {this.state.color}</h1>
        <button onClick={() => this.setState({color: 'orange'})}>Change color</button>
        <Button title="Example" age={10} color={this.state.color} setColor={(color) => this.setState({color})} />
      </div>
    );
  }
}
function Sample2() {
  return <h1>Sample2</h1>;
}
function Button({title, age, color, setColor}) {
  const [colors, setColors] = useState('red');
  return (
    <button style={{color: color !== undefined ? color : ''}} onClick={() => setColor('blue')}>
      {title} {age !== undefined && age.name} {colors}
    </button>
  );
}
function Container(props) {
  return <div>{props.children}</div>;
}
export {Sample2, Button, Container};
