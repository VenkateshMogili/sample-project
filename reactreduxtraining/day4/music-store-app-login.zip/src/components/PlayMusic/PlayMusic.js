import React from 'react';
import AudioPlayer from 'react-h5-audio-player';
import 'react-h5-audio-player/lib/styles.css';
import '../css/style.css';
export default function PlayMusic(props) {
  return (
    <div className="poster player">
      <AudioPlayer src={'music/' + props.song} autoPlay={false} showJumpControls={false} />
    </div>
  );
}
