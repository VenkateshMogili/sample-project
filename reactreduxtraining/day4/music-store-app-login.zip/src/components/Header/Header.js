import React, {useState,useEffect} from 'react';
import Button from '@material-ui/core/Button';
import {Paper} from '@material-ui/core';
import '../css/style.css';
export default function Header({showPlayer}) {
  const [user, setUser] = useState({
    username: '',
    password: '',
  });
  const [status, setStatus] = useState('');
  const [isLoggedIn, setLoggedIn] = useState(
    localStorage.getItem('isLogin') !== null ? localStorage.getItem('isLogin') : 0,
  );
  const handleChange = (e) => {
    setUser((prevState) => {
      return {...prevState, [e.target.name]: e.target.value};
    });
  };
  const handleSubmit = (e) => {
    e.preventDefault();
    localStorage.setItem('userData', JSON.stringify(user));
  };
  const handleLogin = (e) => {
    e.preventDefault();
    let username = localStorage.getItem('userData') !== null && JSON.parse(localStorage.getItem('userData')).username;
    let password = localStorage.getItem('userData') !== null && JSON.parse(localStorage.getItem('userData')).password;
    if (user.username === username && user.password === password) {
      alert('Logged in successfully');
      localStorage.setItem('isLogin', 1);
      setLoggedIn(1);
    } else {
      alert('Wrong username/password');
    }
  };
  useEffect(() => {
    if (isLoggedIn === 0) {
      console.log("logoued")
    }
  }, [isLoggedIn])
  const styles = {
    backgroundColor: 'white',
    heading: {
      color: 'black',
    },
  };
  return (
    <div>
      <h1>Music Store Application</h1>
      {isLoggedIn === 0 && (
        <Button color="primary" variant="contained" onClick={() => setStatus('signup')}>
          Sign Up
        </Button>
      )}
      &nbsp;&nbsp;&nbsp;
      {isLoggedIn === 0 && (
        <Button color="primary" variant="contained" onClick={() => setStatus('signin')}>
          Sign In
        </Button>
      )}
      &nbsp;&nbsp;&nbsp;
      {isLoggedIn === 1 && (
        <>
        <Button color="primary" variant="contained" onClick={() => showPlayer(true)}>
            Music Player
        </Button>
           &nbsp;&nbsp;&nbsp;
          <Button color="secondary" variant="contained" onClick={() => { localStorage.removeItem("isLogin"); setLoggedIn(0) }}>
           Logout
        </Button>
          </>
      )}
      <br />
      <br />
      {/* Sign up form */}
      {status === 'signup' &&
      isLoggedIn === 0 && (
        <Paper>
          <form style={{paddingBottom: 10, ...styles}} onSubmit={handleSubmit}>
            <h1 style={styles.heading}>Sign Up</h1>
            <input
              type="email"
              placeholder="Username"
              name="username"
              className="input-style"
              value={user.username}
              onChange={(e) => handleChange(e)}
            />
            <br />
            <input
              type="password"
              placeholder="Password"
              name="password"
              className="input-style"
              value={user.password}
              onChange={(e) => handleChange(e)}
            />
            <br />

            <Button color="primary" variant="contained" type="submit">
              Sing Up
            </Button>
          </form>
        </Paper>
      )}
      <br />
      {/* Sign In form */}
      {status === 'signin' &&
      isLoggedIn === 0 && (
        <Paper>
          <form style={{paddingBottom: 10, ...styles}} onSubmit={handleLogin}>
            <h1 style={styles.heading}>Sign In</h1>
            <input
              type="email"
              placeholder="Username"
              name="username"
              className="input-style"
              value={user.username}
              onChange={(e) => handleChange(e)}
            />
            <br />
            <input
              type="password"
              placeholder="Password"
              name="password"
              className="input-style"
              value={user.password}
              onChange={(e) => handleChange(e)}
            />
            <br />

            <Button color="primary" variant="contained" type="submit">
              Login
            </Button>
          </form>
        </Paper>
      )}
      <br />
    </div>
  );
}
