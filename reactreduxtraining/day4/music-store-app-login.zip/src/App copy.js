import './App.css';
import ClassComponent2, {Sample2, Button, Container} from './ClassComponent';
import Heading, {ClassComponent} from './Sample';
function App(props) {
  return (
    <div className="App">
      <header className="App-header">
        {/* Music App */}

        {/* <Heading /> */}
        {/* <ClassComponent />
        <ClassComponent2 />
        <Sample2 />
        <Button title="Hi" />
        <Button title="Hello" />
        <input type="text" placeholder="Enter your name" title="" value="" />
        <Container>
          <h1>Hello</h1>
          <h1>Hello</h1>
          <h1>Hello</h1>
          <Button title="Hello" age={{name: 'vivek'}} />
        </Container> */}
      </header>
    </div>
  );
}

export default App;
