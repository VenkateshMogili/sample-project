import React, {Component} from 'react';

export class Lifecycle extends Component {
  constructor(props) {
    super(props);
    console.log('Constructor()');
    this.state = {
      name: 'venkatesh',
    };
    // this.submit = this.submit.bind(this);
  }
  static getDerivedStateFromProps(props, state) {
    console.log('getDerivedStateFromProps()');
    if (props.name !== state.name) {
      return {
        name: state.name,
      };
    }
    return null;
  }
  shouldComponentUpdate(nextProps, nextState) {
    console.log('shouldComponentUpdate()');
    if (nextState !== this.state) {
      return true;
    } else {
      return false;
    }
  }
  getSnapshotBeforeUpdate(prevProps, prevState) {
    console.log('getSnapshotBeforeUpdate()', prevProps, prevState);
    return {oldName: prevState.name};
  }
  componentDidUpdate(prevProps, prevState, snapshot) {
    console.log('componentDidUpdate()', prevProps, prevState, snapshot);
    if (prevState.name !== this.state.name) {
      this.setState({name: this.state.name});
    }
  }
  componentDidMount() {
    console.log('componentDidMount()');
    this.setState({name: 'vivek'});
  }
  componentWillUnmount() {
    console.log('componentWillUnmount()');
  }
  submit(e) {
    console.log('Submitted', e);
  }
  render() {
    console.log('render()');
    return (
      <div>
        <h1>Life cycle methods {this.state.name}</h1>
        <button onClick={(e) => this.submit(e)}>Submit</button>
      </div>
    );
  }
}

export default Lifecycle;
