import React, {useEffect, useState} from 'react';

export default function LifecycleFunction() {
  const [name, setName] = useState(0);
  useEffect(
    () => {
      console.log('Component did/update mount');
      return () => {
        console.log('unmounting');
      };
    },
    [name],
  );
  return (
    <div>
      <h1>Functional Life cycle</h1>
      <button onClick={() => setName(name + 1)}>Click it</button>
    </div>
  );
}
