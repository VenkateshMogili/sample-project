import React, {Component} from 'react';

export default function Sample() {
  let a = 10;
  return null;
}

class ClassComponent extends Component {
  constructor(props) {
    super(props);
  }

  render() {
    return <h1>Class Component Function</h1>;
  }
}
// function Sample2() {
//   return <h1>Sample 2</h1>;
// }
export {ClassComponent};
