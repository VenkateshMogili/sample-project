import { useState, useEffect } from "react";
import Albums from "./components/MusicApp/Albums/Albums";
import Header from "./components/MusicApp/Header/Header";
import PlayerMusic from "./components/MusicApp/PlayMusic/PlayMusic";
import "./css/style.css";
function MusicApp(props) {
	const [ song, setSong ] = useState("song1.mp3");
	const [ loggedin, setLoggedin ] = useState(false);
	// initial song
	return (
		<div>
			{/* Header */}
			<Header setLoggedin={(status) => setLoggedin(status)} />
			{loggedin && (
				<div>
					{/* Albums */}
					<Albums setSong={(song) => setSong(song)} />
					{/* Player */}
					<PlayerMusic song={song} />
				</div>
			)}
		</div>
	);
}

export default MusicApp;
