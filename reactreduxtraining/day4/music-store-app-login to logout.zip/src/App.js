import "./App.css";
// import { ClassComponent, ClassComponent2, ClassComponent3 } from "./ClassComponent";
// import SampleCode, { Button, ClassComponent4 } from "./Sample";
import MusicApp from "./MusicApp";
import "./css/style.css";
// import Lifecycle from "./Lifecycle";
// import LifecycleFunction from "./LifecycleFunction";
function App() {
	return (
		<div className="App">
			<header className="App-header">
				{/* Music App */}
				{/* <Lifecycle /> */}
				{/* <LifecycleFunction song="song1"/> */}
				<MusicApp song="song1.mp3" />
				{/* <h1>Hello World!</h1>
				<SampleCode />
				<ClassComponent />
				<ClassComponent />
				<ClassComponent />
				<ClassComponent />
				<ClassComponent />
				<ClassComponent />
				<ClassComponent />
				<ClassComponent2 />
				<button>Submit</button>
				<Button>Sample</Button>
				<ClassComponent3 />
				<ClassComponent4 /> */}
			</header>
		</div>
	);
}

export default App;
