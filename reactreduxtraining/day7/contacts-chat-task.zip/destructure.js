const user = { name: "Venkatesh", age: 10 };

const { name } = user;

console.log(name);

// function userData() {
// 	return [ "venkatesh", 10 ];
// }
function useState() {
	function age() {
		return 5;
	}
	return [ "venkatesh", age() ];
}
const users = useState();

const [ username, age ] = users;
const [ name2, age2 ] = users;

console.log(username, age);
console.log(name2, age2);
