import React, { useEffect, useState } from "react";

export const useFetch = (url, method, headers, body = {}) => {
	const [ data, setData ] = useState([]);
	useEffect(
		() => {
			let methodType = method;
			if (methodType === "post") {
				fetch(url, {
					method,
					headers,
					body: JSON.stringify(body),
				})
					.then((response) => response.json())
					.then((data) => {
						setData(data);
					});
			} else {
				fetch(url).then((response) => response.json()).then((data) => {
					setData(data);
				});
			}
		},
		[ url ],
	);
	return data;
};
