import React from 'react'
import { Link, useNavigate } from 'react-router-dom'
import api from './api'

export default function OrderSummary({ invoice = false, totalOrder, items, order }) {

  const navigate = useNavigate();
  const handlePlaceorder = () => {
    let headers = {
      "content-type": "application/json"
    };
    var randomnumber = Math.floor(100000 + Math.random() * 900000)
    api("http://localhost:4000/orders", "GET")
      .then(orders => {
        let orderData = {
          id: orders.length > 0 ? orders[orders.length - 1].id + 1 : 1,
          orderId: "ORDER_" + randomnumber,
          orderTotal: totalOrder,
          items,
          tax: 0
        }
        api("http://localhost:4000/orders", "POST", headers, orderData)
          .then(response => {
            alert("Order Placed");
            navigate("/dashboard/invoice/" + response.orderId);
          })
      })
  }
  return (
    <div className='m-2 pt-4 card shadow p-4'>
      <h3>Order Summary</h3>
      <div className='container'>
        <div className='d-flex justify-content-between'>
          <p>Items:</p>
          <p>$ {totalOrder}</p>
        </div>
        <div className='d-flex justify-content-between'>
          <p>Shipping:</p>
          <p>$ 0</p>
        </div>
        <div className='d-flex justify-content-between'>
          <p>Esimated GST:</p>
          <p>$ 0</p>
        </div>
        <div className='d-flex justify-content-between'>
          <p>Gift Card:</p>
          <p>$ 0</p>
        </div>
        <hr />

        <div className='d-flex text-danger justify-content-between'>
          <h4>Order Total:</h4>
          <h4>$ {totalOrder}</h4>
        </div>
        <hr />
        {order && Object.keys(order).length > 0 ? null : <Link to="/dashboard/invoice" className='d-flex justify-content-end text-decoration-none'>
          <button onClick={handlePlaceorder} className=' form-control bg-dark text-white rounded'>Place your order</button>
        </Link>}
      </div>
      {!invoice ? <Link to="/dashboard/bag" className='d-flex justify-content-end text-decoration-none'>
        <button className='bg-dark text-white rounded m-3'><i className='fa fa-angle-left' /> Back</button>
      </Link> :
        <div className='d-flex justify-content-end text-decoration-none'>
          <button onClick={() => window.print()} className='bg-dark text-white rounded m-3'><i className='fa fa-print' /> Print</button>
        </div>}
    </div>
  )
}
