import React from 'react'
import { NavLink, Link, useNavigate } from 'react-router-dom'

export default function SideNav() {
  let navigate = useNavigate();
  return (
    <div className='non-printable'>
      <div className="d-flex flex-column flex-shrink-0 p-3 text-white bg-dark vh-100" style={{ width: 78 }}>
        <a href="/" className="d-flex align-items-center mb-3 mb-md-0 me-md-auto text-white text-decoration-none">
          <i className='fa fa-mobile fs-4 text-center mr-2 p-2' /> EC
        </a>
        <hr />
        <ul className="nav nav-pills flex-column mb-auto">
          <li className="nav-item">
            <NavLink to="/dashboard/home" className={({ isActive }) => isActive ? "nav-link active" : "nav-link text-white"} aria-current="page">
              <i className='fa fa-home' />
            </NavLink>
          </li>
          <li>
            <NavLink to="/dashboard/bag" className={({ isActive }) => isActive ? "nav-link active" : "nav-link text-white"}>
              <i className='fa fa-shopping-cart' />
            </NavLink>
          </li>
        </ul>
        <hr />
        <div className="dropdown">
          <a href="#" className="d-flex align-items-center text-white text-decoration-none dropdown-toggle" id="dropdownUser1" data-bs-toggle="dropdown" aria-expanded="false">
            <img src="https://github.com/mdo.png" alt="" width="32" height="32" className="rounded-circle me-2" />
          </a>
          <ul className="dropdown-menu dropdown-menu-dark text-small shadow" aria-labelledby="dropdownUser1">
            <li><Link className="dropdown-item" to="/dashboard/profile">Profile</Link></li>
            <li><button className="dropdown-item" onClick={() => {
              localStorage.removeItem("user");
              navigate("/login");
            }
            }>Sign out</button></li>
          </ul>
        </div>
      </div>
    </div>
  )
}
