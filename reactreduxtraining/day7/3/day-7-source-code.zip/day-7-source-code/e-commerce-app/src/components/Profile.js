import React, { useEffect, useState } from 'react';
import "../styles/SignUp.css";
import api from './api';

export default function Profile() {
  const [userDetails, setUserDetails] = useState({
    fullname: "",
    email: "",
    id: ""
  });
  const handleChange = ({ target: { name, value } }) => {
    let updatedDetails = { ...userDetails };
    updatedDetails[name] = value;
    setUserDetails(updatedDetails)
  }
  const handleSubmit = (e) => {
    e.preventDefault();
    console.log(userDetails);
    let headers = {
      "content-type": "application/json"
    };
    api("http://localhost:4000/users/" + userDetails.id, "GET").then(userData => {
      let body = { ...userData };
      body.fullname = userDetails.fullname;
      api("http://localhost:4000/users/" + userDetails.id, "PUT", headers, body).then(response => {
        console.log("new user", response);
        alert("Updated Successfully!");
        let user = localStorage.getItem("user") != null ? JSON.parse(localStorage.getItem("user")) : null;
        localStorage.setItem("user", JSON.stringify({ ...user, name: userDetails.fullname }))
      })
    })
  }
  useEffect(() => {
    let user = localStorage.getItem("user") != null ? JSON.parse(localStorage.getItem("user")) : null;
    if (user !== null) {
      setUserDetails({ fullname: user.name, email: user.email, id: user.id })
    }
  }, [])
  return (
    <div className='container mt-5 pt-5'>
      <div className='container'>
        <h1 className='text-center'>Your Profile</h1>
        <form onSubmit={handleSubmit}>
          <InputElement
            label="Full Name"
            placeholder="Enter your full name"
            id="fullname"
            value={userDetails.fullname}
            handleChange={handleChange}
            type="text"
          />
          <InputElement
            label="Email"
            placeholder="Enter your email address"
            id="email"
            value={userDetails.email}
            handleChange={handleChange}
            type="email"
            disabled={true}
          />
          <button type="submit" className='btn btn-dark form-control mt-2'>Update Profile</button>
        </form>
      </div>
    </div>
  )
}
function InputElement({ label, placeholder, id, value, handleChange, type, disabled }) {
  return (
    <div className='input_element'>
      <label htmlFor={id} className='label'>{label}</label>
      <input disabled={disabled} type={type} value={value} onChange={handleChange} id={id} name={id} className='form-control input_style' placeholder={placeholder} />
    </div>
  )
}
