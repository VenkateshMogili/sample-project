import React, { useEffect, useState } from 'react'
import api from './api'
import { Link } from 'react-router-dom'

export default function InvoiceAddress({ order }) {
  const [userData, setUserData] = useState(null)
  useEffect(() => {
    let user = localStorage.getItem("user") !== null ? JSON.parse(localStorage.getItem("user")) : null;
    if (user !== null) {
      api("http://localhost:4000/users/" + user.id, "GET")
        .then(response => {
          console.log(response)
          setUserData(response)
        })
    }
  }, [])
  return (
    <div className='container card p-3 mt-3'>
      <h1>INVOICE</h1>
      <p>#{order.orderId}</p>
    </div>
  )
}
