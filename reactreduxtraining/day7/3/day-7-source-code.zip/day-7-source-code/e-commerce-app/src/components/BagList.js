import React, { useEffect, useState } from 'react'
import api from './api';
import Bag from './Bag';
import "../styles/ProductList.css";
import { Link } from 'react-router-dom'
import { useDispatch, useSelector } from 'react-redux';
import { addItem, decrement, increment } from '../features/counterSlice';
import OrderSummary from './OrderSummary';

export default function BagList({ title, hideBag = false, invoice = false, order }) {
  const [searchText, setSearchText] = useState("");
  const [products, setProducts] = useState([]);
  const [totalCost, setTotalCost] = useState(0);
  let cart = useSelector((store) => store.counter.cart);
  console.log(cart)
  const dispatch = useDispatch();
  const handleChange = ({ target: { name, value } }) => {
    setSearchText(value);
  };
  const handleCart = (id, quantity) => {
    dispatch(addItem({ productId: id, quantity }))
  }
  useEffect(() => {
    api("http://localhost:4000/products", "GET").then(productsReceived => {
      setProducts(productsReceived)
    })
  }, [])
  let [bagItems, setBagItems] = useState([])
  useEffect(() => {
    if (order && Object.keys(order).length > 0) {
      let allProducts = [...order.items];
      let totalCost = allProducts.reduce((prev, current) => {
        return prev + (current.productPrice * current.quantity)
      }, 0)
      setTotalCost(totalCost);
      setBagItems(allProducts)
    } else {
      api("http://localhost:4000/products", "GET").then(productsReceived => {
        let allProducts = [...productsReceived];
        let allCartIds = cart.map(cartItem => cartItem.productId);
        let filterdProducts = allProducts.filter(item => {
          if (allCartIds.includes(item.id)) {
            return { ...item };
          }
        }).map(item => {
          let quantity = cart.filter(cartItem => cartItem.productId === item.id)[0].quantity;
          return { ...item, quantity }
        });

        let totalCost = filterdProducts.reduce((prev, current) => {
          return prev + (current.productPrice * current.quantity)
        }, 0)
        setTotalCost(totalCost);
        setBagItems(filterdProducts)
      })
    }
  }, [cart])
  return (
    <div className='d-flex justify-content-between'>
      <div className='container mt-1 col-md-9'>
        {order && Object.keys(order).length > 0 ? null : <SearchItems
          id="searchText"
          value={searchText}
          handleChange={handleChange}
        />}
        <h1>{title}</h1>
        <div className='d-flex flex-wrap'>
          {bagItems.length > 0 && bagItems.filter(product => {
            return product.productName.toLowerCase().indexOf(searchText.toLowerCase()) > -1 || product.productVersion.toLowerCase().indexOf(searchText.toLowerCase()) > -1 || product.productPrice.toString().toLowerCase().indexOf(searchText.toLowerCase()) > -1
          }).map((product, index) => (
            <div className='m-2 p-2 bg-light rounded d-flex'>
              <Link to={"/dashboard/products/" + product.id} className="text-decoration-none text-dark">
                <img className='card shadow m-2' src={"/images/" + product.productImages[0]} alt="product image" />
              </Link>
              <div>
                <h4 className='m-1'>{product.productName}</h4>
                <h5 className='m-1'>{product.productVersion}</h5>
                <h5 className='m-1'>{product.productDescription}</h5>
                <h5 className='m-1'>{product.rating}/{product.ratingTotal}</h5>
                <div className='d-flex justify-content-between align-items-center'>
                  <h5 className='m-1'>$ {product.productPrice} x {product.quantity}</h5>
                  {cart && cart.length > 0 && cart.filter(cartItem => cartItem.productId === product.id).length > 0 && <div className='d-flex align-items-center'>
                    <button className='rounded border-0 bg-dark text-white' onClick={() => dispatch(decrement({ productId: product.id }))}>-</button>
                    <p className='m-2'>{product.quantity}</p>
                    <button className='rounded border-0 bg-dark text-white' onClick={() => dispatch(increment({ productId: product.id }))}>+</button>
                  </div>}
                  {order && Object.keys(order).length > 0 ? null : (cart && cart.filter(cartItem => cartItem.productId === product.id).length === 0 && <i className='fa fa-shopping-cart bg-dark text-white p-2 rounded' onClick={() => handleCart(product.id, 1)} />)}
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
      {!hideBag && <Bag products={products} checkout={true} />}
      {hideBag && <OrderSummary invoice={invoice} totalOrder={totalCost} items={bagItems} order={order} />}
    </div>
  )
}

function SearchItems({ id, value, handleChange }) {
  return (
    <div className='input_element non-printable'>
      <label htmlFor={id} className='label'>Search Item</label>
      <input type="text" value={value} onChange={handleChange} id={id} name={id} className='form-control input_style' placeholder="Search your items...." />
    </div>
  )
}