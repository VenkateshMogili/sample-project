import React, { useState, useEffect } from 'react'
import { useDispatch, useSelector } from 'react-redux';
import api from './api';
import BagList from './BagList'
import PaymentAddress from './PaymentAddress';
import ShippingAddress from './ShippingAddress';

export default function Checkout() {
  const [products, setProducts] = useState([]);
  let cart = useSelector((store) => store.counter.cart);
  const dispatch = useDispatch();
  useEffect(() => {
    api("http://localhost:4000/products", "GET").then(productsReceived => {
      setProducts(productsReceived)
    })
  }, [])
  let [bagItems, setBagItems] = useState([])
  useEffect(() => {
    api("http://localhost:4000/products", "GET").then(productsReceived => {
      let allProducts = [...productsReceived];
      let allCartIds = cart.map(cartItem => cartItem.productId);
      let filterdProducts = allProducts.filter(item => {
        if (allCartIds.includes(item.id)) {
          return { ...item };
        }
      }).map(item => {
        let quantity = cart.filter(cartItem => cartItem.productId === item.id)[0].quantity;
        return { ...item, quantity }
      });
      setBagItems(filterdProducts)
    })
  }, [cart])
  return (
    <div>
      <ShippingAddress />
      <PaymentAddress />
      <div className='m-5'>
        <BagList title="REVIEW YOUR BAG" hideBag={true} />
      </div>
    </div>
  )
}
