import React, { useEffect, useState } from 'react'
import api from './api'
import { Link } from 'react-router-dom'

export default function ShippingAddress() {
  const [userData, setUserData] = useState(null)
  useEffect(() => {
    let user = localStorage.getItem("user") !== null ? JSON.parse(localStorage.getItem("user")) : null;
    if (user !== null) {
      api("http://localhost:4000/users/" + user.id, "GET")
        .then(response => {
          console.log(response)
          setUserData(response)
        })
    }
  }, [])
  return (
    <div className='container card p-3 mt-3'>
      <h1>SHIPPING ADDRESS</h1>
      <div className='d-flex justify-content-between align-items-start'>
        {userData && userData.shipping_addresses && userData.shipping_addresses.length > 0 && userData.shipping_addresses.filter(address => address.default_address === "Yes").length > 0 && userData.shipping_addresses.filter(address => address.default_address === "Yes") ? <div>
          <p>{userData.shipping_addresses.filter(address => address.default_address === "Yes")[0].name}</p>
          <p>{userData.shipping_addresses.filter(address => address.default_address === "Yes")[0].address},{userData.shipping_addresses.filter(address => address.default_address === "Yes")[0].city}</p>
          <p>{userData.shipping_addresses.filter(address => address.default_address === "Yes")[0].state}</p>
          <p>{userData.shipping_addresses.filter(address => address.default_address === "Yes")[0].country}</p>
        </div> : <div>
          <p>No Address Selected</p>
        </div>}
        <Link to="/dashboard/shippingaddress">
          <button className='rounded'>Change</button>
        </Link>
      </div>
    </div>
  )
}
