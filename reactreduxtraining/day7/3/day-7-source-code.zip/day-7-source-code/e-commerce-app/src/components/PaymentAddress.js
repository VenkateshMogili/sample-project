import React, { useEffect, useState } from 'react'
import api from './api'
import { Link } from 'react-router-dom'

export default function PaymentAddress() {
  const [userData, setUserData] = useState(null)
  useEffect(() => {
    let user = localStorage.getItem("user") !== null ? JSON.parse(localStorage.getItem("user")) : null;
    if (user !== null) {
      api("http://localhost:4000/users/" + user.id, "GET")
        .then(response => {
          console.log(response)
          setUserData(response)
        })
    }
  }, [])
  return (
    <div className='container card p-3 mt-3'>
      <h1>PAYMENT METHOD</h1>
      <div className='d-flex justify-content-between align-items-start'>
        {userData && userData.payment_methods && userData.payment_methods.length > 0 && userData.payment_methods.filter(address => address.default_payment === "Yes").length > 0 && userData.payment_methods.filter(address => address.default_payment === "Yes") ? <div>
          <p>{userData.payment_methods.filter(address => address.default_payment === "Yes")[0].card_type} starting with {userData.payment_methods.filter(address => address.default_payment === "Yes")[0].card_number.slice(0, 4)}xxxxxxxxxx</p>
          <p>{userData.payment_methods.filter(address => address.default_payment === "Yes")[0].card_holder_name}</p>
          <p>{userData.payment_methods.filter(address => address.default_payment === "Yes")[0].expire_date}</p>
        </div> : <div>
          <p>No Payment Selected</p>
        </div>}
        <Link to="/dashboard/paymentaddress">
          <button className='rounded'>Change</button>
        </Link>
      </div>
    </div>
  )
}
