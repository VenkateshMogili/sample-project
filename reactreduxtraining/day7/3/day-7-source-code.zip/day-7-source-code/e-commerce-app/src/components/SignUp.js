import React, { useState } from 'react';
import "../styles/SignUp.css";
import api from './api';

export default function SignUp() {
  const [userDetails, setUserDetails] = useState({
    fullname: "",
    email: "",
    password: "",
    confirmpassword: "",
    shipping_addresses: [],
    payment_methods: []
  });
  const handleChange = ({ target: { name, value } }) => {
    let updatedDetails = { ...userDetails };
    updatedDetails[name] = value;
    setUserDetails(updatedDetails)
  }
  const handleSubmit = (e) => {
    e.preventDefault();
    console.log(userDetails);
    let headers = {
      "content-type": "application/json"
    };
    if (userDetails.password === userDetails.confirmpassword) {
      let body = { ...userDetails };
      delete body.confirmpassword;
      api("http://localhost:4000/users", "POST", headers, body).then(response => {
        console.log("new user", response);
        alert("Sign Up Successful!")
      })
    } else {
      alert("Passwords are not matching!")
    }
  }
  return (
    <div className='container mt-5 pt-5'>
      <div className='container mt-5 pt-5'>
        <h1 className='text-center'>Create New Account</h1>
        <form onSubmit={handleSubmit}>
          <InputElement
            label="Full Name"
            placeholder="Enter your full name"
            id="fullname"
            value={userDetails.fullname}
            handleChange={handleChange}
            type="text"
          />
          <InputElement
            label="Email"
            placeholder="Enter your email address"
            id="email"
            value={userDetails.email}
            handleChange={handleChange}
            type="email"
          />
          <InputElement
            label="Password"
            placeholder="Enter your password"
            id="password"
            value={userDetails.password}
            handleChange={handleChange}
            type="password"
          />
          <InputElement
            label="Confirm Password"
            placeholder="Enter confirm password"
            id="confirmpassword"
            value={userDetails.confirmpassword}
            handleChange={handleChange}
            type="password"
          />
          <button type="submit" className='btn btn-dark form-control mt-2'>Sign Up</button>
        </form>
      </div>
    </div>
  )
}
function InputElement({ label, placeholder, id, value, handleChange, type }) {
  return (
    <div className='input_element'>
      <label htmlFor={id} className='label'>{label}</label>
      <input type={type} value={value} onChange={handleChange} id={id} name={id} className='form-control input_style' placeholder={placeholder} />
    </div>
  )
}
