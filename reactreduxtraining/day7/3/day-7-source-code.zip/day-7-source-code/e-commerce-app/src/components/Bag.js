import React, { useEffect, useState } from 'react'
import { useSelector } from 'react-redux'
import { Link } from 'react-router-dom'

export default function Bag({ products, checkout = false }) {
  let cart = useSelector(store => store.counter.cart);
  let [bagItems, setBagItems] = useState([]);
  const [finalCost, setFinalCost] = useState(0)
  useEffect(() => {
    let allProducts = [...products];
    let allCartIds = cart.map(cartItem => cartItem.productId);
    let filterdProducts = allProducts.filter(item => {
      if (allCartIds.includes(item.id)) {
        return { ...item };
      }
    }).map(item => {
      let quantity = cart.filter(cartItem => cartItem.productId === item.id)[0].quantity;
      return { ...item, quantity }
    });
    let totalCost = filterdProducts.reduce((prev, current) => {
      return prev + (current.productPrice * current.quantity)
    }, 0)
    setFinalCost(totalCost)
    setBagItems(filterdProducts)
  }, [cart])
  return (
    <div className='col-md-3'>
      <h1 className='m-4'>Bag</h1>
      <div className='d-flex flex-wrap'>
        {bagItems.length > 0 && bagItems.map((product, index) => (
          <div className='m-2 p-2 rounded' key={index}>
            <img className='card shadow m-2 bag-img' src={"/images/" + product.productImages[0]} alt="product image" />
          </div>
        ))}
      </div>
      {checkout && <h4 className='text-center'>Bag Total: $ {finalCost.toLocaleString('en-US')}</h4>}
      {checkout ?
        <Link to="/dashboard/checkout" className='text-decoration-none'><button className='form-control bg-dark text-white'><i className='fa fa-shopping-cart' /> Checkout</button></Link> :
        <Link to="/dashboard/bag" className='text-decoration-none'><button className='form-control bg-dark text-white'><i className='fa fa-shopping-cart' /> View Bag</button></Link>}
    </div>
  )
}
