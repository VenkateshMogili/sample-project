import React from 'react'
import SideNav from './SideNav'
import { Outlet } from 'react-router-dom';

export default function Home() {
  return (
    <div className='d-flex'>
      <SideNav />
      <Outlet />
    </div>
  )
}
