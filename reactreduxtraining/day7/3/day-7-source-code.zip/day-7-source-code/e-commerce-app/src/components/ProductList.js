import React, { useEffect, useState } from 'react'
import api from './api';
import Bag from './Bag';
import "../styles/ProductList.css";
import { Link } from 'react-router-dom'
import { useDispatch, useSelector } from 'react-redux';
import { addItem, decrement, increment } from '../features/counterSlice';

export default function ProductList() {
  const [searchText, setSearchText] = useState("");
  const [products, setProducts] = useState([]);
  let cart = useSelector((store) => store.counter.cart);
  console.log(cart)
  const dispatch = useDispatch();
  const handleChange = ({ target: { name, value } }) => {
    setSearchText(value);
  };
  const handleCart = (id, quantity) => {
    dispatch(addItem({ productId: id, quantity }))
  }
  useEffect(() => {
    api("http://localhost:4000/products", "GET").then(productsReceived => {
      setProducts(productsReceived)
    })
  }, [])
  return (
    <div className='d-flex justify-content-between'>
      <div className='container mt-5 col-md-9 border-right'>
        <SearchItems
          id="searchText"
          value={searchText}
          handleChange={handleChange}
        />
        <div className='d-flex flex-wrap'>
          {products.length > 0 && products.filter(product => {
            return product.productName.toLowerCase().indexOf(searchText.toLowerCase()) > -1 || product.productVersion.toLowerCase().indexOf(searchText.toLowerCase()) > -1 || product.productPrice.toString().toLowerCase().indexOf(searchText.toLowerCase()) > -1
          }).map((product, index) => (
            <div className='m-2 p-2 bg-light rounded'>
              <Link to={"/dashboard/products/" + product.id} className="text-decoration-none text-dark">
                <img className='card shadow m-2' src={"/images/" + product.productImages[0]} alt="product image" />
              </Link>
              <h4 className='m-1'>{product.productName}</h4>
              <h5 className='m-1'>{product.productVersion}</h5>
              <div className='d-flex justify-content-between align-items-center'>
                <h5 className='m-1'>$ {product.productPrice}</h5>
                {cart && cart.length > 0 && cart.filter(cartItem => cartItem.productId === product.id).length > 0 && <div className='d-flex align-items-center'>
                  <button className='rounded border-0 bg-dark text-white' onClick={() => dispatch(decrement({ productId: product.id }))}>-</button>
                  <p className='m-2'>{cart.filter(cartItem => cartItem.productId === product.id).length > 0 ? cart.filter(cartItem => cartItem.productId === product.id)[0].quantity : 0}</p>
                  <button className='rounded border-0 bg-dark text-white' onClick={() => dispatch(increment({ productId: product.id }))}>+</button>
                </div>}
                {cart && cart.filter(cartItem => cartItem.productId === product.id).length === 0 && <i className='fa fa-shopping-cart bg-dark text-white p-2 rounded' onClick={() => handleCart(product.id, 1)} />}
              </div>
            </div>
          ))}
        </div>
      </div>
      <Bag products={products} />
    </div>
  )
}

function SearchItems({ id, value, handleChange }) {
  return (
    <div className='input_element'>
      <label htmlFor={id} className='label'>Search Item</label>
      <input type="text" value={value} onChange={handleChange} id={id} name={id} className='form-control input_style' placeholder="Search your items...." />
    </div>
  )
}