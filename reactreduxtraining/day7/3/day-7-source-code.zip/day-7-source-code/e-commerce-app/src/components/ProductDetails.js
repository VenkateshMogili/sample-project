import React, { useEffect, useState } from 'react'
import api from './api';
import Bag from './Bag';
import "../styles/ProductList.css";
import { useParams, Link } from 'react-router-dom'

export default function ProductDetails() {
  const { id } = useParams();
  const [product, setProduct] = useState({})
  const [products, setProducts] = useState([])
  useEffect(() => {
    api("http://localhost:4000/products/" + id, "GET").then(productReceived => {
      console.log(productReceived)
      setProduct(productReceived)
    })
    api("http://localhost:4000/products", "GET").then(productReceived => {
      setProducts(productReceived)
    })
  }, [])
  console.log(product)
  return (
    <div className='d-flex justify-content-between'>
      <div className='container mt-5 col-md-9 border-right'>
        <Link to="/dashboard/home"><button className='bg-light text-dark border-0'><i className='fa fa-arrow-left' /> Back</button></Link>
        <div className='d-flex flex-wrap'>
          {product && Object.keys(product).length > 0 && <div>
            <div className='d-flex'>
              <img src={"/images/" + product.productImages[0]} alt="single product" className='col-md-3' />
              <div>
                <h1>{product.productName}</h1>
                <h1>{product.productVersion}</h1>
                <h1>{product.rating}/{product.ratingTotal}</h1>
                <h3>{product.productPrice}</h3>
                <p>{product.productDescription}</p>
                <button className='bg-dark text-white rounded form-control'><i className='fa fa-shopping-cart' /> Add to bag</button>
              </div>
            </div>
            <hr />
            <h4>Description</h4>
            <p>{product.productDescription}</p>
          </div>}

        </div>
      </div>
      <Bag products={products} />
    </div>
  )
}

function SearchItems({ id, value, handleChange }) {
  return (
    <div className='input_element'>
      <label htmlFor={id} className='label'>Search Item</label>
      <input type="text" value={value} onChange={handleChange} id={id} name={id} className='form-control input_style' placeholder="Search your items...." />
    </div>
  )
}