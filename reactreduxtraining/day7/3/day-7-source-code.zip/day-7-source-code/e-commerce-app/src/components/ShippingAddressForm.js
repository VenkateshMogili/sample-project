import React, { useState } from 'react';
import "../styles/SignUp.css";
import api from './api';
import { useNavigate } from 'react-router-dom'

export default function ShippingAddressForm() {
  const [shippingDetails, setShippingDetails] = useState({
    name: "",
    address: "",
    city: "",
    state: "",
    country: "",
    default_address: "No",
  });
  const navigate = useNavigate();
  const handleChange = ({ target: { name, value } }) => {
    let updatedDetails = { ...shippingDetails };
    updatedDetails[name] = value;
    setShippingDetails(updatedDetails)
  }
  const handleChange2 = ({ target: { name, checked } }) => {
    let updatedDetails = { ...shippingDetails };
    updatedDetails[name] = checked ? "Yes" : "No";
    setShippingDetails(updatedDetails)
  }
  const handleSubmit = (e) => {
    e.preventDefault();
    console.log(shippingDetails);
    let headers = {
      "content-type": "application/json"
    };
    let body = { ...shippingDetails };
    let user = localStorage.getItem("user") !== null ? JSON.parse(localStorage.getItem("user")) : null;
    api("http://localhost:4000/users/" + user.id, "GET").then(response => {
      let userDetails = { ...response };
      if (body.default_address === "Yes") {
        let existingAddress = [...userDetails.shipping_addresses].map(address => ({ ...address, default_address: "No" }))
        userDetails.shipping_addresses = [...existingAddress, body];
      } else {
        let existingAddress = [...userDetails.shipping_addresses]
        userDetails.shipping_addresses = [...existingAddress, body];
      }
      api("http://localhost:4000/users/" + user.id, "PUT", headers, userDetails).then(response => {
        console.log("updated user", response);
        navigate("/dashboard/checkout")
      })
    })
  }
  return (
    <div className='container mt-5 pt-5'>
      <div className='container mt-5 pt-5'>
        <h1 className='text-center'>Add Shipping Address</h1>
        <form onSubmit={handleSubmit}>
          <InputElement
            label="Shipping Name"
            placeholder="Enter your full name"
            id="name"
            value={shippingDetails.name}
            handleChange={handleChange}
            type="text"
          />
          <InputElement
            label="Street address"
            placeholder="Enter your address"
            id="address"
            value={shippingDetails.address}
            handleChange={handleChange}
            type="text"
          />
          <InputElement
            label="City"
            placeholder="Enter your city"
            id="city"
            value={shippingDetails.city}
            handleChange={handleChange}
            type="text"
          />
          <InputElement
            label="State"
            placeholder="Enter your state"
            id="state"
            value={shippingDetails.state}
            handleChange={handleChange}
            type="text"
          />
          <InputElement
            label="Country"
            placeholder="Enter your country and pincode"
            id="country"
            value={shippingDetails.country}
            handleChange={handleChange}
            type="text"
          />
          <input
            label="Save this as your default address"
            placeholder="Save this as your default address"
            id="default_address"
            name="default_address"
            value={shippingDetails.default_address}
            checked={shippingDetails.default_address === "Yes" ? true : false}
            onChange={handleChange2}
            type="checkbox"
          /> Save this as your default address
          <button type="submit" className='btn btn-dark form-control mt-2'>Add Address</button>
        </form>
      </div>
    </div>
  )
}
function InputElement({ label, placeholder, id, value, handleChange, type }) {
  return (
    <div className='input_element'>
      <label htmlFor={id} className='label'>{label}</label>
      <input type={type} value={value} onChange={handleChange} id={id} name={id} className='form-control input_style' placeholder={placeholder} />
    </div>
  )
}
