import React, { useEffect, useState } from 'react';
import "../styles/SignUp.css";
import api from './api';
import { useNavigate } from 'react-router-dom'

export default function PaymentAddressForm() {
  const [paymentMethods, setPaymentMethods] = useState({
    card_type: "",
    card_holder_name: "",
    card_number: "",
    expire_date: "",
    default_payment: "No",
  });
  const [paymentMethodsList, setPaymentMethodsList] = useState([])
  const navigate = useNavigate();
  const handleChange = ({ target: { name, value } }) => {
    let updatedDetails = { ...paymentMethods };
    updatedDetails[name] = value;
    setPaymentMethods(updatedDetails)
  }
  const handleChange2 = ({ target: { name, checked } }) => {
    let updatedDetails = { ...paymentMethods };
    updatedDetails[name] = checked ? "Yes" : "No";
    setPaymentMethods(updatedDetails)
  }
  const handleSubmit = (e) => {
    e.preventDefault();
    console.log(paymentMethods);
    let headers = {
      "content-type": "application/json"
    };
    let body = { ...paymentMethods };
    let user = localStorage.getItem("user") !== null ? JSON.parse(localStorage.getItem("user")) : null;
    api("http://localhost:4000/users/" + user.id, "GET").then(response => {
      let userDetails = { ...response };
      if (body.default_payment === "Yes") {
        let existingAddress = [...userDetails.payment_methods].map(address => ({ ...address, default_payment: "No" }))
        userDetails.payment_methods = [...existingAddress, body];
      } else {
        let existingAddress = [...userDetails.payment_methods]
        userDetails.payment_methods = [...existingAddress, body];
      }
      api("http://localhost:4000/users/" + user.id, "PUT", headers, userDetails).then(response => {
        console.log("updated user", response);
        navigate("/dashboard/checkout")
      })
    })
  }
  const changeDefaultPayment = (payment) => {
    let user = localStorage.getItem("user") !== null ? JSON.parse(localStorage.getItem("user")) : null;
    let headers = {
      "content-type": "application/json"
    };
    api("http://localhost:4000/users/" + user.id, "GET").then(response => {
      let userDetails = { ...response };
      let existingAddress = [...userDetails.payment_methods].map(address => ({ ...address, default_payment: "No" }))
      let index = existingAddress.findIndex(item => item.card_number === payment.card_number);
      existingAddress[index].default_payment = "Yes";
      userDetails.payment_methods = existingAddress;
      api("http://localhost:4000/users/" + user.id, "PUT", headers, userDetails).then(response => {
        console.log("updated user", response);
        setPaymentMethodsList(existingAddress);
      })
    })
  }
  useEffect(() => {
    let user = localStorage.getItem("user") !== null ? JSON.parse(localStorage.getItem("user")) : null;
    api("http://localhost:4000/users/" + user.id, "GET").then(response => {
      let userDetails = { ...response };
      let existingAddress = [...userDetails.payment_methods];
      setPaymentMethodsList(existingAddress);
    })
  }, [])
  return (
    <div className='container mt-5'>
      <div className='container mt-5'>
        <div className='card p-3 m-3'>
          <h1>SELECT A CARD</h1>
          {paymentMethodsList.length > 0 && paymentMethodsList.map(payment => (
            <div onClick={() => changeDefaultPayment(payment)}>
              <i className={`fa fa-credit-card ${payment.default_payment === "Yes" ? 'text-success' : ''}`} /> {payment.card_type} ending with {payment.card_number.slice(0, 4)}xxxxxx
            </div>
          ))}
        </div>
        <div className='card p-3 m-3'>
          <h1>Add A New Card</h1>
          <form onSubmit={handleSubmit}>
            <InputElement
              label="Card Type"
              placeholder="Enter your card type"
              id="card_type"
              value={paymentMethods.card_type}
              handleChange={handleChange}
              type="text"
            />
            <InputElement
              label="Card Holder Name"
              placeholder="Enter your card holder name"
              id="card_holder_name"
              value={paymentMethods.card_holder_name}
              handleChange={handleChange}
              type="text"
            />
            <InputElement
              label="Card Number"
              placeholder="Enter your card number"
              id="card_number"
              value={paymentMethods.card_number}
              handleChange={handleChange}
              type="number"
            />
            <InputElement
              label="Expire Date"
              placeholder="Enter your expire date MM/YYYY"
              id="expire_date"
              value={paymentMethods.expire_date}
              handleChange={handleChange}
              type="text"
            />
            <InputElement
              label="CVC"
              placeholder="Enter your cvc"
              id="cvc"
              value={paymentMethods.cvc}
              handleChange={handleChange}
              type="number"
            />
            <input
              label="Save this as your default payment method"
              placeholder="Save this as your default payment method"
              id="default_payment"
              name="default_payment"
              value={paymentMethods.default_payment}
              checked={paymentMethods.default_payment === "Yes" ? true : false}
              onChange={handleChange2}
              type="checkbox"
            /> Save this as your default payment method
            <button type="submit" className='btn btn-dark form-control mt-2'>Add Payment Method</button>
          </form>
        </div>
      </div>
    </div>
  )
}
function InputElement({ label, placeholder, id, value, handleChange, type }) {
  return (
    <div className='input_element'>
      <label htmlFor={id} className='label'>{label}</label>
      <input type={type} value={value} onChange={handleChange} id={id} name={id} className='form-control input_style' placeholder={placeholder} />
    </div>
  )
}
