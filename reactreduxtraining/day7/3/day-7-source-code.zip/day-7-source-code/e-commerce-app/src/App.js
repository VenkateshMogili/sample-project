import React from 'react';
import './App.css';
import Login from './components/Login';
import SideNav from './components/SideNav';
import SignUp from './components/SignUp';
import { Routes, Route, Outlet } from 'react-router-dom';
import Home from './components/Home';
import ProductList from './components/ProductList';
import ProductDetails from './components/ProductDetails';
import BagList from './components/BagList';
import Checkout from './components/Checkout';
import ShippingAddressForm from './components/ShippingAddressForm';
import PaymentAddressForm from './components/PaymentAddressForm';
import Invoice from './components/Invoice';
import Profile from './components/Profile';

function App() {
  return (
    <div>
      <Routes>
        <Route path="dashboard" element={<Home />}>
          <Route path="home" element={<ProductList />} />
          <Route path="products/:id" element={<ProductDetails />} />
          <Route path="bag" element={<BagList title="Check your Bag Items" />} />
          <Route path="checkout" element={<Checkout />} />
          <Route path="shippingaddress" element={<ShippingAddressForm />} />
          <Route path="paymentaddress" element={<PaymentAddressForm />} />
          <Route path="invoice/:id" element={<Invoice />} />
          <Route path="invoice" element={<Invoice />} />
          <Route path="profile" element={<Profile />} />
        </Route>
        <Route path="login" element={<Login />} />
        <Route path="register" element={<SignUp />} />
      </Routes>
    </div>
  );
}

export default App;
