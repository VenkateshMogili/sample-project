import React from 'react';
import ReactDOM from 'react-dom/client';
import './index.css';
import App from './App';
import Netflix from './Netflix';

const root = ReactDOM.createRoot(document.getElementById('root'));
root.render(
  <React.StrictMode>
    <Netflix />
  </React.StrictMode>
);

//version <18
//ReactDOM.render(<App />, document.getElementById('root'));