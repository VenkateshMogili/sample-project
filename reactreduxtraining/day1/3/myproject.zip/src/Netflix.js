import './Netflix.css';
import React from 'react';

export default function Netflix() {
  return (
    <div className="BgImg">
      <div className='navbar'>
        <h1 className='logo'>NETFLIX</h1>
        <button className='btn'>Sign In</button>
      </div>
      <div className='content'>
        <h1>Unlimited Movies, TV <br /> Shows and more.</h1>
        <h2>Watch anywhere. Cancel anytime.</h2>
        <p>Ready to watch? Enter your email.</p>
        <input type="email" placeholder='Email Address' />
        <button className='getStarted'>Get Started &gt;</button>
      </div>
    </div>
  )
}
