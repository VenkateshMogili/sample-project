import "./App.css";
import image1 from "./images/movie1.png";
import image2 from "./images/movie2.png";
import image3 from "./images/movie3.png";
import image4 from "./images/movie4.png";

function App() {
	// let a = "12345";
	// let user = { name: "venkatesh" };
	return (
		<div className="App">
			<header className="App-header">
				<h1>Movie World!</h1>
				<div>
					<img src={image1} alt="movie1" style={{ width: 150, height: 250 }} />
					<img src={image2} alt="movie2" style={{ width: 150, height: 250 }} />
					<img src={image3} alt="movie3" style={{ width: 150, height: 250 }} />
					<img src={image4} alt="movie4" style={{ width: 150, height: 250 }} />
					<br />
					<img
						src="images/movie4.png"
						alt="movie5"
						style={{
							width: 150,
							height: 250,
							position: "relative",
							top: "-7px",
						}}
					/>
					<img
						src="images/movie3.png"
						alt="movie6"
						style={{
							width: 150,
							height: 250,
							position: "relative",
							top: "-7px",
						}}
					/>
					<img
						src="images/movie2.png"
						alt="movie7"
						style={{
							width: 150,
							height: 250,
							position: "relative",
							top: "-7px",
						}}
					/>
					<img
						src="images/movie1.png"
						alt="movie8"
						style={{
							width: 150,
							height: 250,
							position: "relative",
							top: "-7px",
						}}
					/>
				</div>
			</header>
		</div>
	);
}

export default App;
