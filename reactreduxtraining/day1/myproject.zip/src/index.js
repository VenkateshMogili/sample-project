import React from "react";
import ReactDOM from "react-dom";
import "./index.css";
// import App from "./App";
import StaticReact from "./StaticReact";

// 1st Task: Uncomment below line and comment last line to see output for 1st task
ReactDOM.render(<StaticReact />, document.getElementById("root"));

// 2nd Task: Uncomment below line and 4th line and comment above line to see output for 2nd task.
// ReactDOM.render(<App />, document.getElementById("root"));
