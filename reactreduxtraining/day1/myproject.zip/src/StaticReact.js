import "./App.css";

function StaticReact() {
	return (
		<div className="App">
			<header className="App-header">
				<div style={{ backgroundColor: "#2c2c2c", padding: 20 }}>
					<h1 style={{ color: "aqua" }}>React</h1>
					<p>A JavaScript library forbuilding user interfaces</p>
					<button style={{ padding: 10, border: 0, backgroundColor: "aqua" }}>Get Started</button>
					&nbsp;&nbsp;&nbsp;&nbsp;
					<a href="/#" style={{ textDecoration: "none", fontSize: 14 }}>
						Take the Tutorial &gt;{" "}
					</a>
				</div>
				<div className="block-2">
					<div style={{ margin: 40, padding: 40, border: "2px solid white" }}>
						<h2>Declarative</h2>
						<p>Sample Text</p>
					</div>
					<div style={{ margin: 40, padding: 40, border: "2px solid white" }}>
						<h2>Component-Base</h2>
						<p>Sample Text</p>
					</div>
					<div style={{ margin: 40, padding: 40, border: "2px solid white" }}>
						<h2>Learn once, Write Anywhere</h2>
						<p>Sample Text</p>
					</div>
				</div>
			</header>
		</div>
	);
}

export default StaticReact;
