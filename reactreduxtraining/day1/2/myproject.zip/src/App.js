import React from 'react';
import logo from './logo.svg';
import './App.css';

function App() {
  let button = <button>Click here</button>
  let button2 = React.createElement('button', null, 'Click here');
  return (
    <div className="App App2">
      <header className="App-header" style={{fontSize:200}}>
        <h1>Hello World!</h1>
        {button}
        {button}
        {button}
        {button}
        {button2}
      </header>
    </div>
  );
}

export default App;
