export const {
  initialStateContacts,
  getAllContactsAsyncRequest,
  getAllContactsAsyncSuccess,
  getAllContactsAsyncFail,
} = require("../actions/contacts");

export const contactsReducer = (state = initialStateContacts, action) => {
  switch (action.type) {
    case "GET_ALL_CONTACTS":
      return {...state};
    case "ADD_CONTACT": {
      let contacts = [...state.contacts];
      let lastId =
        contacts.length > 0 && contacts[contacts.length - 1].id ? parseInt(contacts[contacts.length - 1].id) + 1 : 1;
      let contact = action.contact;
      contact.id = lastId;
      contacts.push(contact);
      return {...state, contacts};
    }
    case "GET_SINGLE_CONTACT": {
      let contacts = [...state.contacts];
      return {...state, contact: contacts.filter((contact) => contact.id === action.id)[0], isEdit: true};
    }
    case "EDIT_CONTACT": {
      let contacts = [...state.contacts];
      const findIndex = contacts.findIndex((contact) => contact.id === action.id);
      contacts[findIndex] = action.contact;
      return {...state, contacts};
    }
    case "DELETE_CONTACT": {
      let contacts = [...state.contacts];
      let getIndex = contacts.findIndex((singleContact) => singleContact.id === action.id);
      contacts.splice(getIndex, 1);
      return {...state, contacts};
    }

    case "GET_ALL_CONTACTS_ASYNC_REQUEST":
      return {...state, loading: true};
    case "GET_ALL_CONTACTS_ASYNC_SUCCESS":
      return {...state, loading: false, data: action.payload};
    case "GET_ALL_CONTACTS_ASYNC_FAIL":
      return {...state, loading: false, error: action.payload};
    default:
      return state;
  }
};

export function getAllUsers() {
  return function(dispatch) {
    dispatch(getAllContactsAsyncRequest());
    fetch("https://jsonplaceholder.typicode.com/users")
      .then((res) => res.json())
      .then((result) => {
        dispatch(getAllContactsAsyncSuccess(result));
      })
      .catch((error) => {
        dispatch(getAllContactsAsyncFail(error.message));
      });
  };
}
