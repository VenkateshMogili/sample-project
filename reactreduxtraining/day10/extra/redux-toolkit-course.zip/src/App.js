import React from 'react'
import "./App.css"
import Counter from './components/Counter'
import Users from './components/Users'

export default function App() {
  return (
    <div className='App'>
      <h1>Redux Toolkit Crash Course!</h1>
      {/*<Counter />*/}
      <Users />
    </div>
  )
}