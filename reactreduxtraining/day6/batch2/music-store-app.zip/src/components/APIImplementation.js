import React, {useEffect, useState} from 'react';
import axios from 'axios';
const requestData = new Request('users.json');
const requestData2 = new Request('sample.txt');

export default function APIImplementation() {
  const [contacts, setContacts] = useState([{firstName: 'venkatesh', lastName: 'vivek'}]);
  const [singleContact, setSingleContact] = useState({});
  // const commonAPI = (url, method, body) => {
  //   if (method == 'GET' || method == 'DELETE') {
  //     axios[method](url).then((response) => {
  //       return response.data;
  //     });
  //   } else {
  //     axios
  //       [method](url, JSON.stringify(body), {
  //         headers: {
  //           'content-type': 'application/json',
  //         },
  //       })
  //       .then((response) => {
  //         return response.data;
  //       });
  //   }
  // };
  // useEffect(
  //   () => {
  //     // fetch(requestData).then((response) => response.json()).then((data) => console.log(data));
  //     // fetch(requestData2).then((response) => response.text()).then((data) => console.log(data));
  //     // fetch('http://localhost:3000/api/getAllContacts')
  //     //   .then((response) => response.json())
  //     //   .then((data) => console.log(data));
  //   },
  //   [contacts],
  // );
  const getAllContacts = () => {
    // fetch('http://localhost:3000/api/getAllContacts').then((response) => response.json()).then((data) => {
    //   console.log(data);
    //   setContacts(data.data);
    // });
    axios.get('http://localhost:3000/api/getAllContacts').then((response) => {
      // console.log(response.data);
      setContacts(response.data.data);
    });
  };
  const getSingleContact = (id) => {
    // fetch('http://localhost:3000/api/getContactById/' + id).then((response) => response.json()).then((data) => {
    //   console.log(data);
    //   setSingleContact(data.data[0]);
    // });
    axios.get('http://localhost:3000/api/getContactById/' + id).then((response) => {
      console.log(response.data);
      setSingleContact(response.data.data[0]);
    });
  };
  const addContact = () => {
    let user = {firstName: 'Vivek', lastName: 'Mogili', email: 'vivek@gmail.com'};
    // fetch('http://localhost:3000/api/createContact', {
    //   method: 'POST',
    //   headers: {
    //     'content-type': 'application/json',
    //   },
    //   body: JSON.stringify(user),
    // })
    //   .then((response) => response.json())
    //   .then((data) => {
    //     console.log(data);
    //     if (data.success) {
    //       alert(data.message);
    //     } else {
    //       alert('Something went wrong');
    //     }
    //   });
    axios
      .post('http://localhost:3000/api/createContact', JSON.stringify(user), {
        headers: {
          'content-type': 'application/json',
        },
      })
      .then((response) => {
        console.log(response);
        if (response.data.success) {
          alert(response.data.message);
        } else {
          alert('Something went wrong');
        }
      });
  };
  const updateContact = (id) => {
    let user = {firstName: 'Vivek Venkatesh', lastName: 'Mogili', email: 'vivek@gmail.com'};
    // fetch('http://localhost:3000/api/updateContact/' + id, {
    //   method: 'PUT',
    //   headers: {
    //     'content-type': 'application/json',
    //   },
    //   body: JSON.stringify(user),
    // })
    //   .then((response) => response.json())
    //   .then((data) => {
    //     console.log(data);
    //     if (data.success) {
    //       alert(data.message);
    //     } else {
    //       alert('Something went wrong');
    //     }
    //   });
    axios
      .put('http://localhost:3000/api/updateContact/' + id, JSON.stringify(user), {
        headers: {
          'content-type': 'application/json',
        },
      })
      .then((response) => {
        console.log(response);
        if (response.data.success) {
          alert(response.data.message);
        } else {
          alert('Something went wrong');
        }
      });
  };
  const deleteContact = (id) => {
    // fetch('http://localhost:3000/api/deleteContact/' + id, {
    //   method: 'DELETE',
    // })
    //   .then((response) => response.json())
    //   .then((data) => {
    //     console.log(data);
    //     if (data.success) {
    //       alert(data.message);
    //     } else {
    //       alert('Something went wrong');
    //     }
    //   });
    axios.delete('http://localhost:3000/api/deleteContact/' + id).then((response) => {
      console.log(response);
      if (response.data.success) {
        alert(response.data.message);
      } else {
        alert('Something went wrong');
      }
    });
  };
  return (
    <div>
      <button onClick={() => getAllContacts()} className="btn btn-primary m-2">
        Get Contacts
      </button>
      <button className="btn btn-primary m-2">Get Single Contact</button>
      <button className="btn btn-primary m-2" onClick={() => addContact()}>
        Add Contact
      </button>
      <button className="btn btn-primary m-2">Update Contact</button>
      <button className="btn btn-primary m-2">Delete Contact</button>

      <div>
        {Object.keys(singleContact).length > 0 && (
          <React.Fragment>
            <h1>Selected User</h1>{' '}
            <p>
              {singleContact.email} {singleContact.phoneNumber}
            </p>
          </React.Fragment>
        )}
      </div>

      <div>
        {contacts.length > 0 &&
          contacts.map((contact, index) => (
            <div>
              <p key={index} onClick={() => getSingleContact(contact.id)}>
                {contact.firstName} {contact.lastName}
              </p>

              <button className="btn btn-primary m-2" onClick={() => updateContact(contact.id)}>
                Update Contact
              </button>
              <button className="btn btn-danger m-2" onClick={() => deleteContact(contact.id)}>
                Delete Contact
              </button>
            </div>
          ))}
      </div>
    </div>
  );
}
