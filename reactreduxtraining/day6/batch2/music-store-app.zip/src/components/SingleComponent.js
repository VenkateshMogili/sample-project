import React from 'react';
import {useLocation, useParams} from 'react-router-dom';
export default function SingleComponent() {
  // const {id,title} = useParams();
  let location = useLocation();
  let urlquery = new URLSearchParams(location.search);

  return (
    <div>
      <h1>
        {/* Single Product {id} title {title} */}
        Name {urlquery.get('name')}
        Age {urlquery.get('age')}
      </h1>
    </div>
  );
}
