import React from 'react';

export default function Header() {
  return (<div className='d-block'>
    <h1 className='heading'>Semi Dynamic E-Commerce Application</h1>
    <div className='d-flex justify-content-between align-items-center bg-navy'>
      <div>
        <i className='fa fa-phone text-white m-3' />
        <a href="!#" className='text-white text-decoration-none m-3'>Products</a>
      </div>
      <div className='m-3'>
        <button className='btn btn-outline-primary'><i className='fa fa-cart-plus' /> My Cart</button>
      </div>
    </div>
  </div>);
}
