import "./App.css";
import Header from "./Header";

function App() {
  const mobiles = [
    {
      icon: "https://i.gadgets360cdn.com/products/large/1556860999_635_google_pixel_3a.jpg",
      name: "Google Pixel - Black",
      price: "10",
    },
    {
      icon: "https://i.gadgets360cdn.com/products/large/1556860999_635_google_pixel_3a.jpg",
      name: "Samsung S7",
      price: "16",
    },
    {
      icon: "https://i.gadgets360cdn.com/products/large/1556860999_635_google_pixel_3a.jpg",
      name: "HTC 10 - Black",
      price: "8",
    },
    {
      icon: "https://i.gadgets360cdn.com/products/large/1556860999_635_google_pixel_3a.jpg",
      name: "HTC 10 - White",
      price: "18",
    },
    {
      icon: "https://i.gadgets360cdn.com/products/large/1556860999_635_google_pixel_3a.jpg",
      name: "Iphone 7",
      price: "30",
    },
    {
      icon: "https://i.gadgets360cdn.com/products/large/1556860999_635_google_pixel_3a.jpg",
      name: "Redmi Note 7",
      price: "11",
    },
    {
      icon: "https://i.gadgets360cdn.com/products/large/1556860999_635_google_pixel_3a.jpg",
      name: "Redmi Note 9",
      price: "10",
    },
    {
      icon: "https://i.gadgets360cdn.com/products/large/1556860999_635_google_pixel_3a.jpg",
      name: "Realme 7",
      price: "15",
    },
  ];

  return (
    <div className="App">
      <Header />
      <h1 className="products">Our Products</h1>
      <div className="products-list">
        {mobiles.length > 0 && mobiles.map((mobile) => (
          <div className="product" key={mobile.id}>
            <img src={mobile.icon} className="mobilepic" alt="mobilepic" />
            <div className="product-info">
              <p>{mobile.name}</p>
              <p>${mobile.price}</p>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}

export default App;
