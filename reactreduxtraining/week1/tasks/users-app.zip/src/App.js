import "./App.css";

function App() {
  const users = [
    { id: 1, username: "Admin", profile_pic: "https://cdn.pixabay.com/photo/2020/07/01/12/58/icon-5359553_1280.png", },
    { id: 2, username: "User", profile_pic: "https://cdn.pixabay.com/photo/2020/07/01/12/58/icon-5359553_1280.png", },
    { id: 3, username: "Customer", profile_pic: "https://cdn.pixabay.com/photo/2020/07/01/12/58/icon-5359553_1280.png", },
    { id: 4, username: "Hacker", profile_pic: "https://cdn.pixabay.com/photo/2020/07/01/12/58/icon-5359553_1280.png", }
  ];

  return (
    <div className="App">
      <h1>USERS</h1>
      <div className="users-list">
        {users.length > 0 && users.map((user) => (
          <div className="user" key={user.id}>
            <img src={user.profile_pic} className="profilepic" alt="profilepic" />
            <h2>{user.username}</h2>
          </div>
        ))}
      </div>
    </div>
  );
}

export default App;
