import React from 'react'
import '../assets/css/Header.css';

function Header() {
    return (
        <div>
            <header>
                <h1 className="header-text col-md-12 col-sm-12">Google</h1>
            </header>
        </div>
    )
}

export default Header
