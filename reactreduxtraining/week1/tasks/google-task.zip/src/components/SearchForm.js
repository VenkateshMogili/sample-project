import React, { useState } from 'react';
import '../assets/css/SearchForm.css';

function SearchForm() {
  const [userInput, setUserInput] = useState('');
  const [search, setSearch] = useState([]);
  const addShortcut = (e) => {
    e.preventDefault();
    addSearchValue();
  }
  const handleChange = (e) => {
    setUserInput(e.target.value)
  }
  const addSearchValue = () => {
    const copy = [...search, userInput];
    setSearch(copy);
    setUserInput("");
  }
  return (
    <>
      <div className="search-box">
        <i className="fa fa-search"></i>
        <input type="text" placeholder="Search Google or type a URL" value={userInput} onChange={handleChange} />
        <i className="fas fa-microphone"></i>
      </div>
      <div className="circle" onClick={addShortcut}></div>
      <h4 className="add-shortcut">Add shortcut</h4>
      <div>
        {
          search && search.map((item) => {
            return <p>{item}</p>
          })
        }
      </div>
    </>
  )
}

export default SearchForm
