import "./App.css";

function App() {
  const fruits = [{ id: 1, name: "Apple" }, { id: 2, name: "Banana" }, { id: 3, name: "Pineapple" }, { id: 4, name: "Grapes" }];
  return (
    <div className="App">
      <h1>Fruits</h1>
      <ul>
        {fruits.length > 0 && fruits.map((fruit) => (
          <li key={fruit.id}>{fruit.name}</li>
        ))}
      </ul>
    </div>
  );
}

export default App;
