import React from 'react';
import './App.css';
import Login from './components/Login';
import SignUp from './components/SignUp';
import { Routes, Route } from 'react-router-dom';
import Home from './components/Home';
import HomePage from './components/HomePage';
import Posts from './components/HomePage/Posts';
import Notifications from './components/Notifications';
import Connections from './components/Connections';
import Chat from './components/Chat';
import Jobs from './components/Jobs';

function App() {
  return (
    <div>
      <Routes>
        <Route path="dashboard" element={<Home />}>
          <Route path="home" element={<HomePage />} />
          <Route path="home" element={<HomePage />}>
            <Route path="posts" element={<Posts />} />
            <Route path="notifications" element={<Notifications />} />
            <Route path="network" element={<Connections />} />
            <Route path="messaging" element={<Chat />} />
            <Route path="jobs" element={<Jobs />} />
          </Route>
          <Route path="network" element={<h1>Hello</h1>} />
          <Route path="jobs" element={<h1>Hello</h1>} />
          <Route path="messaging" element={<h1>Hello</h1>} />
          <Route path="notifications" element={<h1>Hello</h1>} />
        </Route>
        <Route path="login" element={<Login />} />
        <Route path="register" element={<SignUp />} />
      </Routes>
    </div>
  );
}

export default App;
