import React, { useEffect, useState } from 'react'
import api from './api';

export default function Connections() {
  const [notifications, setNotifications] = useState([{ name: "" }]);
  useEffect(() => {
    let user = localStorage.getItem("user") !== null ? JSON.parse(localStorage.getItem("user")) : null;
    if (user !== null) {
      api("http://localhost:4000/users", "GET")
        .then(response => {
          console.log(response);
          setNotifications(response);
        })
    }
  }, [])
  return (
    <div className='d-flex flex-wrap'>
      {notifications.length > 0 && notifications.map((notification, index) => (
        <div className='col-md-3 text-center card m-4' key={index}>
          <div className='d-flex p-3 justify-content-center align-items-center'>
            <div>
              <i className='fa fa-times closeIcon' />
              <img src={notification.profilepic} alt="linkedin" className='logo m-2 userImage' />
              <div>
                <h4>Username</h4>
                <p>Software Engineer</p>
                <p><i className='fa fa-bank' /> Software Company</p>
                <button className='btn btn-outline-primary connectBtn'>Connect</button>
              </div>
            </div>
          </div>
        </div>
      ))}
    </div>
  )
}
