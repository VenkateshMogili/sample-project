import React from 'react'
import "./homepage.css";

export default function Recents() {
  return (
    <div className='p-3 bg-white border m-3 rounded'>
      <h4>Recents</h4>
      <p>
        <i className='fa fa-hashtag' /> ReactJS
      </p>
      <p>
        <i className='fa fa-hashtag' /> NodeJS
      </p>
      <p>
        <i className='fa fa-hashtag' /> NextJS
      </p>
    </div>
  )
}
