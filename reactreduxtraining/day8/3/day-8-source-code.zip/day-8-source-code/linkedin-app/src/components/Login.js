import React, { useState } from 'react';
import "../styles/SignUp.css";
import api from './api';
import { useNavigate } from 'react-router-dom'

export default function Login() {
  const [showPassword, setShowPassword] = useState(false)
  const [userDetails, setUserDetails] = useState({
    email: "",
    password: "",
  });
  const handleChange = ({ target: { name, value } }) => {
    let updatedDetails = { ...userDetails };
    updatedDetails[name] = value;
    setUserDetails(updatedDetails)
  }
  const navigate = useNavigate();
  const handleSubmit = (e) => {
    e.preventDefault();
    console.log(userDetails);
    api("http://localhost:4000/users", "GET", {}).then(response => {
      let allUsers = response;
      let filteredUser = allUsers.filter(user => user.email === userDetails.email && user.password === userDetails.password);
      if (filteredUser.length === 1) {
        alert("Login Successful!")
        localStorage.setItem("user", JSON.stringify({ id: filteredUser[0].id, email: filteredUser[0].email, name: filteredUser[0].fullname }));
        navigate("/dashboard/home/posts");
      } else {
        alert("Wrong username/password")
      }
    })
  }
  return (
    <div className='container mt-5 pt-5'>
      <div className='container mt-5 pt-5'>
        <div className='text-center'>
          <h1>Sign In</h1>
          <p>Stay updated on your professional world</p>
        </div>
        <div className='d-flex justify-content-center '>
          <form onSubmit={handleSubmit} className="card p-3 bg-white col-md-4">
            <InputElement
              label="Email"
              placeholder="Enter your email address"
              id="email"
              value={userDetails.email}
              handleChange={handleChange}
              type="email"
            />
            <div className='relative'>
              <InputElement
                label="Password (6 or more characters)"
                placeholder="Enter your password"
                id="password"
                value={userDetails.password}
                handleChange={handleChange}
                type={showPassword ? "text" : "password"}
                min={6}
              />
              <button className='show-btn' type="button" onClick={() => setShowPassword(!showPassword)}>{showPassword ? "Hide" : "Show"}</button>
            </div>
            <button type="submit" className='btn btn-primary form-control mt-2'>Sign In</button>
          </form>
        </div>
      </div>
    </div>
  )
}
function InputElement({ label, placeholder, id, value, handleChange, type }) {
  return (
    <div className='input_element'>
      <label htmlFor={id} className='label'>{label}</label>
      <input type={type} value={value} onChange={handleChange} id={id} name={id} className='form-control input_style' placeholder={placeholder} />
    </div>
  )
}
