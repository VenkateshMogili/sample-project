import React, { useState } from 'react'
import { NavLink, Link, useNavigate } from 'react-router-dom';
import { useDispatch } from 'react-redux'
import { setSearchText2 } from '../features/counterSlice';

export default function SideNav() {
  let navigate = useNavigate();
  const [searchText, setSearchText] = useState("");
  const dispatch = useDispatch();
  return (
    <div className='non-printable  bg-white border sticky-top'>
      <div className="container d-flex justify-content-between align-items-start text-white ">
        <div className='d-flex m-2'>
          <a href="/" className="d-flex align-items-center mb-3 mb-md-0 me-md-auto text-white text-decoration-none">
            <img src="https://play-lh.googleusercontent.com/kMofEFLjobZy_bCuaiDogzBcUT-dz3BBbOrIEjJ-hqOabjK8ieuevGe6wlTD15QzOqw" alt="linkedin" className='logo' />
          </a>
          <div className='bg-light m-2 p-1 rounded'>
            <i className='fa fa-search text-dark' />
            <input type="text" placeholder='Search' value={searchText} onChange={(e) => {
              setSearchText(e.target.value);
              dispatch(setSearchText2(e.target.value))
            }
            } className='border-0 outline-none' />
          </div>
        </div>
        <ul className="col-md-9 nav nav-pills flex-row mb-auto">
          <li className="nav-item text-center">
            <NavLink to="/dashboard/home/posts" className={({ isActive }) => isActive ? "nav-link active" : "nav-link text-dark"} aria-current="page">
              <i className='fa fa-home' />
              <p>Home</p>
            </NavLink>
          </li>
          <li className="nav-item text-center">
            <NavLink to="/dashboard/home/network" className={({ isActive }) => isActive ? "nav-link active" : "nav-link text-dark"} aria-current="page">
              <i className='fa fa-user' />
              <p>My Network</p>
            </NavLink>
          </li>
          <li className="nav-item text-center">
            <NavLink to="/dashboard/home/jobs" className={({ isActive }) => isActive ? "nav-link active" : "nav-link text-dark"} aria-current="page">
              <i className='fa fa-suitcase' />
              <p>Jobs</p>
            </NavLink>
          </li>
          <li className="nav-item text-center">
            <NavLink to="/dashboard/home/messaging" className={({ isActive }) => isActive ? "nav-link active" : "nav-link text-dark"} aria-current="page">
              <i className='fa fa-comments' />
              <p>Messaging</p>
            </NavLink>
          </li>
          <li className="nav-item text-center">
            <NavLink to="/dashboard/home/notifications" className={({ isActive }) => isActive ? "nav-link active" : "nav-link text-dark"} aria-current="page">
              <i className='fa fa-bell' />
              <p>Notifications</p>
            </NavLink>
          </li>
          <li className="nav-item text-center">
            <div className="dropdown m-3">
              <a href="#" className="mt-2 d-flex align-items-center text-dark text-decoration-none dropdown-toggle flex-column" id="dropdownUser1" data-bs-toggle="dropdown" aria-expanded="false">
                <img src="https://github.com/mdo.png" alt="" width="32" height="32" className="rounded-circle me-2" />
                <p>Me <i className='fa fa-angle-down' /></p>
              </a>
              <ul className="dropdown-menu dropdown-menu-dark text-small shadow" aria-labelledby="dropdownUser1">
                {/*<li><Link className="dropdown-item" to="/dashboard/profile">Profile</Link></li>*/}
                <li><button className="dropdown-item" onClick={() => {
                  localStorage.removeItem("user");
                  navigate("/login");
                }
                }>Sign out</button></li>
              </ul>
            </div>
          </li>
        </ul>
      </div>
    </div>
  )
}
