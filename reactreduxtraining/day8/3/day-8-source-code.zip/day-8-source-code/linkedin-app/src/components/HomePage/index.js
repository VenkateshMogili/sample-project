import React from 'react'
import Profile from './Profile'
import Recents from './Recents'
import News from './News'
import Promoted from './Promoted'
import Posts from './Posts'
import { Outlet } from 'react-router-dom'

export default function HomePage() {
  return (
    <div className='container d-flex justify-content-evenly'>
      <div className='col-md-3'>
        <Profile />
        <Recents />
      </div>
      {/* posts */}
      <div className='col-md-8'>
        {/*<Posts />*/}
        <Outlet />
      </div>
      {/* news */}
      <div className='col-md-3'>
        <News />
        <Promoted />
      </div>
    </div>
  )
}
