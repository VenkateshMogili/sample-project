import React, { useEffect, useState } from 'react'
import api from './api';

export default function Notifications() {
  const [notifications, setNotifications] = useState([{ name: "" }]);
  useEffect(() => {
    let user = localStorage.getItem("user") !== null ? JSON.parse(localStorage.getItem("user")) : null;
    if (user !== null) {
      api("http://localhost:4000/notifications", "GET")
        .then(response => {
          console.log(response);
          setNotifications(response);
        })
    }
  }, [])
  return (
    <div>
      {notifications.length > 0 && notifications.map((notification, index) => (
        <div className='card p-3 m-3' key={index}>
          <div className=' d-flex justify-content-between align-items-center'>
            <div className='d-flex'>
              <img src={notification.image} alt="linkedin" className='logo m-2' />
              <div>
                <h4>Username</h4>
                <small>{notification.notification}</small><br />
                <small>{notification.createdAt}</small>
              </div>
            </div>
            <div className='align-self-start'>
              <i className='fa fa-ellipsis-h' />
            </div>
          </div>
        </div>
      ))}
    </div>
  )
}
