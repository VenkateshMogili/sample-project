import React from 'react'
import "./homepage.css";

export default function News() {
  return (
    <div className='p-3 bg-white border m-3 rounded'>
      <h4>LinkedIn News</h4>
      <p>
        <i className='fa fa-dot-circle-o' /> Festive cheer to fuel hiring<br />
        <small>4d ago. 408 readers</small>
      </p>
      <p>
        <i className='fa fa-dot-circle-o' /> Festive cheer to fuel hiring<br />
        <small>4d ago. 408 readers</small>
      </p>
      <p>
        <i className='fa fa-dot-circle-o' /> Festive cheer to fuel hiring<br />
        <small>4d ago. 408 readers</small>
      </p>
      <p>
        <i className='fa fa-dot-circle-o' /> Festive cheer to fuel hiring<br />
        <small>4d ago. 408 readers</small>
      </p>
      <p>
        <i className='fa fa-dot-circle-o' /> Festive cheer to fuel hiring<br />
        <small>4d ago. 408 readers</small>
      </p>
      <p>
        <i className='fa fa-dot-circle-o' /> Festive cheer to fuel hiring<br />
        <small>4d ago. 408 readers</small>
      </p>
    </div>
  )
}
