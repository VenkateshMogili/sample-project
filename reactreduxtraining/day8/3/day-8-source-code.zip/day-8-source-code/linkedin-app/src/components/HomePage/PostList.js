import React, { useEffect, useState } from 'react'

export default function PostList({ post, index }) {
  const [show, setShow] = useState(false);
  return (
    <div className='card p-3 m-3' key={index}>
      <div className=' d-flex justify-content-between align-items-center'>
        <div className='d-flex'>
          <img src="https://play-lh.googleusercontent.com/kMofEFLjobZy_bCuaiDogzBcUT-dz3BBbOrIEjJ-hqOabjK8ieuevGe6wlTD15QzOqw" alt="linkedin" className='logo m-2' />
          <div>
            <h4>Username</h4>
            <small>Software Developer</small><br />
            <small>6d</small>
          </div>
        </div>
        <div className='align-self-start'>
          <i className='fa fa-ellipsis-h' />
        </div>
      </div>
      <p>{post.text.length > 200 && !show ? post.text.slice(0, 200) + "..." : post.text}
        {post.text.length > 200 && <button className='bg-white border-0' onClick={() => setShow(!show)}>See {show ? "less" : "more"}</button>}
      </p>
      {post.image && <div className='text-center'>
        <img src="https://media-exp1.licdn.com/dms/image/C4D22AQEyZw-DS5DpQw/feedshare-shrink_800/0/1657725933261?e=1661385600&v=beta&t=Vv5vIRjG7beUh5PiHkFLXVde8zYSrfoVdtn4Kh5zBJU" alt="post image" className='w-100 h-30' />
      </div>}
    </div>
  )
}
