import React, { useEffect, useState } from 'react'
import { useSelector } from 'react-redux';
import { Outlet } from 'react-router-dom';
import api from '../api';
import PostForm from './PostForm'
import PostList from './PostList'

export default function Posts() {
  const [isChanged, setIsChanged] = useState(false);
  let [postList, setPostList] = useState([]);
  const searchText = useSelector(store => store.counter.searchText2);
  useEffect(() => {
    let user = localStorage.getItem("user") !== null ? JSON.parse(localStorage.getItem("user")) : null;
    if (user !== null) {
      api("http://localhost:4000/posts?userId=" + user.id + "&_sort=id&_order=desc", "GET")
        .then(response => {
          console.log(response);
          setPostList(response);
        })
    }
  }, [isChanged])
  return (
    <div className='col-md-12 mt-3'>
      {/* post form */}
      <PostForm isChanged={isChanged} setIsChanged={setIsChanged} />
      <hr />
      {/* post list */}
      {postList.length > 0 && postList.filter(item => item.text.toLowerCase().indexOf(searchText.toLowerCase()) > -1).map((post, index) => (
        <PostList post={post} index={index} />
      ))}
    </div>
  )
}
