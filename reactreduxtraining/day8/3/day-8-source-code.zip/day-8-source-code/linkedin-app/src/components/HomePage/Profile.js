import React from 'react'
import "./homepage.css";

export default function Profile() {
  return (
    <div className='p-3 bg-white border m-3 rounded'>
      <div className='text-center'>
        <img src="https://cdn-icons-png.flaticon.com/512/149/149071.png" className='user-icon' />
      </div>
      <h4 className='text-center '>Venkatesh Mogili</h4>
      <p className='text-center '>Company Name</p>
      <div className='d-flex justify-content-between'>
        <p>Who's viewed your profile</p>
        <p>171</p>
      </div>
      <div className='d-flex justify-content-between'>
        <p>Impressions Of your posts</p>
        <p>547</p>
      </div>
      <hr />
      <p>Access exclusive tools &amp; insights</p>
      <p><i className='fa fa-star' /> <b>Try Premium for free</b></p>
      <hr />
      <div>
        <i className='fa fa-bookmark' /> My Items
      </div>
    </div>
  )
}
