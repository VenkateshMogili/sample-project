import React, { useState } from 'react'
import "./homepage.css";
import api from '../api';

export default function PostForm({ isChanged, setIsChanged }) {
  const [text, setText] = useState("");
  const handleSubmit = (e) => {
    e.preventDefault();
    let headers = { "content-type": "application/json" };
    let user = localStorage.getItem("user") !== null ? JSON.parse(localStorage.getItem("user")) : null;
    if (user !== null) {
      let body = { userId: user.id, text }
      api("http://localhost:4000/posts", "POST", headers, body)
        .then(response => {
          console.log(response);
          alert("Post successful!");
          setText("");
          setIsChanged(true);
        })
    }
  }
  return (
    <div className='card p-3 m-3'>
      <div className='d-flex  align-items-center'>
        <img src="https://play-lh.googleusercontent.com/kMofEFLjobZy_bCuaiDogzBcUT-dz3BBbOrIEjJ-hqOabjK8ieuevGe6wlTD15QzOqw" alt="linkedin" className='logo m-2' />
        <form className='w-100' onSubmit={handleSubmit}>
          <input type="text" placeholder='Start a post' value={text} onChange={(e) => setText(e.target.value)} className='circle w-100 border-light' />
        </form>
      </div>
      <div className='d-flex justify-content-center m-3'>
        <div className='col-md-3 text-center'>
          <i className='fa fa-photo text-primary' /> Photo
        </div>
        <div className='col-md-3 text-center'>
          <i className='fa fa-play-circle text-success' /> Video
        </div>
        <div className='col-md-3 text-center'>
          <i className='fa fa-calendar text-warning' /> Event
        </div>
        <div className='col-md-3 text-center'>
          <i className='fa fa-list text-danger' /> Write Article
        </div>
      </div>
    </div>
  )
}