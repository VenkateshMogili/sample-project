import React from 'react'
import "./homepage.css";

export default function News() {
  return (
    <div className='p-3 bg-white border m-3 rounded'>
      <h4>Promoted</h4>
      <div className='d-flex'>
        <img src="https://play-lh.googleusercontent.com/kMofEFLjobZy_bCuaiDogzBcUT-dz3BBbOrIEjJ-hqOabjK8ieuevGe6wlTD15QzOqw" alt="linkedin" className='logo m-2' />
        <div>
          <span> Register for event</span>
          <small>AWS Reinvent is the worlds premier cloud.</small>
        </div>
      </div>
      <hr />
      <div className='d-flex'>
        <img src="https://play-lh.googleusercontent.com/kMofEFLjobZy_bCuaiDogzBcUT-dz3BBbOrIEjJ-hqOabjK8ieuevGe6wlTD15QzOqw" alt="linkedin" className='logo m-2' />
        <div>
          <span> Register for event</span>
          <small>AWS Reinvent is the worlds premier cloud.</small>
        </div>
      </div>
      <hr />
      <div className='d-flex'>
        <img src="https://play-lh.googleusercontent.com/kMofEFLjobZy_bCuaiDogzBcUT-dz3BBbOrIEjJ-hqOabjK8ieuevGe6wlTD15QzOqw" alt="linkedin" className='logo m-2' />
        <div>
          <span> Register for event</span>
          <small>AWS Reinvent is the worlds premier cloud.</small>
        </div>
      </div>
    </div>
  )
}
