import { createSlice } from '@reduxjs/toolkit';

const initialState = {
  cart: [
  ],
  searchText2: ""
};

export const counterSlice = createSlice({
  name: 'counter',
  initialState,
  reducers: {
    setSearchText2: (state, action) => {
      state.searchText2 = action.payload;
    },
    increment: (state, action) => {
      let items = [...state.cart];
      let index = items.findIndex(item => item.productId === action.payload.productId);
      items[index].quantity += 1;
      state.cart = items;
    },
    decrement: (state, action) => {
      let items = [...state.cart];
      let index = items.findIndex(item => item.productId === action.payload.productId);
      items[index].quantity -= 1;
      state.cart = items;
    },
    addItem: (state, action) => {
      let items = [...state.cart];
      if (items.findIndex((item) => item.productId === action.payload.productId) == -1) {
        items.push({ ...action.payload, quantity: 1 })
        state.cart = items;
      }
    },
  }
});

export const { increment, decrement, addItem, setSearchText2 } = counterSlice.actions;

export default counterSlice.reducer;
