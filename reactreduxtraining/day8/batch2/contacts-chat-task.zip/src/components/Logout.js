import React, {forwardRef, useImperativeHandle} from 'react';
import {useContactData} from './ContextComponent';

export const Logout = forwardRef((props, ref) => {
  let values = useContactData();
  // useimperativehandle
  useImperativeHandle(ref, () => ({
    logoutUser: () => {
      console.log('User Logged Out');
      console.log('in sub child', values);
    },
  }));
  return (
    <div>
      <button {...props} className="btn btn-danger">
        Logout
      </button>
    </div>
  );
});
