import React, {useState, useEffect, useReducer, useDebugValue} from 'react';
const initialState = {
  data: [],
  error: '',
  loading: false,
};

const apiReducer = (state, action) => {
  switch (action.type) {
    case 'FETCH_DATA_REQUEST':
      return {...state, loading: true};
    case 'FETCH_DATA_SUCCESS':
      return {...state, loading: false, data: action.payload};
    case 'FETCH_DATA_FAIL':
      return {...state, loading: false, error: action.payload};
    default:
      return state;
  }
};

export const useFetch = (url) => {
  const [data, setData] = useState([]);
  const [state, dispatch] = useReducer(apiReducer, initialState);
  useDebugValue(state);
  useEffect(() => {
    dispatch({type: 'FETCH_DATA_REQUEST'});
    fetch(url)
      .then((res) => res.json())
      .then((data) => {
        setData(data);
        dispatch({type: 'FETCH_DATA_SUCCESS', payload: data});
      })
      .catch((error) => {
        dispatch({type: 'FETCH_DATA_FAIL', payload: error.message});
      });
  }, []);
  return state;
};
