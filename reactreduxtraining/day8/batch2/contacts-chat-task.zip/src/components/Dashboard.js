import React, {useMemo, useState, useEffect, useCallback, useRef, useLayoutEffect} from 'react';
import {useContactData} from './ContextComponent';
import {Logout} from './Logout';
import {useFetch} from './useFetch';

// 1000000000
function sum(a, b) {
  for (let i = 0; i < 1000000000; i++) {
    // do something
  }
  return parseInt(a) + parseInt(b);
}

export default function Dashboard() {
  const todos = useFetch('https://jsonplaceholder.typicode.com/todos');
  console.log('todos in child', todos);
  const [a, setA] = useState(10);
  const [b, setB] = useState(20);
  const [sumTotal, setSum] = useState(0);
  const [username, setUsername] = useState('');
  const [loading, setLoading] = useState(true);
  const values = useContactData();
  console.log(values);
  // const sumValue = sum(a, b);
  // const sumValue = useMemo(
  //   () => {
  //     return sum(a, b);
  //   },
  //   [a, b],
  // );
  const makeSum = useCallback(
    (c) => {
      return parseInt(a) + parseInt(c);
    },
    [a, b],
  );
  useEffect(() => {
    setTimeout(() => {
      setLoading(false);
    }, 3000);
  }, []);
  const logoutRef = useRef();
  const handleClick = () => {
    console.log('clicked');
    logoutRef.current.logoutUser();
  };
  useEffect(() => {
    console.log('Effect1');
  }, []);
  useEffect(() => {
    console.log('Effect2');
  }, []);
  // useLayoutEffect(() => {
  //   console.log('Layout Effect');
  // }, []);
  return (
    <div className="container mt-5">
      {loading ? <h1>Loading...</h1> : <Logout onClick={handleClick} ref={logoutRef} />}
      {/* <h3>Sum: {sumValue}</h3> */}
      <h3>Sum2: {sumTotal}</h3>
      {/* <h4>Name: {data.name}</h4> */}
      <input type="number" value={a} onChange={(e) => setA(e.target.value)} />
      <br />
      <input type="text" placeholder="Username" value={username} onChange={(e) => setUsername(e.target.value)} />
      <br />
      <br />
      <button className="btn btn-primary" onClick={() => setSum(makeSum(10))}>
        Sum
      </button>
    </div>
  );
}
