import React, {createContext, useContext} from 'react';
import Child from './Child';
import Dashboard from './Dashboard';
const ContactsContext = createContext();
export const useContactData = () => {
  return useContext(ContactsContext);
};

export default function ContextComponent() {
  return (
    <div>
      <ContactsContext.Provider value={{name: 'Venkatesh'}}>
        <Dashboard />
        <Child />
      </ContactsContext.Provider>
    </div>
  );
}
