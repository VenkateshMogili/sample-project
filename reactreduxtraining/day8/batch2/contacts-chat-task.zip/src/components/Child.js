import React from 'react';
import {useContactData} from './ContextComponent';
import {useFetch} from './useFetch';

export default function Child() {
  let values = useContactData();
  console.log(values);
  const contacts = useFetch('https://jsonplaceholder.typicode.com/users');
  console.log('contacts in child', contacts);
  return (
    <div>
      <h1>Child</h1>
    </div>
  );
}
