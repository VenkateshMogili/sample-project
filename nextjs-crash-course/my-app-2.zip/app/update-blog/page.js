export default function UpdateBlog() {
  return (
    <h1>Update Blog Application</h1>
  );
}
