"use client";

import React, { useState } from 'react'

export default function CreateTask() {
  const [title, setTitle] = useState('');

  return (
    <div>
      <h1>Create Task</h1>
      <form>
        <input
          type="text"
          placeholder='Title'
          value={title}
          onChange={(e) => setTitle(e.target.value)}
        />
      </form>
    </div>
  )
}
