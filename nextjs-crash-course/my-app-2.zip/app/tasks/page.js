export default async function Tasks() {
  console.log("Venkatesh");
  const response = await fetch("https://jsonplaceholder.typicode.com/todos");
  const data = await response.json();
  console.log("data",data);
  return (
    <div>
      <h1>Tasks</h1>
      {data.map((task)=>(
        <p key={task.id}>{task.id} - {task.title}</p>
      ))}
    </div>
  )
}
