export default function CreateBlog() {
  return (
    <h1>Create Blog Application</h1>
  );
}
