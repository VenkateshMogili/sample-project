import BlogCardDetails from "@/app/components/BlogCardDetails";
import Link from "next/link";

export default async function SingleBlog({params}) {
  const paramsData = await params;
  const blogId = paramsData.blogId;
  const response = await fetch("https://jsonplaceholder.typicode.com/posts/"+blogId);
  const blog = await response.json();

  return (
      <BlogCardDetails blog={blog}/>
  );
}
