import BlogCard from "../components/BlogCard";

export default async function Blog() {
  const response = await fetch("https://jsonplaceholder.typicode.com/posts");
  const blogs = await response.json();

  return (
    <div>
      <div className="blog-header">
        <p className="blog-label">Our Blog</p>
        <h1 className="blog-heading">Resources and Insights</h1>
        <p className="blog-sub-heading">The latest industry news, interviews, technologies, and resources.</p>
        <input type="search" placeholder="Search..." className="blog-search" />
      </div>

      <div className="blog-cards">
        {blogs.map((blog) => (
          <BlogCard key={blog.id} blog={blog} />
        ))}
      </div>
    </div>
  );
}
