import Link from "next/link";

export default function BlogCard({ blog }) {
  return (
    <Link href={"/blog/"+blog.id}>
    <div className="blog-card">
      <img src="/image.png" alt="Blog Post" className="blog-banner" />
      <p className="label">Design</p>
      <h2 className="heading">{blog.title.substring(0, 40)}{blog.title.length > 40 ? '...' : ''}</h2>
      <p className="description">{blog.body.substring(0, 100)}{blog.body.length > 100 ? '...' : ''}</p>

      <div className="blog-footer">
        <img src="/user.png" alt="Blog Post" className="blog-author" />
        <div>
          <p>Venkatesh Mogili</p>
          <p>20 Jan 2025</p>
        </div>
      </div>
    </div>
    </Link>
  )
}
