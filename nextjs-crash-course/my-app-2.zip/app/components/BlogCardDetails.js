import Link from "next/link";

export default function BlogCardDetails({ blog }) {
  return (
    <div className="blog-card blog-details">
      <Link href="/blog" className="link">Go Back</Link>
      <div className="header">
      <img src="/image.png" alt="Blog Post" className="blog-banner" />
      <div className="blog-details-header">
      <p className="label">Design</p>
      <div className="blog-footer">
        <img src="/user.png" alt="Blog Post" className="blog-author" />
        <div>
          <p>Venkatesh Mogili</p>
          <p>20 Jan 2025</p>
        </div>
      </div>
      </div>
      </div>

      <h2 className="heading">{blog.title}</h2>
      <p className="description">{blog.body} Lorem ipsum dolor sit amet consectetur adipisicing elit. Perferendis officiis aut, recusandae ipsam tenetur dicta modi ipsa distinctio cumque iste voluptates inventore voluptate numquam delectus. Deleniti nulla autem ab explicabo. Lorem ipsum dolor sit amet consectetur adipisicing elit. Perferendis officiis aut, recusandae ipsam tenetur dicta modi ipsa distinctio cumque iste voluptates inventore voluptate numquam delectus. Deleniti nulla autem ab explicabo. Lorem ipsum dolor sit amet consectetur adipisicing elit. Perferendis officiis aut, recusandae ipsam tenetur dicta modi ipsa distinctio cumque iste voluptates inventore voluptate numquam delectus. Deleniti nulla autem ab explicabo. Lorem ipsum dolor sit amet consectetur adipisicing elit. Perferendis officiis aut, recusandae ipsam tenetur dicta modi ipsa distinctio cumque iste voluptates inventore voluptate numquam delectus. Deleniti nulla autem ab explicabo. Lorem ipsum dolor sit amet consectetur adipisicing elit. Perferendis officiis aut, recusandae ipsam tenetur dicta modi ipsa distinctio cumque iste voluptates inventore voluptate numquam delectus. Deleniti nulla autem ab explicabo. Lorem ipsum dolor sit amet consectetur adipisicing elit. Perferendis officiis aut, recusandae ipsam tenetur dicta modi ipsa distinctio cumque iste voluptates inventore voluptate numquam delectus. Deleniti nulla autem ab explicabo. Lorem ipsum dolor sit amet consectetur adipisicing elit. Perferendis officiis aut, recusandae ipsam tenetur dicta modi ipsa distinctio cumque iste voluptates inventore voluptate numquam delectus. Deleniti nulla autem ab explicabo.Lorem ipsum dolor sit amet consectetur adipisicing elit. Perferendis officiis aut, recusandae ipsam tenetur dicta modi ipsa distinctio cumque iste voluptates inventore voluptate numquam delectus. Deleniti nulla autem ab explicabo. Lorem ipsum dolor sit amet consectetur adipisicing elit. Perferendis officiis aut, recusandae ipsam tenetur dicta modi ipsa distinctio cumque iste voluptates inventore voluptate numquam delectus. Deleniti nulla autem ab explicabo.</p>
    </div>
  )
}
