## Summary:
#### What is Next.js?
#### How to use Next.js?
#### How to create Next.js Project?
#### Hello World!
#### Basic Routing
#### Dynamic Routing
#### Simple Blog Application Part-1 with basic styles.

## Next Video:
#### Blog Application Part-2 (CRUD Operations)
#### Server and Client Components