export default function Blog() {
  return (
    <div>
      <h1>Resources and Insights</h1>
      <p>The latest industry news, interviews, technologies, and resources.</p>
      <input type="search" placeholder="Search..." />

      <div className="blog-card">
        <img src="/image.png" alt="Blog Post" className="blog-banner" />
        <p className="label">Design</p>
        <h2 className="heading">UX review presentations</h2>
        <p className="description">This is the description about the UX review.</p>

      <div className="blog-footer">
        <img src="/user.png" alt="Blog Post" className="blog-author" />
        <div>
        <p>Venkatesh Mogili</p>
        <p>20 Jan 2025</p>
        </div>
        </div>
      </div>

      <div className="blog-card">
        <img src="/image.png" alt="Blog Post" className="blog-banner" />
        <p className="label">Design</p>
        <h2 className="heading">UX review presentations</h2>
        <p className="description">This is the description about the UX review.</p>

      <div className="blog-footer">
        <img src="/user.png" alt="Blog Post" className="blog-author" />
        <div>
        <p>Venkatesh Mogili</p>
        <p>20 Jan 2025</p>
        </div>
        </div>
      </div>

      <div className="blog-card">
        <img src="/image.png" alt="Blog Post" className="blog-banner" />
        <p className="label">Design</p>
        <h2 className="heading">UX review presentations</h2>
        <p className="description">This is the description about the UX review.</p>

      <div className="blog-footer">
        <img src="/user.png" alt="Blog Post" className="blog-author" />
        <div>
        <p>Venkatesh Mogili</p>
        <p>20 Jan 2025</p>
        </div>
        </div>
      </div>
    </div>
  );
}
