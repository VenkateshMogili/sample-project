export default async function SingleBlog({params}) {
  const paramsData = await params;
  return (
    <h1>Blog {paramsData.blogId} Details</h1>
  );
}
